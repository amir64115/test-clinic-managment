import React, { useState } from 'react';
import type { Doctor, PermissionSet, Personnel, Appointment } from '../types';
import { TrashIcon, DownloadIcon, EditIcon, UserCircleIcon, IdentificationIcon } from './icons/Icons';
import { exportToExcel } from '../utils/exportToExcel';
import { formatNumberWithCommas, parseFormattedNumber } from '../utils/numberUtils';

interface DoctorManagementProps {
  doctors: Doctor[];
  permissions: PermissionSet;
  currentUser: Personnel;
  addDoctor: (doctor: Omit<Doctor, 'id'>) => Promise<Doctor>;
  updateDoctor: (doctor: Doctor) => Promise<Doctor>;
  deleteDoctor: (id: number | string) => Promise<void>;
  appointments: Appointment[];
}

const emptyDoctor: Omit<Doctor, 'id'> = {
  name: '', specialty: '', phone: '', photoUrl: '', officeHours: '', ratePerHour: 0, participationRate: 0, referralParticipationRate: 0, education: '',
};

const DoctorManagement: React.FC<DoctorManagementProps> = ({ doctors, permissions, currentUser, addDoctor, updateDoctor, deleteDoctor, appointments }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<Doctor, 'id'>>(emptyDoctor);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [viewingDoctor, setViewingDoctor] = useState<Doctor | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Check if user is a manager (Admin or Management role)
  const isManager = ['مدیر', 'مدیریت'].includes(currentUser.role);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let finalValue;
    if (name === 'ratePerHour') {
        finalValue = parseFormattedNumber(value);
    } else if (name === 'participationRate' || name === 'referralParticipationRate') {
        finalValue = parseInt(value) || 0;
    } else {
        finalValue = value;
    }
    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const handleFile = (file: File | null) => {
    if (!file) return;

    const MAX_SIZE_KB = 100;
    const MAX_SIZE_BYTES = MAX_SIZE_KB * 1024;

    if (file.size > MAX_SIZE_BYTES) {
      alert(`حجم عکس نباید بیشتر از ${MAX_SIZE_KB} کیلوبایت باشد.`);
      return;
    }

    if (!['image/png', 'image/jpeg'].includes(file.type)) {
        alert('لطفا یک فایل با فرمت JPG یا PNG انتخاب کنید.');
        return;
    }
    
    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({...prev, photoUrl: reader.result as string}));
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFile(e.target.files ? e.target.files[0] : null);
    if(e.target) e.target.value = '';
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFile(e.dataTransfer.files && e.dataTransfer.files[0] ? e.dataTransfer.files[0] : null);
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleRemovePhoto = () => {
    setFormData(prev => ({ ...prev, photoUrl: '' }));
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingDoctor(null);
    setFormData(emptyDoctor);
  };

  const closeViewModal = () => {
    setIsViewModalOpen(false);
    setViewingDoctor(null);
  };

  const openAddModal = () => {
    setEditingDoctor(null);
    setFormData(emptyDoctor);
    setIsModalOpen(true);
  };

  const openEditModal = (doctor: Doctor) => {
    setEditingDoctor(doctor);
    setFormData(doctor);
    setIsModalOpen(true);
  };

  const openViewModal = (doctor: Doctor) => {
    setViewingDoctor(doctor);
    setIsViewModalOpen(true);
  };

  const handleEditFromView = () => {
    if (viewingDoctor) {
      openEditModal(viewingDoctor);
      closeViewModal();
    }
  };

  const handleSaveDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.specialty && formData.phone) {
      try {
        if (editingDoctor) {
          await updateDoctor({ ...formData, id: editingDoctor.id });
        } else {
          await addDoctor(formData);
        }
        closeModal();
      } catch (error) {
        console.error("Save doctor failed:", error);
      }
    } else {
      alert("لطفا فیلدهای نام، تخصص و شماره تماس را تکمیل کنید.");
    }
  };
  
  const handleDeleteDoctor = async (id: string) => {
    const hasAppointments = appointments.some(app => app.doctorId === id);
    if (hasAppointments) {
      alert('امکان حذف این پزشک وجود ندارد زیرا نوبت‌های ثبت شده‌ای برای او وجود دارد. لطفا ابتدا نوبت‌های این پزشک را حذف یا به پزشک دیگری منتقل کنید.');
      return;
    }

    if(window.confirm('آیا از حذف این پزشک اطمینان دارید؟ این عمل غیرقابل بازگشت است.')) {
       try {
         await deleteDoctor(id);
       } catch (error) {
         console.error("Delete doctor failed:", error);
       }
    }
  }

  const handleExport = () => {
    const dataToExport = doctors.map(d => {
      const row: any = {
        'نام کامل': d.name,
        'تخصص': d.specialty,
        'رشته تحصیلی': d.education || '-',
        'شماره تماس': d.phone,
        'ساعات کاری': d.officeHours,
        'نرخ ویزیت (ساعت)': d.ratePerHour || 0,
      };
      if (isManager) {
        row['درصد سهم درمانگر (عادی)'] = d.participationRate || 0;
        row['درصد سهم درمانگر (بیمار معرف)'] = d.referralParticipationRate || 0;
      }
      return row;
    });
    exportToExcel(dataToExport, 'doctors-list.xlsx');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h2 className="text-2xl sm:text-3xl font-bold">مدیریت پزشکان و درمانگران</h2>
        <div className="flex items-center gap-2">
            <button onClick={handleExport} className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition flex items-center gap-2">
              <DownloadIcon className="w-5 h-5" />
              خروجی اکسل
            </button>
            {permissions.add && (
              <button onClick={openAddModal} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition">
                افزودن پزشک
              </button>
            )}
        </div>
      </div>

      <div className="bg-white p-2 sm:p-6 rounded-lg shadow-md">
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-3 text-sm font-semibold tracking-wide"></th>
                <th className="p-3 text-sm font-semibold tracking-wide">نام</th>
                <th className="p-3 text-sm font-semibold tracking-wide">تخصص</th>
                {isManager && <th className="p-3 text-sm font-semibold tracking-wide">درصد سهم از درمان</th>}
                <th className="p-3 text-sm font-semibold tracking-wide">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {doctors.map(doctor => (
                <tr key={doctor.id} className="border-b hover:bg-gray-50">
                  <td className="p-2">
                    {doctor.photoUrl ? <img src={doctor.photoUrl} alt={doctor.name} className="w-12 h-12 rounded-full object-cover"/> : <UserCircleIcon className="w-12 h-12 text-gray-300"/>}
                  </td>
                  <td className="p-3 font-semibold">{doctor.name}</td>
                  <td className="p-3">{doctor.specialty}</td>
                  {isManager && (
                    <td className="p-3 text-xs">
                      <p>عادی: {doctor.participationRate || 0}%</p>
                      <p>معرف: {doctor.referralParticipationRate || 0}%</p>
                    </td>
                  )}
                  <td className="p-3 flex items-center space-x-2 space-x-reverse">
                     <button onClick={() => openViewModal(doctor)} className="text-gray-500 hover:text-blue-600 p-1" title="مشاهده پروفایل">
                        <IdentificationIcon className="w-6 h-6" />
                     </button>
                     {permissions.edit && (
                       <button onClick={(e) => {e.stopPropagation(); openEditModal(doctor)}} className="text-gray-500 hover:text-green-600 p-1" title="ویرایش">
                          <EditIcon className="w-6 h-6" />
                       </button>
                     )}
                     {permissions.delete && (
                      <button onClick={(e) => {e.stopPropagation(); handleDeleteDoctor(doctor.id)}} className="text-gray-500 hover:text-red-600 p-1" title="حذف">
                          <TrashIcon className="w-6 h-6" />
                      </button>
                     )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="md:hidden space-y-4">
            {doctors.map(doctor => (
                <div key={doctor.id} className="bg-gray-50 p-4 rounded-lg border" onClick={() => openViewModal(doctor)}>
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                           {doctor.photoUrl ? <img src={doctor.photoUrl} alt={doctor.name} className="w-14 h-14 rounded-full object-cover ml-3"/> : <UserCircleIcon className="w-14 h-14 text-gray-300 ml-3"/>}
                           <div>
                              <p className="font-bold text-lg">{doctor.name}</p>
                              <p className="text-sm text-gray-600">{doctor.specialty}</p>
                           </div>
                        </div>
                    </div>
                    {isManager && (
                      <p className="text-sm text-gray-700 bg-white p-2 rounded border"><span className="font-semibold text-blue-600">سهم درمانگر:</span> {doctor.participationRate || 0}% (معرف: {doctor.referralParticipationRate || 0}%)</p>
                    )}
                </div>
            ))}
        </div>
      </div>

      {isViewModalOpen && viewingDoctor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 overflow-y-auto" onClick={closeViewModal}>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
               <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-right">
                  {viewingDoctor.photoUrl ? <img src={viewingDoctor.photoUrl} alt={viewingDoctor.name} className="w-32 h-32 rounded-full object-cover mb-4 sm:mb-0 sm:ml-6 border-4 border-gray-200"/> : <UserCircleIcon className="w-32 h-32 text-gray-300 mb-4 sm:mb-0 sm:ml-6"/>}
                  <div className="flex-1">
                     <h3 className="text-3xl font-bold">{viewingDoctor.name}</h3>
                     <p className="text-lg text-blue-600 font-semibold mt-1">{viewingDoctor.specialty}</p>
                     {viewingDoctor.education && <p className="text-md text-gray-600 mt-2">{viewingDoctor.education}</p>}
                     <p className="text-md text-gray-600 mt-2">{viewingDoctor.phone}</p>
                     {viewingDoctor.officeHours && <p className="text-sm text-gray-500 mt-2"><strong>ساعات کاری:</strong> {viewingDoctor.officeHours}</p>}
                     {viewingDoctor.ratePerHour && <p className="text-md text-gray-600 mt-2"><strong>نرخ ویزیت (ساعت):</strong> {viewingDoctor.ratePerHour.toLocaleString('fa-IR')} تومان</p>}
                     {(isManager || (currentUser.role === 'پزشک' && currentUser.name === viewingDoctor.name)) && (
                        <div className="mt-2 pt-2 border-t">
                          <p className="text-sm text-gray-600"><strong>درصد سهم درمانگر (عادی):</strong> {(viewingDoctor.participationRate || 0).toLocaleString('fa-IR')}%</p>
                          <p className="text-sm text-gray-600"><strong>درصد سهم درمانگر (معرف):</strong> {(viewingDoctor.referralParticipationRate || 0).toLocaleString('fa-IR')}%</p>
                        </div>
                     )}
                  </div>
               </div>
               <div className="flex justify-end mt-8">
                  <button type="button" onClick={closeViewModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">بستن</button>
                  {permissions.edit && (
                    <button type="button" onClick={handleEditFromView} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center gap-2"><EditIcon className="w-5 h-5"/> ویرایش</button>
                  )}
                </div>
            </div>
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" onClick={closeModal}>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-2xl font-bold mb-6">{editingDoctor ? 'ویرایش پروفایل' : 'افزودن پروفایل جدید'}</h3>
              <form onSubmit={handleSaveDoctor} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-center">
                    عکس پروفایل <span className="text-gray-500 text-xs">(اختیاری)</span>
                  </label>
                  <div 
                      className={`relative group w-48 h-48 mx-auto border-2 border-dashed rounded-full flex justify-center items-center cursor-pointer transition-colors ${isDragging ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-500 hover:bg-gray-50'}`}
                      onClick={() => document.getElementById('photo-upload-doctor')?.click()}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                  >
                      <input type="file" id="photo-upload-doctor" accept="image/png, image/jpeg" onChange={handlePhotoChange} className="hidden" />
                      {formData.photoUrl ? (
                          <>
                              <img src={formData.photoUrl} alt="Preview" className="w-full h-full rounded-full object-cover" />
                              <button 
                                  type="button" 
                                  onClick={(e) => {
                                      e.stopPropagation();
                                      handleRemovePhoto();
                                  }}
                                  className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                  title="حذف عکس"
                              >
                                  <TrashIcon className="w-4 h-4" />
                              </button>
                          </>
                      ) : (
                          <div className="text-center text-gray-500 p-4">
                              <UserCircleIcon className="w-16 h-16 mx-auto text-gray-400" />
                              <p className="mt-2 text-sm">عکس را اینجا بکشید یا کلیک کنید</p>
                          </div>
                      )}
                  </div>
                  <p className="text-xs text-gray-500 text-center mt-2">حداکثر حجم: ۱۰۰ کیلوبایت (JPG, PNG)</p>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 mb-2">نام کامل<span className="text-red-500 mr-1">*</span></label>
                      <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required />
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2">تخصص<span className="text-red-500 mr-1">*</span></label>
                      <input type="text" name="specialty" value={formData.specialty} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required />
                    </div>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">رشته تحصیلی (اختیاری)</label>
                  <input type="text" name="education" placeholder="مثال: دانشگاه علوم پزشکی تهران" value={formData.education || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg" />
                </div>

                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 mb-2">شماره تماس<span className="text-red-500 mr-1">*</span></label>
                      <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required />
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2">ساعات کاری (اختیاری)</label>
                      <input type="text" name="officeHours" placeholder="مثال: روزهای زوج، ۱۶ تا ۲۰" value={formData.officeHours || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg" />
                    </div>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">نرخ ویزیت (تومان در ساعت) <span className="text-gray-500 text-xs">(اختیاری)</span></label>
                  <input type="text" name="ratePerHour" value={formatNumberWithCommas(formData.ratePerHour || '')} onChange={handleInputChange} className="w-full p-2 border rounded-lg" />
                </div>
                
                {isManager && (
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                      <h4 className="text-sm font-bold text-blue-800 mb-3 border-b border-blue-200 pb-1">تنظیمات سهم درمانگر (برای محاسبه حقوق)</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-gray-700 mb-1 text-sm">درصد سهم درمانگر (عادی)</label>
                            <input type="number" name="participationRate" min="0" max="100" value={formData.participationRate || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg bg-white" placeholder="مثال: 30" />
                          </div>
                          <div>
                            <label className="block text-gray-700 mb-1 text-sm">درصد سهم درمانگر (بیمار معرف)</label>
                            <input type="number" name="referralParticipationRate" min="0" max="100" value={formData.referralParticipationRate || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg bg-white" placeholder="مثال: 40" />
                          </div>
                      </div>
                  </div>
                )}
                
                <div className="flex justify-end mt-6">
                  <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">لغو</button>
                  <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">ذخیره</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DoctorManagement;