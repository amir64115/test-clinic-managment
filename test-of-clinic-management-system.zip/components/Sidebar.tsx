
import React, { useMemo } from 'react';
import { DashboardIcon, PatientsIcon, DoctorsIcon, AppointmentsIcon, FinancialIcon, ReportsIcon, PersonnelIcon, BackupIcon, SettingsIcon } from './icons/Icons';
import type { AppView, AppPermissions, Personnel, RolePermissions } from '../types';

interface SidebarProps {
  setCurrentView: (view: AppView) => void;
  currentView: AppView;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  currentUser: Personnel;
  permissions: AppPermissions;
}

const Sidebar: React.FC<SidebarProps> = ({ setCurrentView, currentView, isOpen, setIsOpen, currentUser, permissions }) => {
  
  const navItems = useMemo(() => {
    const allItems = [
      { name: 'dashboard', label: 'داشبورد', icon: DashboardIcon },
      { name: 'patients', label: 'بیماران', icon: PatientsIcon },
      { name: 'doctors', label: 'پزشکان', icon: DoctorsIcon },
      { name: 'personnel', label: 'پرسنل', icon: PersonnelIcon },
      { name: 'appointments', label: 'نوبت‌دهی', icon: AppointmentsIcon },
      { name: 'financial', label: 'مالی', icon: FinancialIcon },
      { name: 'reports', label: 'گزارشات', icon: ReportsIcon },
      { name: 'backup', label: 'پشتیبان‌گیری', icon: BackupIcon },
      { name: 'settings', label: 'تنظیمات', icon: SettingsIcon },
    ];
    
    const userRole = currentUser.role || '';
    const userPermissions = permissions[userRole] || {};

    return allItems.filter(item => {
      if (item.name === 'settings' && ['مدیر', 'مدیریت'].includes(userRole)) {
        return true;
      }
      return !!userPermissions[item.name as keyof RolePermissions]?.view;
    });
  }, [currentUser, permissions]);


  const handleNavClick = (view: AppView) => {
    setCurrentView(view);
    setIsOpen(false);
  };

  return (
    <>
      {/* Overlay for mobile/tablet with blur effect - hidden on large screens */}
      <div 
        className={`fixed inset-0 bg-gray-900/50 backdrop-blur-sm z-20 transition-opacity duration-300 lg:hidden ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsOpen(false)}
      ></div>

      {/* Sidebar - fixed on mobile/tablet, relative on large screens */}
      <aside className={`fixed top-0 right-0 h-full w-72 bg-gray-800 text-white flex flex-col z-30 transform transition-transform duration-300 ease-in-out shadow-2xl lg:relative lg:translate-x-0 lg:w-64 lg:shadow-none ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="h-16 flex items-center justify-center text-2xl font-bold border-b border-gray-700 bg-gray-900">
          کلینیک
        </div>
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.name}>
                <button
                  onClick={() => handleNavClick(item.name as AppView)}
                  className={`w-full flex items-center px-4 py-3 rounded-xl text-lg transition-all duration-200 ${
                    currentView === item.name
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white hover:pl-6'
                  }`}
                >
                  <item.icon className="w-6 h-6 ml-3" />
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="p-4 border-t border-gray-700 text-center text-sm text-gray-400 bg-gray-900">
          نسخه 1.0.4
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
