import React, { useState, useRef, useEffect } from 'react';
import { MicrophoneIcon } from './icons/Icons';

// Add SpeechRecognition to the window object for TypeScript
declare global {
    interface Window {
        SpeechRecognition: any;
        webkitSpeechRecognition: any;
    }
}

interface VoiceEnabledTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

const VoiceEnabledTextarea: React.FC<VoiceEnabledTextareaProps> = ({ value, onChange, ...rest }) => {
    const [isRecording, setIsRecording] = useState(false);
    const recognitionRef = useRef<any | null>(null);
    const isComponentMounted = useRef(true);

    useEffect(() => {
        isComponentMounted.current = true;
        return () => {
            isComponentMounted.current = false;
            // Stop recognition if component unmounts while recording
            if (recognitionRef.current) {
                recognitionRef.current.stop();
            }
        };
    }, []);
    
    const handleToggleRecording = () => {
        if (isRecording) {
            recognitionRef.current?.stop();
            return;
        }

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert("متاسفانه مرورگر شما از قابلیت تشخیص گفتار پشتیبانی نمی‌کند.");
            return;
        }

        const recognition = new SpeechRecognition();
        recognitionRef.current = recognition;
        recognition.lang = 'fa-IR';
        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onstart = () => {
            if(isComponentMounted.current) setIsRecording(true);
        };
        recognition.onend = () => {
            if(isComponentMounted.current) setIsRecording(false);
            recognitionRef.current = null;
        };
        recognition.onerror = (event: any) => {
            console.error("Speech recognition error:", event.error);
            if(isComponentMounted.current) setIsRecording(false);
        };

        recognition.onresult = (event: any) => {
            let finalTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                }
            }
            if (finalTranscript && onChange) {
                 const syntheticEvent = {
                    target: {
                        value: (value ? value + ' ' : '') + finalTranscript.trim(),
                        name: rest.name
                    }
                } as React.ChangeEvent<HTMLTextAreaElement>;
                onChange(syntheticEvent);
            }
        };
        recognition.start();
    };

    return (
        <div className="relative w-full">
            <textarea
                value={value}
                onChange={onChange}
                className="w-full p-2 border rounded-lg pl-12"
                {...rest}
            />
            <button
                type="button"
                onClick={handleToggleRecording}
                className={`absolute top-2 left-2 p-2 rounded-full transition-colors ${
                    isRecording
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                }`}
                title={isRecording ? 'توقف ضبط' : 'ضبط صدا (فارسی)'}
            >
                <MicrophoneIcon className="w-5 h-5" />
            </button>
        </div>
    );
};

export default VoiceEnabledTextarea;