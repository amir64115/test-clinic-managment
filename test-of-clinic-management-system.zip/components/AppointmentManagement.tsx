
import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { Appointment, Patient, Doctor, Transaction, BankAccount, PermissionSet, Personnel, ClinicalRecord, TreatmentPlan } from '../types';
import { BellIcon, CalendarMonthIcon, CalendarWeekIcon, ClipboardListIcon, ListViewIcon, TrashIcon, EditIcon, JalaliDatePicker, UsersIcon, ClockIcon, StethoscopeIcon, CalendarDayIcon, ChevronLeftIcon, ChevronRightIcon, ClipboardCopyIcon, DocumentReportIcon } from './icons/Icons';
import { AppointmentCalendarView } from './AppointmentCalendarView';
import { formatToJalali, isPastDateTime, getJalaliMonthName } from '../utils/dateUtils';
import { formatNumberWithCommas, parseFormattedNumber } from '../utils/numberUtils';
import VoiceEnabledTextarea from './VoiceEnabledTextarea';


// FIX: Declare the jalaali library loaded via script tag to resolve reference errors.
declare var jalaali: any;
// Add SpeechRecognition to the window object for TypeScript
declare global {
    interface Window {
        SpeechRecognition: any;
        webkitSpeechRecognition: any;
    }
}

const DOCTOR_COLOR_PALETTE_DAY = [
  { bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-400', hoverBg: 'hover:bg-blue-100' },
  { bg: 'bg-green-50', text: 'text-green-800', border: 'border-green-400', hoverBg: 'hover:bg-green-100' },
  { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-400', hoverBg: 'hover:bg-purple-100' },
  { bg: 'bg-yellow-50', text: 'text-yellow-800', border: 'border-yellow-400', hoverBg: 'hover:bg-yellow-100' },
  { bg: 'bg-pink-50', text: 'text-pink-800', border: 'border-pink-400', hoverBg: 'hover:bg-pink-100' },
  { bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-400', hoverBg: 'hover:bg-indigo-100' },
  { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-400', hoverBg: 'hover:bg-red-100' },
  { bg: 'bg-teal-50', text: 'text-teal-800', border: 'border-teal-400', hoverBg: 'hover:bg-teal-100' },
];

const getDoctorColorClasses = (doctorId: string) => {
  if (!doctorId) return DOCTOR_COLOR_PALETTE_DAY[0];
  const numericId = parseInt(doctorId, 10) || 0;
  const colorIndex = numericId % DOCTOR_COLOR_PALETTE_DAY.length;
  return DOCTOR_COLOR_PALETTE_DAY[colorIndex];
};

interface CustomTimePickerProps {
  value: string; // HH:MM format
  onChange: (value: string) => void;
  required?: boolean;
}

const CustomTimePicker: React.FC<CustomTimePickerProps> = ({ value, onChange, required }) => {
    const [hour, minute] = useMemo(() => {
        return value && value.includes(':') ? value.split(':') : ['09', '00'];
    }, [value]);

    const handleTimeChange = (part: 'hour' | 'minute', val: string) => {
        const newTime = part === 'hour' ? `${val}:${minute}` : `${hour}:${val}`;
        onChange(newTime);
    };
    
    const hours = useMemo(() => Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0')), []);
    const minutes = useMemo(() => ['00', '15', '30', '45'], []);

    return (
        <div className="flex items-center gap-2" dir="ltr">
            <select
                value={hour}
                onChange={(e) => handleTimeChange('hour', e.target.value)}
                className="w-full p-2.5 border rounded-lg bg-white text-center"
                required={required}
            >
                {hours.map(h => <option key={h} value={h}>{Number(h).toLocaleString('fa-IR')}</option>)}
            </select>
            <span className="font-bold text-gray-500">:</span>
            <select
                value={minute}
                onChange={(e) => handleTimeChange('minute', e.target.value)}
                className="w-full p-2.5 border rounded-lg bg-white text-center"
                required={required}
            >
                {minutes.map(m => <option key={m} value={m}>{Number(m).toLocaleString('fa-IR')}</option>)}
            </select>
        </div>
    );
};

// FIX: Added interface for component props to resolve type error.
interface AppointmentManagementProps {
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  patients: Patient[];
  doctors: Doctor[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  bankAccounts: BankAccount[];
  permissions: PermissionSet;
  currentUser: Personnel;
  clinicalRecords: ClinicalRecord[];
  setClinicalRecords: React.Dispatch<React.SetStateAction<ClinicalRecord[]>>;
  treatmentPlans: TreatmentPlan[];
  setTreatmentPlans: React.Dispatch<React.SetStateAction<TreatmentPlan[]>>;
}

// FIX: Added constant for an empty appointment to resolve reference errors.
const emptyAppointment: Omit<Appointment, 'id'> = {
  patientIds: [],
  doctorId: '',
  date: new Date().toISOString().split('T')[0],
  time: '09:00',
  sessionDuration: '45',
  sessionFee: 0,
  status: 'Scheduled',
  paymentStatus: 'Unpaid',
  cancellationReason: '',
  notes: '',
  suggestedDoctorIds: [], // Added suggestedDoctorIds
};

const getStatusLabel = (status: Appointment['status']) => {
    switch(status) {
        case 'Scheduled': return { text: 'زمان‌بندی شده', className: 'bg-blue-100 text-blue-800' };
        case 'Completed': return { text: 'تکمیل شده', className: 'bg-green-100 text-green-800' };
        case 'Cancelled': return { text: 'لغو شده', className: 'bg-red-100 text-red-800' };
        case 'Waiting': return { text: 'در انتظار', className: 'bg-yellow-100 text-yellow-800' };
        default: return { text: status, className: 'bg-gray-100 text-gray-800' };
    }
};


const AppointmentManagement: React.FC<AppointmentManagementProps> = ({
  appointments,
  setAppointments,
  patients,
  doctors,
  setTransactions,
  bankAccounts,
  permissions,
  currentUser,
  clinicalRecords,
  setClinicalRecords,
  treatmentPlans,
  setTreatmentPlans,
}) => {
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day' | 'list' | 'waiting'>('day');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<Appointment, 'id'>>(emptyAppointment);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [currentDay, setCurrentDay] = useState(new Date());

  const [patientSearch, setPatientSearch] = useState('');
  const [isPatientDropdownOpen, setIsPatientDropdownOpen] = useState(false);
  const patientSearchRef = useRef<HTMLDivElement>(null);
  
  const [currentRecord, setCurrentRecord] = useState<Omit<ClinicalRecord, 'id'> | null>(null);

  const [isCustomReminderEnabled, setIsCustomReminderEnabled] = useState(false);
  const [reminderDate, setReminderDate] = useState('');
  const [reminderTime, setReminderTime] = useState('');
  
  const [cancellationFeeData, setCancellationFeeData] = useState({
      charge: false,
      amount: '',
      paymentMethod: 'نقد',
      accountDebited: '',
  });

  const [draggingAppointmentId, setDraggingAppointmentId] = useState<string | null>(null);
  const [dragOverSlot, setDragOverSlot] = useState<{ doctorId: string; time: string } | null>(null);

  // Deletion modal state
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingAppointment, setDeletingAppointment] = useState<Appointment | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  
  // Copy Day Modal State
  const [isCopyDayModalOpen, setIsCopyDayModalOpen] = useState(false);
  const [copyTargetDate, setCopyTargetDate] = useState('');
  const [selectedDoctorIdsForCopy, setSelectedDoctorIdsForCopy] = useState<string[]>([]);

  
  const getPatientName = (id: string) => patients.find(p => p.id === id)?.name || `بیمار #${id}`;
  const getDoctorName = (id: string) => doctors.find(d => d.id === id)?.name || `پزشک #${id}`;

  const availablePatients = useMemo(() => {
    return patients.filter(p => 
      p.name.toLowerCase().includes(patientSearch.toLowerCase()) && 
      !formData.patientIds.includes(p.id)
    );
  }, [patients, patientSearch, formData.patientIds]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (patientSearchRef.current && !patientSearchRef.current.contains(event.target as Node)) {
            setIsPatientDropdownOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (editingAppointment || formData.patientIds.length !== 1) return;
    const patientId = formData.patientIds[0];
    const patientAppointments = appointments.filter(app => app.patientIds.includes(patientId)).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    if (patientAppointments.length === 0) return;
    let lastAppointment = patientAppointments.find(app => app.status === 'Completed') || patientAppointments[0];
    if (lastAppointment && lastAppointment.id !== editingAppointment?.id) {
       setFormData(prev => ({ ...prev, doctorId: lastAppointment.doctorId, sessionDuration: lastAppointment.sessionDuration || '45' }));
    }
  }, [formData.patientIds, appointments, editingAppointment]);

  useEffect(() => {
    if (isCustomReminderEnabled && !reminderDate) {
        setReminderDate(formData.date);
    }
  }, [isCustomReminderEnabled, formData.date, reminderDate]);
  
  const handleAddPatientToSelection = (patientId: string) => {
    setFormData(prev => ({...prev, patientIds: [...prev.patientIds, patientId]}));
    setPatientSearch('');
    setIsPatientDropdownOpen(false);
  };
  
  const handleRemovePatientFromSelection = (patientId: string) => {
    setFormData(prev => ({...prev, patientIds: prev.patientIds.filter(id => id !== patientId)}));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'sessionFee' ? parseFormattedNumber(value) : value }));
  };
  
  const handleRecordChange = (field: keyof Omit<ClinicalRecord, 'id' | 'appointmentId' | 'patientId' | 'doctorId' | 'createdAt' | 'updatedAt'>, value: string) => {
    setCurrentRecord(prev => prev ? { ...prev, [field]: value, updatedAt: new Date().toISOString() } : null);
  }

  const handleDateChange = (name: string, date: string) => {
    setFormData(prev => ({ ...prev, [name]: date }));
  };
  
  const handleSuggestedDoctorsChange = (doctorId: string) => {
      setFormData(prev => {
          const currentList = prev.suggestedDoctorIds || [];
          if (currentList.includes(doctorId)) {
              return { ...prev, suggestedDoctorIds: currentList.filter(id => id !== doctorId) };
          } else {
              return { ...prev, suggestedDoctorIds: [...currentList, doctorId] };
          }
      });
  };
  
  useEffect(() => {
    if(formData.doctorId && formData.sessionDuration) {
      const doctor = doctors.find(d => d.id === formData.doctorId);
      if (doctor) {
        const fee = Math.round((doctor.ratePerHour / 60) * parseInt(formData.sessionDuration, 10));
        setFormData(prev => ({...prev, sessionFee: fee}));
      }
    } else {
        setFormData(prev => ({...prev, sessionFee: 0}));
    }
  }, [formData.doctorId, formData.sessionDuration, doctors]);

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingAppointment(null);
    setFormData(emptyAppointment);
    setPatientSearch('');
    setCurrentRecord(null);
    setIsCustomReminderEnabled(false);
    setReminderDate('');
    setReminderTime('');
    setCancellationFeeData({ charge: false, amount: '', paymentMethod: 'نقد', accountDebited: '' });
  };
  
  const closeDeleteModal = () => {
      setIsDeleteModalOpen(false);
      setDeletingAppointment(null);
      setDeleteReason('');
  }

// FIX: Update openAddModal to accept an optional date string to allow creating appointments from the calendar view.
  const openAddModal = (date?: string) => {
    setEditingAppointment(null);
    setFormData({
      ...emptyAppointment,
      date: date || new Date().toISOString().split('T')[0],
    });
    setCurrentRecord(null);
    setIsCustomReminderEnabled(false);
    setReminderDate('');
    setReminderTime('');
    setCancellationFeeData({ charge: false, amount: '', paymentMethod: 'نقد', accountDebited: '' });
    setIsModalOpen(true);
  };

  const openEditModal = (appointment: Appointment) => {
    setEditingAppointment(appointment);
    setFormData({ ...appointment, suggestedDoctorIds: appointment.suggestedDoctorIds || [] });

    if (currentUser.role === 'پزشک' && appointment.status === 'Completed' && appointment.patientIds.length > 0) {
        const existingRecord = clinicalRecords.find(r => r.appointmentId === appointment.id);
        if (existingRecord) {
            setCurrentRecord(existingRecord);
        } else {
            setCurrentRecord({
                appointmentId: appointment.id,
                patientId: appointment.patientIds[0],
                doctorId: appointment.doctorId,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                note: '',
                messages: [],
                subjective: '', objective: '', assessment: '', plan: ''
            });
        }
    } else {
        setCurrentRecord(null);
    }
    
    if (appointment.reminderDateTime) {
        setIsCustomReminderEnabled(true);
        const [datePart, timePart] = appointment.reminderDateTime.split('T');
        setReminderDate(datePart);
        setReminderTime(timePart ? timePart.substring(0, 5) : '');
    } else {
        setIsCustomReminderEnabled(false);
        setReminderDate('');
        setReminderTime('');
    }
    setCancellationFeeData({
        charge: !!appointment.cancellationFee,
        amount: appointment.cancellationFee ? String(appointment.cancellationFee) : '',
        paymentMethod: 'نقد',
        accountDebited: ''
    });
    setIsModalOpen(true);
  };
  
  const requestNotificationPermission = async (): Promise<boolean> => {
    if (typeof Notification === 'undefined') {
        alert('مرورگر شما از یادآوری‌ها پشتیبانی نمی‌کند.');
        return false;
    }
    if (Notification.permission === 'granted') return true;
    if (Notification.permission === 'denied') {
        alert('ارسال یادآوری در مرورگر شما مسدود شده است. برای فعال‌سازی، لطفا به تنظیمات مرورگر خود مراجعه کرده و دسترسی لازم را به این سایت بدهید.');
        return false;
    }
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
        new Notification('یادآوری‌ها فعال شدند', { body: 'یادآوری‌های سفارشی برای شما نمایش داده خواهد شد.', icon: '/logo192.png' });
        return true;
    } else {
        alert('شما اجازه ارسال یادآوری را ندادید. برای استفاده از این قابلیت، لطفا از تنظیمات مرورگر خود اقدام کنید.');
        return false;
    }
  };

  const handleSaveAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.patientIds.length > 0 && (formData.doctorId || formData.status === 'Waiting') && formData.date) {
      if (formData.status === 'Completed' && formData.paymentStatus === 'Paid' && !formData.paymentMethod) {
        alert('لطفا روش پرداخت را انتخاب کنید.');
        return;
      }
       if (formData.status === 'Cancelled' && cancellationFeeData.charge && (!cancellationFeeData.amount || parseFormattedNumber(cancellationFeeData.amount) <= 0)) {
        alert('لطفا مبلغ جریمه کنسلی را وارد کنید.');
        return;
      }
      if (formData.status === 'Cancelled' && !formData.cancellationReason?.trim()) {
        alert('لطفا دلیل لغو نوبت را وارد کنید. این فیلد اجباری است.');
        return;
      }
      
      let customReminderData: Partial<Appointment> = {};
      if (isCustomReminderEnabled && reminderDate && reminderTime) {
          const permissionGranted = await requestNotificationPermission();
          if (!permissionGranted) {
              setIsCustomReminderEnabled(false);
          } else {
              const reminderDateTimeObj = new Date(`${reminderDate}T${reminderTime}`);
              if (reminderDateTimeObj < new Date()) {
                  alert('زمان یادآوری نمی‌تواند در گذشته باشد.');
                  return;
              }
              customReminderData = { reminderDateTime: `${reminderDate}T${reminderTime}:00`, reminderSent: false };
          }
      } else {
          customReminderData = { reminderDateTime: undefined, reminderSent: undefined };
      }
      
      const finalAppointmentData: Omit<Appointment, 'id'> & {id?: string} = {
          ...(editingAppointment ? { ...formData, id: editingAppointment.id } : { ...formData, id: String(Date.now()) }),
          ...customReminderData,
          cancellationFee: formData.status === 'Cancelled' && cancellationFeeData.charge ? parseFormattedNumber(cancellationFeeData.amount) : undefined
      };
      
      if (currentRecord) {
        const recordExists = clinicalRecords.some(r => r.appointmentId === currentRecord.appointmentId);
        const hasContent = Object.values(currentRecord).some(val => typeof val === 'string' && val.trim().length > 0);
        
        if (recordExists) {
            setClinicalRecords(prev => prev.map(r => r.appointmentId === currentRecord.appointmentId ? { ...currentRecord, id: r.id } as ClinicalRecord : r));
        } else if (hasContent) {
            setClinicalRecords(prev => [...prev, { ...currentRecord, id: String(Date.now()) } as ClinicalRecord]);
        }
      }

      if (editingAppointment) {
        setAppointments(prev => prev.map(a => a.id === editingAppointment.id ? finalAppointmentData as Appointment : a));
      } else {
        if (finalAppointmentData.status === 'Waiting') {
            finalAppointmentData.dateAddedToWaitingList = new Date().toISOString().split('T')[0];
        }
        setAppointments(prev => [...prev, finalAppointmentData as Appointment]);
      }

      const patientNames = finalAppointmentData.patientIds.map(getPatientName).join(', ');

      if (finalAppointmentData.status === 'Completed' && finalAppointmentData.paymentStatus === 'Paid' && finalAppointmentData.sessionFee) {
          const newTransaction: Omit<Transaction, 'id'> = {
              type: 'درآمد', description: `ویزیت بیمار: ${patientNames}`, amount: finalAppointmentData.sessionFee || 0,
              date: finalAppointmentData.date, patientId: finalAppointmentData.patientIds[0], doctorId: finalAppointmentData.doctorId,
              accountDebited: finalAppointmentData.paymentMethod === 'نقد' ? 'صندوق نقدی کلینیک' : (bankAccounts.find(b => b.name !== 'صندوق نقدی کلینیک')?.name || ''),
              paymentMethod: finalAppointmentData.paymentMethod,
          };
          setTransactions(prev => [...prev, {...newTransaction, id: String(Date.now())}]);
      }
      
      if (finalAppointmentData.status === 'Cancelled' && finalAppointmentData.cancellationFee && finalAppointmentData.cancellationFee > 0) {
          const newTransaction: Omit<Transaction, 'id'> = {
              type: 'درآمد', description: `هزینه کنسلی نوبت: ${patientNames}`, amount: finalAppointmentData.cancellationFee,
              date: new Date().toISOString().split('T')[0], patientId: finalAppointmentData.patientIds[0], doctorId: finalAppointmentData.doctorId,
              accountDebited: cancellationFeeData.accountDebited, paymentMethod: cancellationFeeData.paymentMethod as any,
          };
          setTransactions(prev => [...prev, {...newTransaction, id: String(Date.now() + 1)}]); // +1 to avoid key collision
      }

      const patientIdsWithNewAppointment = finalAppointmentData.patientIds;
      // Archive any confirmed treatment plans for this patient if an actual appointment is being scheduled (not just waiting list)
      if (patientIdsWithNewAppointment.length > 0 && finalAppointmentData.status !== 'Waiting') {
        setTreatmentPlans(prevPlans => {
            let plansUpdated = false;
            const newPlans = prevPlans.map(plan => {
                // Check if plan belongs to any of the patients in the appointment
                if (plan.status === 'confirmed' && patientIdsWithNewAppointment.includes(plan.patientId)) {
                    plansUpdated = true;
                    // FIX: Use 'as const' to ensure TypeScript infers 'archived' as a literal type, not a generic string, matching the TreatmentPlan['status'] type.
                    return { ...plan, status: 'archived' as const };
                }
                return plan;
            });
            // Only return new array if something actually changed to prevent re-renders
            return plansUpdated ? newPlans : prevPlans;
        });
      }
      
      closeModal();
    } else {
        alert("لطفا فیلدهای اجباری را تکمیل کنید.");
    }
  };

  const deleteAppointment = (id: string) => {
    const appToDelete = appointments.find(a => a.id === id);
    if (!appToDelete) return;

    if (appToDelete.status === 'Waiting') {
        setDeletingAppointment(appToDelete);
        setDeleteReason('');
        setIsDeleteModalOpen(true);
    } else {
        if (window.confirm('آیا از حذف این نوبت اطمینان دارید؟')) {
            setAppointments(prev => prev.filter(a => a.id !== id));
        }
    }
  };
  
    const handleCopyAppointment = (appointment: Appointment) => {
        const { patientIds, doctorId, sessionDuration } = appointment;
        const copiedData = {
            ...emptyAppointment,
            patientIds,
            doctorId,
            sessionDuration,
            date: new Date().toISOString().split('T')[0],
            time: '09:00',
        };
        setFormData(copiedData);
        setEditingAppointment(null);
        setIsModalOpen(true);
    };

  const handleConfirmRemoveFromWaitingList = () => {
    if (!deletingAppointment || !deleteReason.trim()) {
        alert('لطفا دلیل حذف از لیست انتظار را وارد کنید.');
        return;
    }
    setAppointments(prev => prev.map(app => 
        app.id === deletingAppointment.id 
        ? { ...app, status: 'Cancelled', cancellationReason: deleteReason.trim() } 
        : app
    ));
    closeDeleteModal();
  };

  const getPatientNames = (ids: string[]): string => {
    if (!ids || ids.length === 0) return 'نامشخص';
    const patientNames = ids.map(id => patients.find(p => p.id === id)?.name || `بیمار #${id}`);
    return patientNames.join('، ');
  };
  
  const handleSendManualReminder = async (appointment: Appointment) => {
    if (!await requestNotificationPermission()) return;
    const patientNames = getPatientNames(appointment.patientIds);
    const doctorName = getDoctorName(appointment.doctorId);
    new Notification('یادآوری نوبت', {
        body: `یادآوری نوبت برای بیمار ${patientNames} با ${doctorName} در تاریخ ${formatToJalali(appointment.date)} ساعت ${appointment.time || ''}.`,
        icon: '/logo192.png', tag: `manual-reminder-${appointment.id}-${Date.now()}`
    });
    alert('یادآوری با موفقیت ارسال شد.');
  };

  const sortedAppointments = useMemo(() => 
    [...appointments].sort((a,b) => (new Date(b.date).getTime() - new Date(a.date).getTime()) || (b.time || '00:00').localeCompare(a.time || '00:00')), [appointments]);
    
  const listAppointments = useMemo(() => sortedAppointments, [sortedAppointments]);
  const waitingListAppointments = useMemo(() => sortedAppointments.filter(a => a.status === 'Waiting'), [sortedAppointments]);

  const renderListView = () => (
    <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-right text-sm">
                <thead className="bg-gray-50 border-b">
                    <tr>
                        <th className="p-3 font-semibold">بیمار</th><th className="p-3 font-semibold">پزشک</th>
                        <th className="p-3 font-semibold">تاریخ و ساعت</th><th className="p-3 font-semibold">وضعیت</th><th className="p-3 font-semibold">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    {listAppointments.map(app => {
                        const isLocked = isPastDateTime(app.date, app.time);
                        const statusInfo = getStatusLabel(app.status);
                        return (
                            <tr key={app.id} className={`border-b hover:bg-gray-50 ${isLocked ? 'opacity-60' : ''}`}>
                                <td className="p-3">{getPatientNames(app.patientIds)}</td><td className="p-3">{getDoctorName(app.doctorId)}</td>
                                <td className="p-3">{formatToJalali(app.date)} - {app.time || 'نامشخص'}</td>
                                <td className="p-3">
                                    <span className={`px-2 py-1 rounded-full text-xs ${statusInfo.className}`}>
                                        {statusInfo.text}
                                    </span>
                                </td>
                                <td className="p-3 flex items-center space-x-2 space-x-reverse">
                                    {app.status === 'Scheduled' && !isLocked && <button onClick={() => handleSendManualReminder(app)} className="text-gray-500 hover:text-yellow-600 p-1" title="ارسال یادآوری دستی"><BellIcon className="w-6 h-6"/></button>}
                                    {permissions.add && <button onClick={() => handleCopyAppointment(app)} className="text-gray-500 p-1 hover:text-blue-600" title="کپی کردن نوبت"><ClipboardCopyIcon className="w-6 h-6" /></button>}
                                    {permissions.edit && <button onClick={() => !isLocked && openEditModal(app)} disabled={isLocked} className="text-gray-500 p-1 disabled:opacity-50 disabled:cursor-not-allowed hover:text-green-600" title="ویرایش"><EditIcon className="w-6 h-6"/></button>}
                                    {permissions.delete && <button onClick={() => !isLocked && deleteAppointment(app.id)} disabled={isLocked} className="text-gray-500 p-1 disabled:opacity-50 disabled:cursor-not-allowed hover:text-red-600" title="حذف"><TrashIcon className="w-6 h-6"/></button>}
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
        <div className="md:hidden space-y-4">
            {listAppointments.map(app => {
                const isLocked = isPastDateTime(app.date, app.time);
                const statusInfo = getStatusLabel(app.status);
                return (
                    <div key={app.id} className={`bg-gray-50 p-4 rounded-lg border ${isLocked ? 'opacity-60' : ''}`}>
                        <div className="flex justify-between items-start mb-2">
                            <p className="font-bold text-lg">{getPatientNames(app.patientIds)}</p>
                            <span className={`px-2 py-1 rounded-full text-xs ${statusInfo.className}`}>
                                {statusInfo.text}
                            </span>
                        </div>
                        <div className="text-sm text-gray-500 mt-2 space-y-1"><p>پزشک: {getDoctorName(app.doctorId)}</p><p>زمان: {formatToJalali(app.date)} - {app.time || 'نامشخص'}</p></div>
                        <div className="mt-4 flex justify-end items-center gap-2">
                            {app.status === 'Scheduled' && !isLocked && <button onClick={() => handleSendManualReminder(app)} className="text-gray-500 hover:text-yellow-600 p-2" title="ارسال یادآوری"><BellIcon className="w-6 h-6"/></button>}
                            {permissions.add && <button onClick={() => handleCopyAppointment(app)} className="text-gray-500 hover:text-blue-600 p-2" title="کپی"><ClipboardCopyIcon className="w-6 h-6" /></button>}
                            {permissions.edit && <button onClick={() => !isLocked && openEditModal(app)} disabled={isLocked} className="text-gray-500 hover:text-green-600 p-2 disabled:opacity-50" title="ویرایش"><EditIcon className="w-6 h-6"/></button>}
                            {permissions.delete && <button onClick={() => !isLocked && deleteAppointment(app.id)} disabled={isLocked} className="text-gray-500 hover:text-red-600 p-2 disabled:opacity-50" title="حذف"><TrashIcon className="w-6 h-6"/></button>}
                        </div>
                    </div>
                );
            })}
        </div>
        {listAppointments.length === 0 && <p className="text-center py-8 text-gray-500">نوبتی یافت نشد.</p>}
    </div>
  );

  const renderWaitingListView = () => (
    <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-right text-sm">
                <thead className="bg-gray-50 border-b">
                    <tr>
                        <th className="p-3 font-semibold">بیمار</th><th className="p-3 font-semibold">پزشک/درمانگر</th><th className="p-3 font-semibold">تاریخ ثبت</th>
                        <th className="p-3 font-semibold">یادداشت</th><th className="p-3 font-semibold">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    {waitingListAppointments.map(app => (
                        <tr key={app.id} className="border-b hover:bg-gray-50">
                            <td className="p-3">{getPatientNames(app.patientIds)}</td>
                            <td className="p-3">
                                {app.doctorId ? getDoctorName(app.doctorId) : (
                                    app.suggestedDoctorIds && app.suggestedDoctorIds.length > 0 ? (
                                        <div className="flex flex-wrap gap-1">
                                            {app.suggestedDoctorIds.map(id => (
                                                <span key={id} className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded-full whitespace-nowrap">
                                                    {doctors.find(d => d.id === id)?.name}
                                                </span>
                                            ))}
                                        </div>
                                    ) : <span className="text-gray-400">-</span>
                                )}
                            </td>
                            <td className="p-3">{app.dateAddedToWaitingList ? formatToJalali(app.dateAddedToWaitingList) : '-'}</td><td className="p-3">{app.notes}</td>
                            <td className="p-3 flex items-center space-x-2 space-x-reverse">
                                {permissions.edit && <button onClick={() => openEditModal(app)} className="text-gray-500 hover:text-green-600 p-1" title="زمان‌بندی نوبت"><EditIcon className="w-6 h-6"/></button>}
                                {permissions.delete && <button onClick={() => deleteAppointment(app.id)} className="text-gray-500 hover:text-red-600 p-1" title="حذف از لیست"><TrashIcon className="w-6 h-6"/></button>}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        <div className="md:hidden space-y-4">
            {waitingListAppointments.map(app => (
                <div key={app.id} className="bg-gray-50 p-4 rounded-lg border">
                    <p className="font-bold text-lg">{getPatientNames(app.patientIds)}</p>
                    <div className="text-sm text-gray-500 mt-2 space-y-1">
                        <p>پزشک/درمانگر: {app.doctorId ? getDoctorName(app.doctorId) : (app.suggestedDoctorIds?.length ? `${app.suggestedDoctorIds.length} درمانگر پیشنهادی` : 'نامشخص')}</p>
                        <p>تاریخ ثبت: {app.dateAddedToWaitingList ? formatToJalali(app.dateAddedToWaitingList) : '-'}</p>
                        {app.notes && <p className="text-gray-700 mt-1 italic">"{app.notes}"</p>}
                    </div>
                    <div className="mt-4 flex justify-end items-center gap-2">
                        {permissions.edit && <button onClick={() => openEditModal(app)} className="text-gray-500 hover:text-green-600 p-2" title="زمان‌بندی نوبت"><EditIcon className="w-6 h-6"/></button>}
                        {permissions.delete && <button onClick={() => deleteAppointment(app.id)} className="text-gray-500 hover:text-red-600 p-2" title="حذف از لیست"><TrashIcon className="w-6 h-6"/></button>}
                    </div>
                </div>
            ))}
        </div>
        {waitingListAppointments.length === 0 && <p className="text-center py-8 text-gray-500">موردی در لیست انتظار یافت نشد.</p>}
    </div>
  );
  
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, appointmentId: string) => {
    if (!permissions.edit) return;
    setDraggingAppointmentId(appointmentId);
    e.dataTransfer.setData('text/plain', String(appointmentId));
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragEnd = () => { setDraggingAppointmentId(null); setDragOverSlot(null); };
  const handleDragOver = (e: React.DragEvent<HTMLTableCellElement>) => e.preventDefault();
  const handleDragEnter = (e: React.DragEvent<HTMLTableCellElement>, doctorId: string, time: string) => { e.preventDefault(); if (permissions.edit && draggingAppointmentId) setDragOverSlot({ doctorId, time }); };
  const handleDragLeave = (e: React.DragEvent<HTMLTableCellElement>) => { e.preventDefault(); setDragOverSlot(null); };

  const handleDrop = (e: React.DragEvent<HTMLTableCellElement>, targetDoctorId: string, targetTime: string) => {
    e.preventDefault();
    if (!permissions.edit || !draggingAppointmentId) return;
    const appointmentToMove = appointments.find(app => app.id === draggingAppointmentId);
    if (appointmentToMove) {
      if (appointments.some(app => app.doctorId === targetDoctorId && app.time === targetTime && app.date === currentDay.toISOString().split('T')[0] && app.id !== draggingAppointmentId)) {
        alert('این جایگاه زمانی برای این پزشک قبلاً رزرو شده است.');
      } else {
        setAppointments(prev => prev.map(app => app.id === draggingAppointmentId ? { ...appointmentToMove, doctorId: targetDoctorId, time: targetTime } : app));
      }
    }
    setDraggingAppointmentId(null);
    setDragOverSlot(null);
  };
  
  const doctorsOnCurrentDay = useMemo(() => {
    const sourceDate = currentDay.toISOString().split('T')[0];
    const doctorIdsOnDay = new Set(appointments.filter(app => app.date === sourceDate).map(app => app.doctorId));
    return doctors.filter(doc => doctorIdsOnDay.has(doc.id)).sort((a,b) => a.name.localeCompare(b.name, 'fa'));
  }, [currentDay, appointments, doctors]);

  const handleDoctorSelectionForCopy = (doctorId: string, isSelected: boolean) => {
    setSelectedDoctorIdsForCopy(prev => {
        if (isSelected) {
            return [...prev, doctorId];
        } else {
            return prev.filter(id => id !== doctorId);
        }
    });
  };

  const handleSelectAllDoctorsForCopy = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
        setSelectedDoctorIdsForCopy(doctorsOnCurrentDay.map(d => d.id));
    } else {
        setSelectedDoctorIdsForCopy([]);
    }
  };

  const handleCopyDay = () => {
    if (!copyTargetDate) {
        alert("لطفا تاریخ مقصد را برای کپی کردن انتخاب کنید.");
        return;
    }
     if (selectedDoctorIdsForCopy.length === 0) {
        alert("لطفا حداقل یک پزشک را برای کپی کردن انتخاب کنید.");
        return;
    }
    
    const sourceDate = currentDay.toISOString().split('T')[0];
    const targetDate = copyTargetDate;

    if (sourceDate === targetDate) {
        alert("تاریخ مبدا و مقصد نمی‌توانند یکسان باشند.");
        return;
    }

    const appointmentsToCopy = appointments.filter(app => 
        app.date === sourceDate && selectedDoctorIdsForCopy.includes(app.doctorId)
    );

    if (appointmentsToCopy.length === 0) {
        alert("هیچ نوبتی برای پزشکان انتخاب شده در این روز وجود ندارد.");
        setIsCopyDayModalOpen(false);
        return;
    }

    const targetDayAppointments = appointments.filter(app => app.date === targetDate);
    if (targetDayAppointments.length > 0) {
        if (!window.confirm(`در تاریخ مقصد ${targetDayAppointments.length.toLocaleString('fa-IR')} نوبت وجود دارد. آیا می‌خواهید نوبت‌های جدید را اضافه کنید؟ این کار ممکن است باعث تداخل شود.`)) {
            return;
        }
    }

    const newAppointments = appointmentsToCopy.map(app => ({
        ...app,
        id: String(Date.now() + Math.random()),
        date: targetDate,
        status: 'Scheduled' as 'Scheduled',
        paymentStatus: 'Unpaid' as 'Unpaid',
        cancellationReason: undefined,
        cancellationFee: undefined,
        reminderSent: undefined,
        reminderDateTime: undefined,
    }));
    
    setAppointments(prev => [...prev, ...newAppointments]);
    alert(`${newAppointments.length.toLocaleString('fa-IR')} نوبت از پزشکان منتخب با موفقیت به تاریخ ${formatToJalali(targetDate)} کپی شد.`);
    setIsCopyDayModalOpen(false);
    setSelectedDoctorIdsForCopy([]);
  };


  const renderDayView = () => {
    const handlePrevDay = () => setCurrentDay(prev => { const d = new Date(prev); d.setDate(prev.getDate() - 1); return d; });
    const handleNextDay = () => setCurrentDay(prev => { const d = new Date(prev); d.setDate(prev.getDate() + 1); return d; });
    const handleToday = () => setCurrentDay(new Date());

    let headerText = '';
    if (typeof jalaali !== 'undefined' && jalaali.toJalaali) {
        const jd = jalaali.toJalaali(currentDay);
        const dayOfWeekName = new Intl.DateTimeFormat('fa-IR', { weekday: 'long' }).format(currentDay);
        headerText = `${dayOfWeekName}، ${jd.jd.toLocaleString('fa-IR')} ${getJalaliMonthName(jd.jm)} ${jd.jy.toLocaleString('fa-IR', { useGrouping: false })}`;
    }

    const timeSlots = Array.from({ length: 56 }, (_, i) => { const hour = 8 + Math.floor(i / 4); const minute = (i % 4) * 15; return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`; });
    const dayAppointments = appointments.filter(app => app.date === currentDay.toISOString().split('T')[0]);
    const sortedDoctors = [...doctors].sort((a,b) => a.name.localeCompare(b.name, 'fa'));

    return (
        <div className="bg-white rounded-lg shadow-md">
            <div className="flex justify-between items-center p-4 border-b flex-wrap gap-2">
                 <div className="flex items-center gap-2">
                    <button onClick={handlePrevDay} className="p-2 rounded-full hover:bg-gray-200"><ChevronRightIcon className="w-5 h-5"/></button>
                    <button onClick={handleNextDay} className="p-2 rounded-full hover:bg-gray-200"><ChevronLeftIcon className="w-5 h-5"/></button>
                    <button onClick={handleToday} className="px-4 py-1.5 border rounded-lg text-sm hover:bg-gray-100">امروز</button>
                    {permissions.add && (
                        <button 
                            onClick={() => {
                                setCopyTargetDate('');
                                setSelectedDoctorIdsForCopy([]);
                                setIsCopyDayModalOpen(true);
                            }} 
                            className="px-4 py-1.5 border rounded-lg text-sm bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100 flex items-center gap-2"
                        >
                            <ClipboardCopyIcon className="w-4 h-4" />
                            کپی نوبت‌های این روز
                        </button>
                    )}
                </div>
                <h3 className="text-xl font-bold text-gray-800">{headerText}</h3>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                    <thead>
                        <tr className="bg-gray-50">
                            <th className="sticky right-0 bg-gray-50 p-2 border-b border-l text-sm font-semibold w-24 z-10">ساعت</th>
                            {sortedDoctors.map(doc => <th key={doc.id} className="p-2 border-b border-l text-sm font-semibold min-w-[150px]">{doc.name}</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {timeSlots.map(time => (
                            <tr key={time}>
                                <td className="sticky right-0 bg-white p-2 border-b border-l text-center text-sm font-mono z-10">{time}</td>
                                {sortedDoctors.map(doc => {
                                    const appsInSlot = dayAppointments.filter(a => a.doctorId === doc.id && a.time === time);
                                    const isDragOverTarget = dragOverSlot?.doctorId === doc.id && dragOverSlot?.time === time;
                                    return (
                                        <td key={doc.id} className={`p-1 border-b border-l align-top min-h-[60px] transition-colors ${isDragOverTarget ? 'bg-green-100' : 'hover:bg-gray-50'}`}
                                          onDragOver={handleDragOver} onDragEnter={(e) => handleDragEnter(e, doc.id, time)} onDragLeave={handleDragLeave} onDrop={(e) => handleDrop(e, doc.id, time)}>
                                            <div className="space-y-1">
                                                {appsInSlot.map(app => {
                                                    const color = getDoctorColorClasses(doc.id); const isLocked = isPastDateTime(app.date, app.time);
                                                    const canEdit = permissions.edit && !isLocked; const isBeingDragged = draggingAppointmentId === app.id;
                                                    return (
                                                        <div key={app.id} draggable={canEdit} onDragStart={(e) => canEdit && handleDragStart(e, app.id)} onDragEnd={handleDragEnd}
                                                            onClick={() => openEditModal(app)} className={`p-2 rounded-lg ${color.bg} ${color.text} border-r-4 ${color.border} h-full ${canEdit || currentUser.role === 'پزشک' ? `cursor-pointer ${color.hoverBg}` : `cursor-default opacity-60`} ${isBeingDragged ? 'opacity-40' : ''}`}>
                                                            <p className="font-bold text-xs">{getPatientNames(app.patientIds)}</p>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {dayAppointments.length === 0 && <p className="text-center text-gray-500 py-8">هیچ نوبتی برای این روز ثبت نشده است.</p>}
            </div>
        </div>
    );
};
  
  const viewTabs = [
    { id: 'day', label: 'روزانه', icon: CalendarDayIcon }, { id: 'week', label: 'هفتگی', icon: CalendarWeekIcon },
    { id: 'month', label: 'ماهانه', icon: CalendarMonthIcon }, { id: 'list', label: 'لیست نوبت‌ها', icon: ListViewIcon }, { id: 'waiting', label: 'لیست انتظار', icon: ClipboardListIcon }
  ];

  return (
    <div>
        <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
            <h2 className="text-2xl sm:text-3xl font-bold">مدیریت نوبت‌دهی</h2>
            {/* FIX: The `openAddModal` function expects an optional string, but the `onClick` event passes a MouseEvent object, causing a type mismatch. Wrapping the call in an arrow function `() => openAddModal()` resolves this by calling the function without any arguments, which is the intended behavior for this button. */}
            {permissions.add && <button onClick={() => openAddModal()} className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition">افزودن نوبت</button>}
        </div>
        <div className="mb-6 border-b border-gray-200"><nav className="-mb-px flex space-x-4 space-x-reverse overflow-x-auto" aria-label="Tabs">
            {viewTabs.map(tab => <button key={tab.id} onClick={() => setViewMode(tab.id as any)}
                className={`whitespace-nowrap py-3 px-4 border-b-2 font-medium text-sm flex items-center gap-2 ${viewMode === tab.id ? 'border-purple-500 text-purple-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                <tab.icon className="w-5 h-5"/>{tab.label}</button>
            )}</nav>
        </div>
        <div>
            {viewMode === 'list' && renderListView()} {viewMode === 'waiting' && renderWaitingListView()} {viewMode === 'day' && renderDayView()}
            {/* FIX: Pass the required onAddClick prop to AppointmentCalendarView to fix missing property error. */}
            {(viewMode === 'month' || viewMode === 'week') && <AppointmentCalendarView viewMode={viewMode} appointments={appointments} patients={patients} doctors={doctors} onAppointmentClick={openEditModal} onAppointmentCopy={handleCopyAppointment} permissions={permissions} currentUser={currentUser} onAddClick={openAddModal} />}
        </div>
        {isModalOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-40 overflow-y-auto" onClick={closeModal}>
                <div className="flex items-center justify-center min-h-screen p-4">
                    <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-2xl" onClick={(e) => e.stopPropagation()}>
                        <h3 className="text-2xl font-bold mb-6">{editingAppointment ? 'ویرایش نوبت' : 'افزودن نوبت جدید'}</h3>
                        <form onSubmit={handleSaveAppointment} className="space-y-4">
                            <div ref={patientSearchRef}><label className="block text-gray-700 mb-2">بیمار(ان)<span className="text-red-500 mr-1">*</span></label>
                                <div className="border rounded-lg p-2 flex flex-wrap gap-2 min-h-[44px]">{formData.patientIds.map(id => (<div key={id} className="bg-gray-200 text-sm rounded-full px-3 py-1 flex items-center gap-2">{getPatientName(id)}<button type="button" onClick={() => handleRemovePatientFromSelection(id)} className="text-red-500 hover:font-bold">&times;</button></div>))}</div>
                                <div className="relative mt-2">
                                    <input type="text" placeholder="جستجوی بیمار برای افزودن..." value={patientSearch} onChange={e => { setPatientSearch(e.target.value); setIsPatientDropdownOpen(true); }} onFocus={() => setIsPatientDropdownOpen(true)} className="w-full p-2 border rounded-lg"/>
                                    {isPatientDropdownOpen && availablePatients.length > 0 && (<div className="absolute z-10 w-full bg-white border rounded-lg mt-1 max-h-48 overflow-y-auto shadow-lg">{availablePatients.map(p => (<div key={p.id} onClick={() => handleAddPatientToSelection(p.id)} className="p-2 hover:bg-gray-100 cursor-pointer">{p.name}</div>))}</div>)}
                                </div>
                            </div>
                            <div><label className="block text-gray-700 mb-2">پزشک<span className="text-red-500 mr-1">*</span></label><select name="doctorId" value={formData.doctorId} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required={formData.status !== 'Waiting'}><option value="">انتخاب پزشک</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4"><JalaliDatePicker label="تاریخ" value={formData.date} onChange={(date) => handleDateChange('date', date)} required/><div><label className="block text-gray-700 mb-1">ساعت <span className="text-gray-500 text-xs">(اختیاری)</span></label><CustomTimePicker value={formData.time || ''} onChange={(newTime) => handleDateChange('time', newTime)}/></div></div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div><label className="block text-gray-700 mb-2">وضعیت نوبت<span className="text-red-500 mr-1">*</span></label><select name="status" value={formData.status} onChange={handleInputChange} className="w-full p-2 border rounded-lg"><option value="Scheduled">زمان‌بندی شده</option><option value="Completed">تکمیل شده</option><option value="Cancelled">لغو شده</option><option value="Waiting">در انتظار</option></select></div>
                                {formData.status === 'Cancelled' && (<div><label className="block text-gray-700 mb-2">دلیل لغو<span className="text-red-500 mr-1">*</span></label><VoiceEnabledTextarea name="cancellationReason" value={formData.cancellationReason || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required rows={2} /></div>)}
                            </div>
                            {formData.status === 'Waiting' && (
                                <div className="p-4 border rounded-lg bg-yellow-50 space-y-2">
                                    <label className="block text-gray-700 font-semibold">درمانگران پیشنهادی (توسط پزشک داخلی)</label>
                                    <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
                                        {doctors.map(doc => (
                                            <label key={doc.id} className="flex items-center gap-2 p-1.5 bg-white border rounded cursor-pointer hover:bg-gray-50">
                                                <input
                                                    type="checkbox"
                                                    checked={formData.suggestedDoctorIds?.includes(doc.id)}
                                                    onChange={() => handleSuggestedDoctorsChange(doc.id)}
                                                    className="w-4 h-4 text-blue-600 rounded"
                                                />
                                                <span className="text-sm">{doc.name}</span>
                                            </label>
                                        ))}
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">این پیشنهادها به منشی کمک می‌کند تا درمانگر مناسب را انتخاب کند.</p>
                                </div>
                            )}
                            {formData.status === 'Cancelled' && (<div className="p-4 border rounded-lg bg-red-50 space-y-4">
                                <label htmlFor="charge-cancellation" className="flex items-center cursor-pointer"><input type="checkbox" id="charge-cancellation" className="w-5 h-5 ml-3 rounded text-red-600 focus:ring-red-500 border-gray-300" checked={cancellationFeeData.charge} onChange={(e) => setCancellationFeeData(p => ({...p, charge: e.target.checked}))}/><span className="font-semibold text-gray-700">ثبت هزینه کنسلی</span></label>
                                {cancellationFeeData.charge && (<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div><label className="block text-gray-700 mb-1">مبلغ جریمه*</label><input type="text" value={cancellationFeeData.amount} onChange={e => setCancellationFeeData(p => ({...p, amount: e.target.value}))} className="w-full p-2 border rounded-lg bg-white" /></div>
                                    <div><label className="block text-gray-700 mb-1">روش پرداخت</label><select value={cancellationFeeData.paymentMethod} onChange={e => setCancellationFeeData(p => ({...p, paymentMethod: e.target.value}))} className="w-full p-2 border rounded-lg"><option value="نقد">نقد</option><option value="کارت به کارت">کارت به کارت</option><option value="پوز">پوز</option></select></div>
                                    <div><label className="block text-gray-700 mb-1">به حساب</label><select value={cancellationFeeData.accountDebited} onChange={e => setCancellationFeeData(p => ({...p, accountDebited: e.target.value}))} className="w-full p-2 border rounded-lg"><option value="">انتخاب</option>{bankAccounts.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}</select></div>
                                </div>)}
                            </div>)}
                            {formData.status === 'Completed' && (
                                <div className="p-4 border rounded-lg bg-gray-50 space-y-4">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div><label className="block text-gray-700 mb-2">مدت جلسه (دقیقه)<span className="text-red-500 mr-1">*</span></label><select name="sessionDuration" value={formData.sessionDuration} onChange={handleInputChange} className="w-full p-2 border rounded-lg"><option value="15">۱۵ دقیقه</option><option value="30">30 دقیقه</option><option value="45">45 دقیقه</option><option value="60">60 دقیقه (۱ ساعت)</option><option value="90">90 دقیقه (۱.۵ ساعت)</option><option value="120">120 دقیقه (۲ ساعت)</option></select></div>
                                        <div><label className="block text-gray-700 mb-2">هزینه جلسه (تومان)<span className="text-red-500 mr-1">*</span></label><input type="text" name="sessionFee" value={formatNumberWithCommas(formData.sessionFee || '')} onChange={handleInputChange} className="w-full p-2 border rounded-lg bg-white" /></div>
                                        <div><label className="block text-gray-700 mb-2">وضعیت پرداخت<span className="text-red-500 mr-1">*</span></label><select name="paymentStatus" value={formData.paymentStatus} onChange={handleInputChange} className="w-full p-2 border rounded-lg"><option value="Unpaid">پرداخت نشده</option><option value="Paid">پرداخت شده</option></select></div>
                                        {formData.paymentStatus === 'Paid' && (<div><label className="block text-gray-700 mb-2">روش پرداخت<span className="text-red-500 mr-1">*</span></label><select name="paymentMethod" value={formData.paymentMethod || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required><option value="" disabled>انتخاب روش پرداخت</option><option value="پوز">پوز</option><option value="کارت به کارت">کارت به کارت</option><option value="نقد">نقد</option></select></div>)}
                                    </div>
                                </div>
                            )}
                             {currentUser.role === 'پزشک' && formData.status === 'Completed' && currentRecord ? (
                                <div className="p-4 border rounded-lg bg-gray-50/50">
                                    <h4 className="font-semibold text-gray-700 mb-3 -mt-1 flex items-center gap-2"><DocumentReportIcon className="w-5 h-5"/> پرونده جلسه (محرمانه)</h4>
                                    <div className="space-y-3">
                                        <div><label className="block text-sm font-medium text-gray-600 mb-1">شرح حال و طرح درمان</label><VoiceEnabledTextarea value={currentRecord.note || ''} onChange={(e) => handleRecordChange('note', e.target.value)} rows={6} placeholder="شرح حال، مشاهدات و طرح درمان را وارد کنید..."/></div>
                                    </div>
                                </div>
                            ) : currentUser.role !== 'پزشک' && formData.status === 'Completed' && (
                                <div className="p-4 border rounded-lg bg-gray-100 text-center text-sm text-gray-500">
                                    پرونده بالینی این جلسه توسط پزشک ثبت می‌شود و محرمانه است.
                                </div>
                            )}
                            <div>
                                <label className="block text-gray-700 mb-2">یادداشت داخلی (اختیاری)</label>
                                <VoiceEnabledTextarea name="notes" value={formData.notes || ''} onChange={handleInputChange} rows={2}/>
                            </div>
                            <div className="border-t pt-4 mt-4">
                                <label htmlFor="custom-reminder-toggle" className="flex items-center cursor-pointer"><input type="checkbox" id="custom-reminder-toggle" className="w-5 h-5 ml-3 rounded text-purple-600 focus:ring-purple-500 border-gray-300" checked={isCustomReminderEnabled} onChange={(e) => setIsCustomReminderEnabled(e.target.checked)}/><span className="font-semibold text-gray-700">تنظیم یادآوری سفارشی</span></label>
                                {isCustomReminderEnabled && (<div className="mt-4 p-4 bg-gray-50 rounded-lg grid grid-cols-1 md:grid-cols-2 gap-4 border"><JalaliDatePicker label="تاریخ یادآوری" value={reminderDate} onChange={setReminderDate} required/><div><label className="block text-gray-700 mb-1">ساعت یادآوری<span className="text-red-500 mr-1">*</span></label><CustomTimePicker value={reminderTime} onChange={setReminderTime} required={isCustomReminderEnabled}/></div></div>)}
                            </div>
                            <div className="flex justify-between items-center mt-6">
                                <div>{editingAppointment && editingAppointment.status === 'Scheduled' && !isPastDateTime(editingAppointment.date, editingAppointment.time) && (<button type="button" onClick={() => handleSendManualReminder(editingAppointment)} className="bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 flex items-center gap-2 transition-colors" title="ارسال یادآوری فوری برای این نوبت"><BellIcon className="w-5 h-5" /><span>ارسال یادآوری</span></button>)}</div>
                                <div className="flex items-center gap-2"><button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">لغو</button><button type="submit" className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">ذخیره</button></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )}
        
        {isDeleteModalOpen && deletingAppointment && (
            <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
              <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">حذف از لیست انتظار</h3>
                <p className="text-gray-600 mb-6">
                  برای حذف نوبت بیمار <span className="font-semibold">{getPatientNames(deletingAppointment.patientIds)}</span> از لیست انتظار، لطفا دلیل آن را وارد کنید. این نوبت به وضعیت "لغو شده" تغییر خواهد کرد.
                </p>
                <div>
                  <label htmlFor="deleteReason" className="block text-gray-700 font-semibold mb-2">دلیل حذف (اجباری)</label>
                  <textarea
                    id="deleteReason"
                    value={deleteReason}
                    onChange={(e) => setDeleteReason(e.target.value)}
                    className="w-full p-2 border rounded-lg"
                    rows={3}
                    placeholder="مثال: بیمار نوبت جدید دریافت کرد."
                    autoFocus
                  />
                </div>
                <div className="flex justify-end mt-6 gap-3">
                  <button type="button" onClick={closeDeleteModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">انصراف</button>
                  <button
                    type="button"
                    onClick={handleConfirmRemoveFromWaitingList}
                    disabled={!deleteReason.trim()}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    حذف از لیست
                  </button>
                </div>
              </div>
            </div>
        )}
        {isCopyDayModalOpen && (
             <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
                <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                    <h3 className="text-xl font-bold mb-4">کپی نوبت‌های روز</h3>
                    <p className="text-gray-600 mb-6">
                        نوبت‌های پزشکان منتخب از تاریخ <span className="font-semibold text-blue-600">{formatToJalali(currentDay.toISOString())}</span> به تاریخ مقصد کپی خواهند شد.
                    </p>
                    <JalaliDatePicker label="تاریخ مقصد" value={copyTargetDate} onChange={setCopyTargetDate} required />

                    <div className="mt-6">
                        <h4 className="font-semibold text-gray-700 mb-3">پزشکان مورد نظر را برای کپی انتخاب کنید</h4>
                        {doctorsOnCurrentDay.length > 0 ? (
                            <div className="space-y-2 max-h-48 overflow-y-auto border p-3 rounded-lg bg-gray-50">
                                <label className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 cursor-pointer font-bold">
                                    <input 
                                        type="checkbox" 
                                        className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                                        onChange={handleSelectAllDoctorsForCopy}
                                        checked={doctorsOnCurrentDay.length > 0 && selectedDoctorIdsForCopy.length === doctorsOnCurrentDay.length}
                                    />
                                    انتخاب همه
                                </label>
                                {doctorsOnCurrentDay.map(doc => (
                                    <label key={doc.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 cursor-pointer">
                                        <input 
                                            type="checkbox"
                                            value={doc.id}
                                            className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                                            checked={selectedDoctorIdsForCopy.includes(doc.id)}
                                            onChange={(e) => handleDoctorSelectionForCopy(doc.id, e.target.checked)}
                                        />
                                        {doc.name}
                                    </label>
                                ))}
                            </div>
                        ) : (
                            <p className="text-center text-gray-500 py-4">پزشکی در این روز نوبت ندارد.</p>
                        )}
                    </div>
                    
                    <div className="flex justify-end mt-8 gap-3">
                        <button type="button" onClick={() => setIsCopyDayModalOpen(false)} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">انصراف</button>
                        <button 
                            type="button" 
                            onClick={handleCopyDay} 
                            disabled={!copyTargetDate || selectedDoctorIdsForCopy.length === 0}
                            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                          کپی نوبت‌ها
                        </button>
                    </div>
                </div>
             </div>
        )}
    </div>
  );
};

// FIX: Corrected the export name to match the component name.
export default AppointmentManagement;