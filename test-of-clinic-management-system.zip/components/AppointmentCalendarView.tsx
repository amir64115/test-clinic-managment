import React, { useState, useMemo, useEffect } from 'react';
import type { Appointment, Patient, Doctor, PermissionSet, Personnel } from '../types';
import { ChevronLeftIcon, ChevronRightIcon, ClipboardCopyIcon, EditIcon } from './icons/Icons';
import { getMonthMatrix, getWeekDays, isSameDay, getJalaliMonthName, isPastDateTime } from '../utils/dateUtils';

// Declare the jalaali library loaded via script tag
declare var jalaali: any;

const DOCTOR_COLOR_PALETTE = [
  { bg: 'bg-blue-100', text: 'text-blue-800', hoverBg: 'hover:bg-blue-200' },
  { bg: 'bg-green-100', text: 'text-green-800', hoverBg: 'hover:bg-green-200' },
  { bg: 'bg-purple-100', text: 'text-purple-800', hoverBg: 'hover:bg-purple-200' },
  { bg: 'bg-yellow-100', text: 'text-yellow-800', hoverBg: 'hover:bg-yellow-200' },
  { bg: 'bg-pink-100', text: 'text-pink-800', hoverBg: 'hover:bg-pink-200' },
  { bg: 'bg-indigo-100', text: 'text-indigo-800', hoverBg: 'hover:bg-indigo-200' },
  { bg: 'bg-red-100', text: 'text-red-800', hoverBg: 'hover:bg-red-200' },
  { bg: 'bg-teal-100', text: 'text-teal-800', hoverBg: 'hover:bg-teal-200' },
];

const getDoctorColorClasses = (doctorId: string) => {
  if (!doctorId) return DOCTOR_COLOR_PALETTE[0];
  const numericId = parseInt(doctorId.replace(/[^0-9]/g, '').slice(-3)) || 0;
  const colorIndex = numericId % DOCTOR_COLOR_PALETTE.length;
  return DOCTOR_COLOR_PALETTE[colorIndex];
};


interface AppointmentCalendarViewProps {
  viewMode: 'week' | 'month';
  appointments: Appointment[];
  patients: Patient[];
  doctors: Doctor[];
  onAppointmentClick: (appointment: Appointment) => void;
  onAppointmentCopy: (appointment: Appointment) => void;
  permissions: PermissionSet;
  currentUser: Personnel;
  onAddClick: (date: string) => void;
}

const WEEK_DAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

const toDateKey = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

export const AppointmentCalendarView: React.FC<AppointmentCalendarViewProps> = ({ 
    viewMode, 
    appointments, 
    patients, 
    doctors,
    onAppointmentClick,
    onAppointmentCopy,
    permissions,
    currentUser,
    onAddClick,
}) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isJalaaliLoaded, setIsJalaaliLoaded] = useState(typeof jalaali !== 'undefined');
  const [popover, setPopover] = useState<{ x: number, y: number, appointment: Appointment } | null>(null);
  const popoverRef = React.useRef<HTMLDivElement>(null);

  const isAdmin = useMemo(() => ['مدیر', 'مدیریت'].includes(currentUser.role), [currentUser.role]);

  useEffect(() => {
    if (isJalaaliLoaded) return;
    const interval = setInterval(() => {
      if (typeof jalaali !== 'undefined' && jalaali.toJalaali) {
        setIsJalaaliLoaded(true);
        clearInterval(interval);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [isJalaaliLoaded]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
            setPopover(null);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);


  const getPatientNames = (ids: string[]): string => {
    if (!ids || ids.length === 0) return 'نامشخص';
    const patientNames = ids.map(id => patients.find(p => p.id === id)?.name || `بیمار #${id}`);
    if (patientNames.length > 1) {
      return `${patientNames[0]} و دیگران`;
    }
    return patientNames[0];
  };

  const appointmentsByDate = useMemo(() => {
    const map = new Map<string, Appointment[]>();
    appointments.forEach(app => {
        const dateKey = app.date; // YYYY-MM-DD
        if (!map.has(dateKey)) {
            map.set(dateKey, []);
        }
        map.get(dateKey)!.push(app);
    });
    // Sort appointments within each day by time
    map.forEach(dayAppointments => {
        dayAppointments.sort((a, b) => (a.time || '00:00').localeCompare(b.time || '00:00'));
    });
    return map;
  }, [appointments]);

  const handlePrev = () => {
    setCurrentDate(prevDate => {
      if (viewMode === 'month') {
        const jd = jalaali.toJalaali(prevDate);
        const newJm = jd.jm === 1 ? 12 : jd.jm - 1;
        const newJy = jd.jm === 1 ? jd.jy - 1 : jd.jy;
        const gd = jalaali.toGregorian(newJy, newJm, 15);
        return new Date(gd.gy, gd.gm - 1, gd.gd);
      } else { // week
        const newDate = new Date(prevDate);
        newDate.setDate(newDate.getDate() - 7);
        return newDate;
      }
    });
  };

  const handleNext = () => {
    setCurrentDate(prevDate => {
      if (viewMode === 'month') {
        const jd = jalaali.toJalaali(prevDate);
        const newJm = jd.jm === 12 ? 1 : jd.jm + 1;
        const newJy = jd.jm === 12 ? jd.jy + 1 : jd.jy;
        const gd = jalaali.toGregorian(newJy, newJm, 15);
        return new Date(gd.gy, gd.gm - 1, gd.gd);
      } else { // week
        const newDate = new Date(prevDate);
        newDate.setDate(newDate.getDate() + 7);
        return newDate;
      }
    });
  };
  
  const handleToday = () => {
    setCurrentDate(new Date());
  }
  
  const headerText = useMemo(() => {
    if (!isJalaaliLoaded) return '';
    const jd = jalaali.toJalaali(currentDate);

    if (viewMode === 'month') {
        return `${getJalaliMonthName(jd.jm)} ${jd.jy.toLocaleString('fa-IR', { useGrouping: false })}`;
    }
    
    const week = getWeekDays(currentDate);
    const startOfWeek = week[0];
    const endOfWeek = week[6];
    const startJd = jalaali.toJalaali(startOfWeek);
    const endJd = jalaali.toJalaali(endOfWeek);

    const startYearStr = startJd.jy.toLocaleString('fa-IR', { useGrouping: false });
    const endYearStr = endJd.jy.toLocaleString('fa-IR', { useGrouping: false });

    const startDayStr = startJd.jd.toLocaleString('fa-IR');
    const endDayStr = endJd.jd.toLocaleString('fa-IR');

    const startMonthName = getJalaliMonthName(startJd.jm);
    const endMonthName = getJalaliMonthName(endJd.jm);

    if (startJd.jy !== endJd.jy) {
      return `هفته از ${startDayStr} ${startMonthName} ${startYearStr} تا ${endDayStr} ${endMonthName} ${endYearStr}`;
    }

    if (startJd.jm !== endJd.jm) {
      return `هفته از ${startDayStr} ${startMonthName} تا ${endDayStr} ${endMonthName} ${startYearStr}`;
    }

    return `هفته ${startDayStr} تا ${endDayStr} ${startMonthName} ${startYearStr}`;
  }, [currentDate, viewMode, isJalaaliLoaded]);


  const renderMonthView = () => {
    const monthMatrix = getMonthMatrix(currentDate);
    
    return (
      <>
        {/* Desktop View */}
        <div className="hidden md:grid grid-cols-7 border-r border-t border-gray-200">
            {WEEK_DAYS.map(day => (
              <div key={day} className="p-2 text-center font-semibold text-sm border-l border-b bg-gray-50">{day}</div>
            ))}
            {monthMatrix.flat().map((dayInfo, index) => {
              const { date, isCurrentMonth, jalaali: dayJalaali } = dayInfo;
              const dateKey = toDateKey(date);
              const dayAppointments = appointmentsByDate.get(dateKey) || [];
              const isToday = isSameDay(date, new Date());
              
              return (
                <div 
                  key={index} 
                  className={`min-h-[120px] p-2 border-l border-b relative group ${isCurrentMonth ? 'bg-white' : 'bg-gray-50'}`}
                  onDoubleClick={() => permissions.add && onAddClick(dateKey)}
                >
                  <span className={`text-sm ${isCurrentMonth ? 'text-gray-800' : 'text-gray-400'} ${isToday ? 'bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center font-bold' : ''}`}>
                    {dayJalaali.jd.toLocaleString('fa-IR')}
                  </span>
                  <div className="mt-2 space-y-1">
                    {dayAppointments.map(app => {
                        const colorClasses = getDoctorColorClasses(app.doctorId);
                        const canInteract = permissions.edit && (isAdmin || !['Completed', 'Cancelled'].includes(app.status));
                        
                        return (
                            <div 
                                key={app.id} 
                                className={`group/item relative p-1 rounded ${colorClasses.bg} ${colorClasses.text} text-xs transition-colors ${!canInteract ? 'opacity-60 cursor-default' : `cursor-pointer ${colorClasses.hoverBg}`}`}
                            >
                                <span onClick={() => canInteract && onAppointmentClick(app)} className="block w-full">
                                    <span className="font-semibold">{app.time}</span> - {getPatientNames(app.patientIds)} ({app.sessionDuration || '?'} دقیقه)
                                </span>
                                {canInteract && (
                                    <div className="absolute top-0 left-0 flex items-center justify-center p-1 opacity-0 group-hover/item:opacity-100 transition-opacity">
                                        {permissions.add && <button onClick={(e) => { e.stopPropagation(); onAppointmentCopy(app); }} className="p-1 rounded-full bg-white/50 hover:bg-white" title="کپی"><ClipboardCopyIcon className="w-4 h-4 text-blue-700"/></button>}
                                    </div>
                                )}
                            </div>
                        );
                    })}
                  </div>
                </div>
              );
            })}
        </div>

        {/* Mobile View */}
        <div className="block md:hidden border-t border-gray-200">
          {monthMatrix.flat().filter(d => d.isCurrentMonth).map((dayInfo, index) => {
            const { date, jalaali: dayJalaali } = dayInfo;
            const dateKey = toDateKey(date);
            const dayAppointments = appointmentsByDate.get(dateKey) || [];
            const isToday = isSameDay(date, new Date());
            const dayOfWeekName = WEEK_DAYS[(date.getDay() + 1) % 7];

            return (
              <div key={index} className="border-b p-3">
                <div className={`flex items-center gap-2 mb-3 ${isToday ? 'text-blue-600' : 'text-gray-800'}`}>
                  <span className={`text-lg font-bold ${isToday ? 'bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center' : ''}`}>
                    {dayJalaali.jd.toLocaleString('fa-IR')}
                  </span>
                  <span className="font-semibold">{dayOfWeekName}</span>
                </div>
                <div className="space-y-2 pl-4">
                  {dayAppointments.length > 0 ? dayAppointments.map(app => {
                    const colorClasses = getDoctorColorClasses(app.doctorId);
                    const canInteract = permissions.edit && (isAdmin || !['Completed', 'Cancelled'].includes(app.status));
                    return (
                        <div key={app.id} className={`group/item relative p-2 rounded-lg ${colorClasses.bg} ${colorClasses.text} transition-colors ${!canInteract ? 'opacity-60 cursor-default' : `cursor-pointer ${colorClasses.hoverBg}`}`}>
                            <div onClick={() => canInteract && onAppointmentClick(app)}>
                                <p className="font-bold text-sm">{app.time}</p>
                                <p className="text-xs">{getPatientNames(app.patientIds)} ({app.sessionDuration || '?'} دقیقه)</p>
                                <p className={`text-xs ${colorClasses.text} opacity-80`}>{doctors.find(d=>d.id===app.doctorId)?.name}</p>
                            </div>
                            {canInteract && (
                                <div className="absolute top-1 left-1 flex items-center justify-center p-1 opacity-0 group-hover/item:opacity-100 transition-opacity">
                                    {permissions.add && <button onClick={(e) => { e.stopPropagation(); onAppointmentCopy(app); }} className="p-1 rounded-full bg-white/50 hover:bg-white" title="کپی"><ClipboardCopyIcon className="w-4 h-4 text-blue-700"/></button>}
                                </div>
                            )}
                        </div>
                    );
                  }) : <p className="text-xs text-gray-400">نوبتی ثبت نشده است.</p>}
                </div>
              </div>
            );
          })}
        </div>
      </>
    );
  };
  
  const renderWeekView = () => {
    const weekDays = getWeekDays(currentDate);

    return (
        <div className="grid grid-cols-1 md:grid-cols-7 border-t border-r border-gray-200">
            {weekDays.map((day, index) => {
                const dateKey = toDateKey(day);
                const dayAppointments = appointmentsByDate.get(dateKey) || [];
                const isToday = isSameDay(day, new Date());
                const jalaaliDay = jalaali.toJalaali(day);

                return (
                    <div key={index} className="border-l border-b" onDoubleClick={() => permissions.add && onAddClick(dateKey)}>
                        <div className={`p-2 text-center font-semibold text-sm border-b-2 ${isToday ? 'border-blue-600' : 'border-gray-200'} bg-gray-50`}>
                            <p>{WEEK_DAYS[index]}</p>
                            <p className="text-gray-500 font-normal">{`${jalaaliDay.jd.toLocaleString('fa-IR')} ${getJalaliMonthName(jalaaliDay.jm)}`}</p>
                        </div>
                        <div className="p-2 min-h-[200px] space-y-2">
                            {dayAppointments.length > 0 ? dayAppointments.map(app => {
                                const colorClasses = getDoctorColorClasses(app.doctorId);
                                const canInteract = permissions.edit && (isAdmin || !['Completed', 'Cancelled'].includes(app.status));
                                return (
                                    <div 
                                        key={app.id}
                                        className={`group/item relative p-2 rounded-lg ${colorClasses.bg} ${colorClasses.text} transition-colors ${!canInteract ? 'opacity-60 cursor-default' : `cursor-pointer ${colorClasses.hoverBg}`}`}
                                    >
                                        <div onClick={() => canInteract && onAppointmentClick(app)}>
                                            <p className="font-bold text-sm">{app.time}</p>
                                            <p className="text-xs">{getPatientNames(app.patientIds)} ({app.sessionDuration || '?'} دقیقه)</p>
                                            <p className={`text-xs ${colorClasses.text} opacity-80`}>{doctors.find(d=>d.id===app.doctorId)?.name}</p>
                                        </div>
                                         {canInteract && (
                                            <div className="absolute top-1 left-1 flex items-center justify-center p-1 opacity-0 group-hover/item:opacity-100 transition-opacity">
                                                {permissions.add && <button onClick={(e) => { e.stopPropagation(); onAppointmentCopy(app); }} className="p-1 rounded-full bg-white/50 hover:bg-white" title="کپی"><ClipboardCopyIcon className="w-4 h-4 text-blue-700"/></button>}
                                            </div>
                                        )}
                                    </div>
                                );
                            }) : (
                                <p className="text-center text-xs text-gray-400 mt-4">نوبتی نیست</p>
                            )}
                        </div>
                    </div>
                )
            })}
        </div>
    )
  }

  if (!isJalaaliLoaded) {
    return <div className="text-center p-8 text-gray-500">در حال بارگذاری تقویم...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
            <button onClick={handlePrev} className="p-2 rounded-full hover:bg-gray-200"><ChevronRightIcon className="w-5 h-5"/></button>
            <button onClick={handleNext} className="p-2 rounded-full hover:bg-gray-200"><ChevronLeftIcon className="w-5 h-5"/></button>
            <button onClick={handleToday} className="px-4 py-1.5 border rounded-lg text-sm hover:bg-gray-100">امروز</button>
        </div>
        <h3 className="text-xl font-bold text-gray-800">{headerText}</h3>
      </div>
      {viewMode === 'month' ? renderMonthView() : renderWeekView()}
      
    </div>
  );
};