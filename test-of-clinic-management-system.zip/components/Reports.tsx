import React, { useMemo, useState, useEffect, useRef } from 'react';
import type { Appointment, Patient, Doctor, Transaction, InsuranceProvider, BankAccount, Personnel, CostCategory } from '../types';
import { JalaliDatePicker, TrendingUpIcon, TrendingDownIcon, ChartBarIcon, FilterIcon, FinancialIcon, DoctorsIcon, ChevronDownIcon, ClipboardListIcon, UsersIcon, DownloadIcon, ShieldCheckIcon, UserCircleIcon } from './icons/Icons';
import { formatToJalali } from '../utils/dateUtils';
import { exportToExcel } from '../utils/exportToExcel';
import { areNamesEquivalent } from '../utils/textUtils';

interface ReportsProps {
  transactions: Transaction[];
  patients: Patient[];
  doctors: Doctor[];
  appointments: Appointment[];
  insuranceProviders: InsuranceProvider[];
  bankAccounts: BankAccount[];
  personnel: Personnel[];
  currentUser: Personnel;
  costCategories: CostCategory[];
}

type ReportViewType = 'general' | 'income' | 'expenses' | 'expenseCategories' | 'referralSources' | 'doctor' | 'receivables' | 'insuranceClaims' | 'therapistPerformance' | 'patientRetention';

const getInitialFilters = (isSecretary: boolean) => {
    const today = new Date().toISOString().split('T')[0];
    
    if (isSecretary) {
        return {
            doctorId: 'all' as 'all' | string,
            status: 'all' as 'all' | Appointment['status'],
            startDate: today,
            endDate: today,
            paymentMethod: 'all' as 'all' | Transaction['paymentMethod'],
            bankAccount: 'all' as 'all' | string,
        };
    }

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 29); // 30 days including today
    
    return {
        doctorId: 'all' as 'all' | string,
        status: 'all' as 'all' | Appointment['status'],
        startDate: startDate.toISOString().split('T')[0],
        endDate: endDate.toISOString().split('T')[0],
        paymentMethod: 'all' as 'all' | Transaction['paymentMethod'],
        bankAccount: 'all' as 'all' | string,
    };
};

const Reports: React.FC<ReportsProps> = ({ transactions, patients, doctors, appointments, insuranceProviders, bankAccounts, personnel, currentUser, costCategories }) => {
    const isSecretary = currentUser.role === 'منشی';
    const [filters, setFilters] = useState(getInitialFilters(isSecretary));
    const [reportView, setReportView] = useState<ReportViewType>('general');
    const [expandedPatientId, setExpandedPatientId] = useState<string | null>(null);
    const [expandedProviderId, setExpandedProviderId] = useState<string | null>(null);
    const [isViewDropdownOpen, setIsViewDropdownOpen] = useState(false);
    const viewDropdownRef = useRef<HTMLDivElement>(null);
    
    const [selectedStatusDetail, setSelectedStatusDetail] = useState<Appointment['status'] | null>(null);

    const isMedicalStaff = ['پزشک', 'درمانگر'].includes(currentUser.role);
    const isManager = ['مدیر', 'مدیریت'].includes(currentUser.role);

    useEffect(() => {
        if (isMedicalStaff) {
            const doctorRecord = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
            if (doctorRecord && filters.doctorId !== doctorRecord.id) {
                setFilters(prev => ({ ...prev, doctorId: doctorRecord.id }));
                setReportView('doctor');
            }
        }
        // Force secretary to income view and correct dates
        if (isSecretary) {
            if (!['income'].includes(reportView)) {
                setReportView('income');
            }
            const today = new Date().toISOString().split('T')[0];
            if (filters.startDate !== today || filters.endDate !== today) {
                 setFilters(prev => ({ ...prev, startDate: today, endDate: today }));
            }
        }
    }, [isMedicalStaff, currentUser.name, doctors, filters.doctorId, isSecretary, reportView, filters.startDate, filters.endDate]);

    useEffect(() => {
        if (filters.doctorId === 'all' && reportView === 'doctor' && !isMedicalStaff) {
            setReportView('general');
        }
    }, [filters.doctorId, reportView, isMedicalStaff]);
    
     useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (viewDropdownRef.current && !viewDropdownRef.current.contains(event.target as Node)) {
                setIsViewDropdownOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };
    
    const handleDateChange = (name: 'startDate' | 'endDate', date: string) => {
        setFilters(prev => ({...prev, [name]: date}));
    };

    const handleResetFilters = () => {
        if (isMedicalStaff) {
            const doctorRecord = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
            const { doctorId, ...rest } = getInitialFilters(false);
            setFilters(prev => ({...prev, ...rest, doctorId: doctorRecord ? doctorRecord.id : 'all'}));
            setReportView('doctor');
        } else if (isSecretary) {
             setFilters(getInitialFilters(true));
             setReportView('income');
        } else {
            setFilters(getInitialFilters(false));
            setReportView('general');
        }
        setSelectedStatusDetail(null);
    };

    const filteredData = useMemo(() => {
        const start = filters.startDate ? new Date(filters.startDate) : null;
        if (start) start.setHours(0, 0, 0, 0);

        const end = filters.endDate ? new Date(filters.endDate) : null;
        if (end) end.setHours(23, 59, 59, 999);

        const filteredAppointments = appointments.filter(app => {
            if (filters.doctorId !== 'all' && app.doctorId !== filters.doctorId) return false;
            if (filters.status !== 'all' && app.status !== filters.status) return false;
            
            const appDate = new Date(app.date);
            if (start && appDate < start) return false;
            if (end && appDate > end) return false;
            
            return true;
        });

        const filteredTransactions = transactions.filter(t => {
            const transactionDate = new Date(t.date);
            if (start && transactionDate < start) return false;
            if (end && transactionDate > end) return false;
            
            if (filters.doctorId !== 'all' && t.doctorId && t.doctorId !== filters.doctorId) return false;
            
            if (t.type === 'درآمد') {
                if (filters.paymentMethod !== 'all' && t.paymentMethod !== filters.paymentMethod) {
                    return false;
                }
                if (filters.bankAccount !== 'all' && t.accountDebited !== filters.bankAccount) {
                    return false;
                }
            }

            return true;
        });
        
        return { appointments: filteredAppointments, transactions: filteredTransactions };

    }, [filters, appointments, transactions]);

    const financialSummary = useMemo(() => {
        const income = filteredData.transactions
            .filter(t => t.type === 'درآمد')
            .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
        const expense = filteredData.transactions
            .filter(t => t.type === 'هزینه')
            .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
        const profit = income - expense;
        return { income, expense, profit };
    }, [filteredData.transactions]);
    
    const therapistPerformanceData = useMemo(() => {
        const performanceMap = new Map<string, number>();
        filteredData.appointments.forEach(app => {
            if (app.status === 'Completed') {
                performanceMap.set(app.doctorId, (performanceMap.get(app.doctorId) || 0) + 1);
            }
        });
        return Array.from(performanceMap.entries()).map(([doctorId, count]) => ({
            name: doctors.find(d => d.id === doctorId)?.name || 'نامشخص',
            count
        })).sort((a, b) => b.count - a.count);
    }, [filteredData.appointments, doctors]);

    const patientRetentionData = useMemo(() => {
        const patientVisitCounts = new Map<string, { count: number, lastDoctorId: string }>();
        filteredData.appointments.forEach(app => {
            if (app.status === 'Completed') {
                app.patientIds.forEach(pid => {
                    const current = patientVisitCounts.get(pid) || { count: 0, lastDoctorId: '' };
                    patientVisitCounts.set(pid, { count: current.count + 1, lastDoctorId: app.doctorId });
                });
            }
        });
        const buckets = { '1': 0, '2-5': 0, '6-10': 0, '11-15': 0, '>15': 0 };
        const singleVisitPatients: { patientName: string, doctorName: string }[] = [];
        patientVisitCounts.forEach((data, patientId) => {
            const count = data.count;
            if (count === 1) {
                buckets['1']++;
                singleVisitPatients.push({
                    patientName: patients.find(p => p.id === patientId)?.name || 'نامشخص',
                    doctorName: doctors.find(d => d.id === data.lastDoctorId)?.name || 'نامشخص'
                });
            } else if (count >= 2 && count <= 5) buckets['2-5']++;
            else if (count >= 6 && count <= 10) buckets['6-10']++;
            else if (count >= 11 && count <= 15) buckets['11-15']++;
            else buckets['>15']++;
        });
        const totalPatients = patientVisitCounts.size;
        const distribution = Object.entries(buckets).map(([range, count]) => ({
            range,
            count,
            percentage: totalPatients > 0 ? (count / totalPatients) * 100 : 0
        }));
        return { distribution, singleVisitPatients };
    }, [filteredData.appointments, patients, doctors]);

    const appointmentStatusData = useMemo(() => {
        const statusCounts = filteredData.appointments.reduce((acc, curr) => {
            acc[curr.status] = (acc[curr.status] || 0) + 1;
            return acc;
        }, {} as Record<Appointment['status'], number>);
        const statusMap = {
            'Scheduled': { label: 'زمان‌بندی شده', color: 'bg-blue-100 text-blue-800' },
            'Completed': { label: 'تکمیل شده', color: 'bg-green-100 text-green-800' },
            'Cancelled': { label: 'لغو شده', color: 'bg-red-100 text-red-800' },
            'Waiting': { label: 'در انتظار', color: 'bg-yellow-100 text-yellow-800' }
        };
        return (Object.entries(statusMap)).map(([status, {label, color}]) => ({
            status: status as Appointment['status'], name: label, value: statusCounts[status as Appointment['status']] || 0, color: color
        }));
    }, [filteredData.appointments]);
    
    const getPatientNames = (ids: string[]): string => {
        if (!ids || ids.length === 0) return 'نامشخص';
        const patientNames = ids.map(id => patients.find(p => p.id === id)?.name || `بیمار #${id}`);
        return patientNames.join('، ');
    };

    const receivablesData = useMemo(() => {
        const patientFinancials = new Map<string, { patientId: string, patientName: string, totalFees: number, totalPayments: number, details: any[] }>();
        appointments.forEach(app => {
            if (app.status === 'Completed' && app.patientIds.length > 0) {
                const doctor = doctors.find(d => d.id === app.doctorId);
                const sessionCost = app.sessionFee || (doctor ? Math.round((doctor.ratePerHour / 60) * parseInt(app.sessionDuration || '0', 10)) : 0);
                if (sessionCost <= 0) return;
                app.patientIds.forEach(patientId => {
                    const patient = patients.find(p => p.id === patientId);
                    if (!patient) return;
                    const insuranceProvider = insuranceProviders.find(i => i.id === patient.insuranceProviderId);
                    let insuranceShare = 0;
                    if (insuranceProvider) {
                        insuranceShare = insuranceProvider.commissionType === 'percentage' ? Math.round(sessionCost * (insuranceProvider.commissionValue / 100)) : Math.min(sessionCost, insuranceProvider.commissionValue);
                    }
                    const patientShare = sessionCost - insuranceShare;
                    if (patientShare <= 0) return;
                    if (!patientFinancials.has(patientId)) patientFinancials.set(patientId, { patientId, patientName: patient.name, totalFees: 0, totalPayments: 0, details: [] });
                    const info = patientFinancials.get(patientId)!;
                    info.totalFees += patientShare;
                    info.details.push({ id: `${app.id}-fee`, date: app.date, description: `سهم بیمار از جلسه با ${doctor?.name || 'پزشک'}`, type: 'fee', amount: patientShare });
                });
            }
        });
        transactions.forEach(t => {
            if (t.type === 'درآمد' && t.patientId) {
                const patient = patients.find(p => p.id === t.patientId);
                if (!patient) return;
                if (!patientFinancials.has(t.patientId)) patientFinancials.set(t.patientId, { patientId: t.patientId, patientName: patient.name, totalFees: 0, totalPayments: 0, details: [] });
                const info = patientFinancials.get(t.patientId)!;
                info.totalPayments += t.amount;
                info.details.push({ id: t.id, date: t.date, description: t.description, type: 'income', amount: t.amount });
            }
        });
        const debtors = Array.from(patientFinancials.values()).map(info => ({ ...info, balance: info.totalFees - info.totalPayments })).filter(info => info.balance > 0.1).map(info => ({ patientId: info.patientId, patientName: info.patientName, totalDebt: info.balance, details: info.details.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) })).sort((a, b) => b.totalDebt - a.totalDebt);
        return { groupedDetails: debtors, totalReceivables: debtors.reduce((sum, d) => sum + d.totalDebt, 0) };
    }, [appointments, transactions, patients, doctors, insuranceProviders]);

    const doctorFinancialProfile = useMemo(() => {
        if (filters.doctorId === 'all') return null;
        const doctor = doctors.find(d => d.id === filters.doctorId);
        if (!doctor) return null;
        const incomeAppointments = filteredData.appointments.filter(app => app.doctorId === filters.doctorId && app.status === 'Completed');
        let totalGrossIncome = 0; let totalDoctorShare = 0;
        const incomeDetails = incomeAppointments.map(app => {
            const sessionFee = Number(app.sessionFee) || 0;
            totalGrossIncome += sessionFee;
            let applicableParticipationRate = doctor.participationRate || 0;
            if (app.patientIds.length === 1) {
                const patient = patients.find(p => p.id === app.patientIds[0]);
                if (patient && patient.referredById === doctor.id) applicableParticipationRate = doctor.referralParticipationRate || applicableParticipationRate;
            }
            const doctorShareForApp = sessionFee * (applicableParticipationRate / 100);
            totalDoctorShare += doctorShareForApp;
            return { id: app.id, date: app.date, patientNames: getPatientNames(app.patientIds), sessionFee, doctorShare: doctorShareForApp, appliedRate: applicableParticipationRate };
        });
        const totalClinicShare = totalGrossIncome - totalDoctorShare;
        const paymentTransactions = filteredData.transactions.filter(t => t.type === 'هزینه' && t.doctorId === filters.doctorId);
        const totalPaymentsToDoctor = paymentTransactions.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
        return { doctorName: doctor.name, totalGrossIncome, totalDoctorShare, totalClinicShare, totalPaymentsToDoctor, balance: totalDoctorShare - totalPaymentsToDoctor, incomeDetails, paymentTransactions };
    }, [filters.doctorId, filteredData, doctors, patients]);

    const insuranceClaimsData = useMemo(() => {
        type ClaimDetail = { appointmentId: string; date: string; patientName: string; sessionFee: number; claimAmount: number; doctorName: string; };
        const claims = new Map<string, { providerId: string, providerName: string; totalAmount: number; details: ClaimDetail[] }>();
        filteredData.appointments.forEach(app => {
            if (app.status !== 'Completed') return;
            const sessionCost = app.sessionFee || 0;
            if (sessionCost <= 0) return;
            app.patientIds.forEach(patientId => {
                const patient = patients.find(p => p.id === patientId);
                if (!patient || !patient.insuranceProviderId) return;
                const insuranceProvider = insuranceProviders.find(i => i.id === patient.insuranceProviderId);
                if (!insuranceProvider) return;
                let insuranceShare = insuranceProvider.commissionType === 'percentage' ? Math.round(sessionCost * (insuranceProvider.commissionValue / 100)) : Math.min(sessionCost, insuranceProvider.commissionValue);
                if (insuranceShare <= 0) return;
                if (!claims.has(insuranceProvider.id)) claims.set(insuranceProvider.id, { providerId: insuranceProvider.id, providerName: insuranceProvider.name, totalAmount: 0, details: [] });
                const claimInfo = claims.get(insuranceProvider.id)!;
                claimInfo.totalAmount += insuranceShare;
                claimInfo.details.push({ appointmentId: app.id, date: app.date, patientName: patient.name, sessionFee: sessionCost, claimAmount: insuranceShare, doctorName: doctors.find(d => d.id === app.doctorId)?.name || '-' });
            });
        });
        const sortedClaims = Array.from(claims.values()).sort((a, b) => b.totalAmount - a.totalAmount);
        return { claims: sortedClaims, total: sortedClaims.reduce((sum, claim) => sum + claim.totalAmount, 0) };
    }, [filteredData.appointments, patients, doctors, insuranceProviders]);

    const incomeTransactions = useMemo(() => filteredData.transactions.filter(t => t.type === 'درآمد'), [filteredData.transactions]);
    const expenseTransactions = useMemo(() => filteredData.transactions.filter(t => t.type === 'هزینه'), [filteredData.transactions]);

    const expenseByCategoryData = useMemo(() => {
        const expenses = filteredData.transactions.filter(t => t.type === 'هزینه');
        const categoryMap = new Map<string, { totalAmount: number, count: number }>();
        expenses.forEach(t => {
            const category = t.costCategory || 'دسته بندی نشده';
            if (!categoryMap.has(category)) categoryMap.set(category, { totalAmount: 0, count: 0 });
            const current = categoryMap.get(category)!;
            current.totalAmount += t.amount;
            current.count += 1;
        });
        return Array.from(categoryMap.entries()).map(([name, data]) => ({ name, ...data })).sort((a, b) => b.totalAmount - a.totalAmount);
    }, [filteredData.transactions]);

    const referralSourceData = useMemo(() => {
        const patientIdsInPeriod = new Set<string>();
        filteredData.appointments.forEach(app => app.patientIds.forEach(id => patientIdsInPeriod.add(id)));
        const totalUniquePatients = patientIdsInPeriod.size;
        if (totalUniquePatients === 0) return { data: [], total: 0 };
        const sourceCounts = new Map<string, number>();
        patientIdsInPeriod.forEach(patientId => {
            const patient = patients.find(p => p.id === patientId);
            const source = patient?.referralSource?.trim() || 'نامشخص';
            sourceCounts.set(source, (sourceCounts.get(source) || 0) + 1);
        });
        const data = Array.from(sourceCounts.entries()).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
        return { data, total: totalUniquePatients };
    }, [filteredData.appointments, patients]);

  const appointmentStatusOptions: {value: Appointment['status'], label: string}[] = [
    { value: 'Scheduled', label: 'زمان‌بندی شده' },
    { value: 'Completed', label: 'تکمیل شده' },
    { value: 'Cancelled', label: 'لغو شده' },
    { value: 'Waiting', label: 'در انتظار' },
  ];
  
  const allReportTabs: {
      id: ReportViewType;
      label: string;
      icon: React.FC<{className?: string}>;
      disabled: boolean;
      restricted: string[];
  }[] = [
      { id: 'general', label: 'گزارش کلی', icon: ClipboardListIcon, disabled: false, restricted: ['منشی'] },
      { id: 'income', label: 'گزارش درآمدها', icon: TrendingUpIcon, disabled: false, restricted: [] },
      { id: 'expenses', label: 'گزارش هزینه‌ها', icon: TrendingDownIcon, disabled: false, restricted: ['منشی'] },
      { id: 'expenseCategories', label: 'سرفصل هزینه‌ها', icon: ChartBarIcon, disabled: false, restricted: ['منشی'] },
      { id: 'referralSources', label: 'منابع جذب بیمار', icon: UsersIcon, disabled: false, restricted: ['منشی'] },
      { id: 'receivables', label: 'مطالبات از بیماران', icon: FinancialIcon, disabled: false, restricted: ['منشی'] },
      { id: 'insuranceClaims', label: 'مطالبات از بیمه', icon: ShieldCheckIcon, disabled: false, restricted: ['منشی'] },
      { id: 'doctor', label: 'مالی پزشکان', icon: DoctorsIcon, disabled: filters.doctorId === 'all', restricted: ['منشی'] },
      { id: 'therapistPerformance', label: 'عملکرد درمانگران', icon: ChartBarIcon, disabled: false, restricted: ['منشی', 'پزشک', 'درمانگر'] },
      { id: 'patientRetention', label: 'تحلیل مراجعین', icon: UserCircleIcon, disabled: false, restricted: ['منشی', 'پزشک', 'درمانگر'] }
  ];

  const reportTabs = useMemo(() => {
      if (isMedicalStaff) {
          return allReportTabs.filter(tab => ['doctor'].includes(tab.id));
      }
      return allReportTabs.filter(tab => !tab.restricted.includes(currentUser.role));
  }, [isMedicalStaff, currentUser.role, filters.doctorId]);

  const currentReportTab = reportTabs.find(tab => tab.id === reportView) || reportTabs[0];

  const handleExport = () => {
    const dateRangeStr = `${filters.startDate}_to_${filters.endDate}`;
    switch (reportView) {
        case 'therapistPerformance': {
            const data = therapistPerformanceData.map(item => ({ 'درمانگر': item.name, 'تعداد جلسات': item.count }));
            exportToExcel(data, `therapist-performance-${dateRangeStr}.xlsx`);
            break;
        }
        case 'patientRetention': {
            const data = [
                ...patientRetentionData.distribution.map(d => ({ 'تعداد مراجعه': d.range, 'تعداد بیماران': d.count, 'درصد': d.percentage.toFixed(1) + '%' })),
                {},
                { 'عنوان': 'لیست بیماران تک جلسه' },
                ...patientRetentionData.singleVisitPatients.map(p => ({ 'نام بیمار': p.patientName, 'درمانگر': p.doctorName }))
            ];
            exportToExcel(data, `patient-retention-${dateRangeStr}.xlsx`);
            break;
        }
        case 'general': {
            const data = [
                { 'شاخص': 'مجموع درآمد', 'مبلغ': financialSummary.income },
                { 'شاخص': 'مجموع هزینه', 'مبلغ': financialSummary.expense },
                { 'شاخص': 'سود خالص', 'مبلغ': financialSummary.profit },
                {}, ...appointmentStatusData.map(s => ({ 'وضعیت نوبت': s.name, 'تعداد': s.value }))
            ];
            exportToExcel(data, `general-report-${dateRangeStr}.xlsx`);
            break;
        }
        case 'income': {
            const data = incomeTransactions.map(t => ({
                'تاریخ': formatToJalali(t.date), 'شرح': t.description, 'بیمار': t.patientId ? patients.find(p => p.id === t.patientId)?.name : '-',
                'روش پرداخت': t.paymentMethod || '-', 'حساب': t.accountDebited || '-', 'مبلغ': t.amount,
            }));
            exportToExcel(data, `income-report-${dateRangeStr}.xlsx`);
            break;
        }
        case 'expenses': {
            const data = expenseTransactions.map(t => ({
                'تاریخ': formatToJalali(t.date), 'شرح': t.description, 'سرفصل': t.costCategory || '-',
                'پرداخت به': t.doctorId ? doctors.find(d => d.id === t.doctorId)?.name : (t.personnelId ? personnel.find(p => p.id === t.personnelId)?.name : '-'),
                'از حساب': t.accountDebited || '-', 'مبلغ': t.amount,
            }));
            exportToExcel(data, `expenses-report-${dateRangeStr}.xlsx`);
            break;
        }
        case 'expenseCategories': {
            const data = expenseByCategoryData.map(item => ({ 'سرفصل هزینه': item.name, 'تعداد تراکنش': item.count, 'مجموع مبلغ': item.totalAmount }));
            exportToExcel(data, `expense-categories-report-${dateRangeStr}.xlsx`);
            break;
        }
        case 'referralSources': {
            const data = referralSourceData.data.map(item => ({
                'منبع جذب': item.name, 'تعداد مراجعین': item.count,
                'درصد': referralSourceData.total > 0 ? ((item.count / referralSourceData.total) * 100).toFixed(1) + '%' : '0%',
            }));
            exportToExcel(data, `referral-sources-report-${dateRangeStr}.xlsx`);
            break;
        }
        case 'receivables': {
            const data = receivablesData.groupedDetails.map(item => ({ 'نام بیمار': item.patientName, 'مبلغ بدهی': item.totalDebt }));
            exportToExcel(data, 'receivables-report.xlsx');
            break;
        }
        case 'insuranceClaims': {
            const dataToExport: any[] = [];
            insuranceClaimsData.claims.forEach(claim => {
                if (claim.details.length > 0) {
                    claim.details.forEach(detail => {
                        dataToExport.push({
                            'شرکت بیمه': claim.providerName,
                            'تاریخ': formatToJalali(detail.date),
                            'بیمار': detail.patientName,
                            'پزشک': detail.doctorName,
                            'هزینه کل جلسه (تومان)': detail.sessionFee,
                            'مبلغ مطالبه (تومان)': detail.claimAmount,
                        });
                    });
                }
            });
            exportToExcel(dataToExport, `insurance-claims-details-report-${dateRangeStr}.xlsx`);
            break;
        }
        case 'doctor': {
            if (doctorFinancialProfile) {
                const data = [
                    { 'پزشک': doctorFinancialProfile.doctorName, 'از تاریخ': formatToJalali(filters.startDate), 'تا تاریخ': formatToJalali(filters.endDate) },
                    {}, { 'گزارش': 'خلاصه' },
                    { 'عنوان': 'درآمد ناخالص از نوبت‌ها', 'مبلغ': doctorFinancialProfile.totalGrossIncome },
                    { 'عنوان': 'جمع سهم پزشک', 'مبلغ': doctorFinancialProfile.totalDoctorShare },
                    { 'عنوان': 'جمع پرداختی به پزشک', 'مبلغ': doctorFinancialProfile.totalPaymentsToDoctor },
                    { 'عنوان': 'وضعیت نهایی حساب', 'مبلغ': doctorFinancialProfile.balance },
                    {}, { 'گزارش': 'جزئیات درآمد' },
                    ...doctorFinancialProfile.incomeDetails.map(item => ({ 
                        'تاریخ': formatToJalali(item.date), 
                        'بیمار': item.patientNames, 
                        'مبلغ جلسه': item.sessionFee, 
                        'درصد سهم': item.appliedRate, 
                        'سهم پزشک': item.doctorShare 
                    })),
                    {}, { 'گزارش': 'جزئیات پرداخت' },
                    ...doctorFinancialProfile.paymentTransactions.map(item => ({ 'تاریخ پرداخت': formatToJalali(item.date), 'شرح': item.description, 'مبلغ پرداخت': item.amount })),
                ];
                exportToExcel(data, `doctor-report-${doctorFinancialProfile.doctorName}-${dateRangeStr}.xlsx`);
            }
            break;
        }
    }
  };

  const filteredAppointmentsForDetail = useMemo(() => {
      if (!selectedStatusDetail) return [];
      return filteredData.appointments.filter(app => app.status === selectedStatusDetail);
  }, [filteredData.appointments, selectedStatusDetail]);

  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">گزارشات و آمار</h2>

      <div className="bg-gray-50 p-6 rounded-2xl shadow-sm mb-8 border border-gray-200">
          <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
              <h3 className="text-xl font-bold text-gray-700 flex items-center gap-2">
                <FilterIcon className="w-6 h-6" />
                فیلترها
              </h3>
              <div className="flex items-center gap-4">
                  <button onClick={handleExport} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition flex items-center gap-2 text-sm">
                    <DownloadIcon className="w-5 h-5" />
                    خروجی اکسل
                  </button>
                  <button onClick={handleResetFilters} className="text-sm text-gray-500 hover:text-blue-600 transition font-semibold">
                    پاک کردن
                  </button>
              </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              <div>
                  <label className="block text-gray-700 text-sm font-semibold mb-2">پزشک</label>
                  <select 
                      name="doctorId" 
                      value={filters.doctorId} 
                      onChange={handleFilterChange} 
                      className="w-full p-2 border border-gray-300 rounded-lg bg-white shadow-sm focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-200 disabled:cursor-not-allowed"
                      disabled={isMedicalStaff}
                  >
                      {isMedicalStaff && currentUser ? (
                          <option value={filters.doctorId}>{currentUser.name}</option>
                      ) : (
                          <>
                              <option value="all">همه پزشکان</option>
                              {doctors.map(doc => <option key={doc.id} value={doc.id}>{doc.name}</option>)}
                          </>
                      )}
                  </select>
              </div>
               <div>
                  <label className="block text-gray-700 text-sm font-semibold mb-2">وضعیت نوبت</label>
                  <select name="status" value={filters.status} onChange={handleFilterChange} className="w-full p-2 border border-gray-300 rounded-lg bg-white shadow-sm focus:ring-blue-500 focus:border-blue-500">
                      <option value="all">همه وضعیت‌ها</option>
                      {appointmentStatusOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                  </select>
              </div>
              <JalaliDatePicker 
                label="از تاریخ" 
                value={filters.startDate} 
                onChange={(date) => handleDateChange('startDate', date)} 
                disabled={isSecretary}
              />
              <JalaliDatePicker 
                label="تا تاریخ" 
                value={filters.endDate} 
                onChange={(date) => handleDateChange('endDate', date)} 
                disabled={isSecretary}
              />
              <div>
                  <label className="block text-gray-700 text-sm font-semibold mb-2">روش پرداخت (درآمد)</label>
                  <select name="paymentMethod" value={filters.paymentMethod} onChange={handleFilterChange} className="w-full p-2 border border-gray-300 rounded-lg bg-white shadow-sm focus:ring-blue-500 focus:border-blue-500">
                      <option value="all">همه روش‌ها</option>
                      <option value="نقد">نقد</option>
                      <option value="کارت به کارت">کارت به کارت</option>
                      <option value="پوز">پوز</option>
                  </select>
              </div>
              <div>
                  <label className="block text-gray-700 text-sm font-semibold mb-2">حساب بانکی (درآمد)</label>
                  <select name="bankAccount" value={filters.bankAccount} onChange={handleFilterChange} className="w-full p-2 border border-gray-300 rounded-lg bg-white shadow-sm focus:ring-blue-500 focus:border-blue-500">
                      <option value="all">همه حساب‌ها</option>
                      {bankAccounts.map(acc => <option key={acc.id} value={acc.name}>{acc.name}</option>)}
                  </select>
              </div>
          </div>
      </div>
      
       <div className="mb-6 border-b border-gray-200">
            <div className="md:hidden relative" ref={viewDropdownRef}>
                <button
                    onClick={() => setIsViewDropdownOpen(prev => !prev)}
                    className="w-full flex items-center justify-between text-left px-4 py-2 border rounded-lg bg-white"
                >
                    <span className="flex items-center gap-2">
                        <currentReportTab.icon className="w-5 h-5 text-gray-600" />
                        <span className="font-semibold text-gray-800">{currentReportTab.label}</span>
                    </span>
                    <ChevronDownIcon className={`w-5 h-5 text-gray-500 transition-transform ${isViewDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isViewDropdownOpen && (
                    <div className="absolute z-20 mt-1 w-full bg-white border rounded-lg shadow-lg">
                        {reportTabs.map(tab => (
                            <button
                                key={tab.id}
                                disabled={tab.disabled}
                                onClick={() => {
                                    if (!tab.disabled) {
                                        setReportView(tab.id);
                                        setIsViewDropdownOpen(false);
                                    }
                                }}
                                className={`w-full text-right flex items-center gap-2 px-4 py-3 text-sm transition-colors ${reportView === tab.id ? 'font-bold text-blue-600' : 'text-gray-800'} ${tab.disabled ? 'text-gray-400 cursor-not-allowed' : 'hover:bg-gray-100'}`}
                            >
                                <tab.icon className="w-5 h-5"/>
                                {tab.label}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            <nav className="hidden md:flex -mb-px space-x-4 space-x-reverse overflow-x-auto" aria-label="Tabs">
                {reportTabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => !tab.disabled && setReportView(tab.id)}
                        disabled={tab.disabled}
                        className={`whitespace-nowrap py-4 px-4 border-b-2 font-medium text-sm transition-colors flex items-center gap-2 ${reportView === tab.id ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} ${tab.disabled ? 'cursor-not-allowed text-gray-400' : ''}`}
                    >
                        <tab.icon className="w-5 h-5"/>
                        {tab.label}
                    </button>
                ))}
            </nav>
        </div>

      {reportView === 'general' && (
        <div className="space-y-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
               <h3 className="text-xl font-semibold mb-4">خلاصه مالی</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="bg-green-50 p-6 rounded-lg flex items-center">
                        <div className="bg-green-500 text-white p-3 rounded-full"><TrendingUpIcon className="w-6 h-6"/></div>
                        <div className="mr-4">
                            <p className="text-gray-500">مجموع درآمد</p>
                            <p className="text-xl font-bold">{financialSummary.income.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
                        </div>
                    </div>
                    <div className="bg-red-50 p-6 rounded-lg flex items-center">
                        <div className="bg-red-500 text-white p-3 rounded-full"><TrendingDownIcon className="w-6 h-6"/></div>
                        <div className="mr-4">
                            <p className="text-gray-500">مجموع هزینه</p>
                            <p className="text-xl font-bold">{financialSummary.expense.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
                        </div>
                    </div>
                    <div className="bg-blue-50 p-6 rounded-lg flex items-center">
                        <div className="bg-blue-500 text-white p-3 rounded-full"><ChartBarIcon className="w-6 h-6"/></div>
                        <div className="mr-4">
                            <p className="text-gray-500">سود خالص</p>
                            <p className={`text-xl font-bold ${financialSummary.profit < 0 ? 'text-red-600' : 'text-green-600'}`}>{financialSummary.profit.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
                        </div>
                    </div>
                </div>
            </div>
            {/* Status Chart Logic */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4">خلاصه وضعیت نوبت‌ها</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                    {appointmentStatusData.map(status => (
                        <div 
                            key={status.name} 
                            className={`p-4 rounded-lg cursor-pointer transition transform hover:-translate-y-1 shadow-sm hover:shadow-md ${status.color} ${selectedStatusDetail === status.status ? 'ring-4 ring-offset-2 ring-blue-300' : ''}`}
                            onClick={() => setSelectedStatusDetail(status.status === selectedStatusDetail ? null : status.status)}
                        >
                            <p className="font-bold text-2xl">{status.value.toLocaleString('fa-IR')}</p>
                            <p className="text-sm font-semibold">{status.name}</p>
                        </div>
                    ))}
                </div>
                
                {selectedStatusDetail && (
                    <div className="mt-8 pt-6 border-t animate-fade-in-down">
                        <div className="flex justify-between items-center mb-4">
                            <h4 className="text-lg font-bold text-gray-700">
                                جزئیات نوبت‌های: <span className="text-blue-600">{appointmentStatusData.find(s => s.status === selectedStatusDetail)?.name}</span>
                            </h4>
                            <button onClick={() => setSelectedStatusDetail(null)} className="text-gray-400 hover:text-red-500 text-sm">بستن</button>
                        </div>
                        {filteredAppointmentsForDetail.length > 0 ? (
                            <div className="overflow-x-auto">
                                <table className="w-full text-right text-sm border rounded-lg overflow-hidden">
                                    <thead className="bg-gray-50 border-b">
                                        <tr>
                                            <th className="p-3 font-semibold">بیمار</th>
                                            <th className="p-3 font-semibold">پزشک</th>
                                            <th className="p-3 font-semibold">تاریخ</th>
                                            <th className="p-3 font-semibold">ساعت</th>
                                            {selectedStatusDetail === 'Cancelled' && <th className="p-3 font-semibold text-red-600">دلیل لغو</th>}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredAppointmentsForDetail.map(app => (
                                            <tr key={app.id} className="border-b hover:bg-gray-50 last:border-0">
                                                <td className="p-3">{getPatientNames(app.patientIds)}</td>
                                                <td className="p-3">{doctors.find(d => d.id === app.doctorId)?.name}</td>
                                                <td className="p-3">{formatToJalali(app.date)}</td>
                                                <td className="p-3">{app.time}</td>
                                                {selectedStatusDetail === 'Cancelled' && <td className="p-3 text-red-600">{app.cancellationReason || '-'}</td>}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        ) : (
                            <p className="text-center text-gray-500 bg-gray-50 p-4 rounded-lg">موردی برای نمایش وجود ندارد.</p>
                        )}
                    </div>
                )}
            </div>
        </div>
      )}

      {reportView === 'therapistPerformance' && isManager && (
          <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="mb-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">گزارش عملکرد درمانگران</h3>
                  <p className="text-gray-500 text-sm">تعداد جلسات تکمیل شده هر درمانگر در بازه زمانی انتخاب شده</p>
              </div>
              
              {therapistPerformanceData.length > 0 ? (
                  <div className="overflow-x-auto">
                      <table className="w-full text-right text-sm">
                          <thead className="bg-gray-50 border-b">
                              <tr>
                                  <th className="p-3 font-semibold">نام درمانگر</th>
                                  <th className="p-3 font-semibold text-center">تعداد جلسات</th>
                                  <th className="p-3 font-semibold w-1/3">نمودار</th>
                              </tr>
                          </thead>
                          <tbody>
                              {therapistPerformanceData.map(item => {
                                  const maxCount = therapistPerformanceData[0]?.count || 1;
                                  const percentage = (item.count / maxCount) * 100;
                                  return (
                                      <tr key={item.name} className="border-b hover:bg-gray-50">
                                          <td className="p-3 font-medium">{item.name}</td>
                                          <td className="p-3 text-center text-lg font-bold text-blue-600">{item.count.toLocaleString('fa-IR')}</td>
                                          <td className="p-3">
                                              <div className="w-full bg-gray-100 rounded-full h-4">
                                                  <div 
                                                      className="bg-blue-500 h-4 rounded-full transition-all duration-500" 
                                                      style={{ width: `${percentage}%` }}
                                                  ></div>
                                              </div>
                                          </td>
                                      </tr>
                                  );
                              })}
                          </tbody>
                      </table>
                  </div>
              ) : (
                  <p className="text-center text-gray-500 py-8 bg-gray-50 rounded-lg">هیچ داده‌ای برای نمایش وجود ندارد.</p>
              )}
          </div>
      )}

      {reportView === 'patientRetention' && isManager && (
          <div className="space-y-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">تحلیل تداوم مراجعه بیماران</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                      {patientRetentionData.distribution.map(item => (
                          <div key={item.range} className="bg-indigo-50 p-4 rounded-lg text-center border border-indigo-100">
                              <p className="text-gray-600 text-sm mb-1">{item.range} بار مراجعه</p>
                              <p className="text-2xl font-bold text-indigo-700">{item.count.toLocaleString('fa-IR')} <span className="text-xs font-normal text-gray-500">بیمار</span></p>
                              <p className="text-xs text-indigo-400 mt-1">{item.percentage.toFixed(1)}% کل</p>
                          </div>
                      ))}
                  </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">بیماران تک‌جلسه‌ای</h3>
                  <p className="text-gray-500 text-sm mb-4">لیست بیمارانی که در بازه زمانی انتخاب شده فقط یک بار مراجعه داشته‌اند.</p>
                  
                  {patientRetentionData.singleVisitPatients.length > 0 ? (
                      <div className="overflow-x-auto max-h-96">
                          <table className="w-full text-right text-sm">
                              <thead className="bg-gray-50 border-b sticky top-0">
                                  <tr>
                                      <th className="p-3 font-semibold">نام بیمار</th>
                                      <th className="p-3 font-semibold">درمانگر</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  {patientRetentionData.singleVisitPatients.map((p, idx) => (
                                      <tr key={idx} className="border-b hover:bg-gray-50">
                                          <td className="p-3 font-medium">{p.patientName}</td>
                                          <td className="p-3 text-gray-600">{p.doctorName}</td>
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      </div>
                  ) : (
                      <p className="text-center text-gray-500 py-8 bg-gray-50 rounded-lg">هیچ بیمار تک‌جلسه‌ای یافت نشد.</p>
                  )}
              </div>
          </div>
      )}

      {reportView === 'income' && (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-green-50 p-6 rounded-lg mb-6">
                <p className="text-green-800">مجموع درآمد در بازه انتخابی</p>
                <p className="text-2xl font-bold text-green-800">{financialSummary.income.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
                {isSecretary && <p className="text-xs text-green-600 mt-1 font-bold">گزارش روزانه تراکنش‌ها (امروز)</p>}
            </div>
            <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-right text-sm">
                    <thead className="bg-gray-50 border-b">
                        <tr>
                            <th className="p-2 font-semibold">تاریخ</th>
                            <th className="p-2 font-semibold">شرح</th>
                            <th className="p-2 font-semibold">بیمار</th>
                            <th className="p-2 font-semibold">حساب</th>
                            <th className="p-2 font-semibold">مبلغ</th>
                        </tr>
                    </thead>
                    <tbody>
                        {incomeTransactions.map(t => (
                            <tr key={t.id} className="border-b hover:bg-gray-50">
                                <td className="p-2">{formatToJalali(t.date)}</td>
                                <td className="p-2">{t.description}</td>
                                <td className="p-2">{t.patientId ? patients.find(p=>p.id === t.patientId)?.name : '-'}</td>
                                <td className="p-2">{t.accountDebited}</td>
                                <td className="p-2 font-semibold text-green-700">{t.amount.toLocaleString('fa-IR')}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="md:hidden space-y-4">
                {incomeTransactions.map(t => (
                    <div key={t.id} className="bg-gray-50 p-4 rounded-lg border">
                        <p className="font-bold">{t.description}</p>
                        <p className="font-semibold text-lg text-green-700 mt-1">{t.amount.toLocaleString('fa-IR')} تومان</p>
                        <div className="text-sm text-gray-500 mt-2 space-y-1">
                            <p>تاریخ: {formatToJalali(t.date)}</p>
                            {t.patientId && <p>بیمار: {patients.find(p=>p.id === t.patientId)?.name}</p>}
                            {t.accountDebited && <p>حساب: {t.accountDebited}</p>}
                        </div>
                    </div>
                ))}
            </div>
            {incomeTransactions.length === 0 && <p className="text-center text-gray-500 py-8">هیچ درآمدی در این بازه زمانی یافت نشد.</p>}
        </div>
      )}
      
      {reportView === 'expenses' && (
         <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-red-50 p-6 rounded-lg mb-6">
                <p className="text-red-800">مجموع هزینه‌ها در بازه انتخابی</p>
                <p className="text-2xl font-bold text-red-800">{financialSummary.expense.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
            </div>
            <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-right text-sm">
                    <thead className="bg-gray-50 border-b">
                        <tr>
                            <th className="p-2 font-semibold">تاریخ</th>
                            <th className="p-2 font-semibold">شرح</th>
                            <th className="p-2 font-semibold">سرفصل</th>
                            <th className="p-2 font-semibold">پرداخت به</th>
                            <th className="p-2 font-semibold">حساب</th>
                            <th className="p-2 font-semibold">مبلغ</th>
                        </tr>
                    </thead>
                    <tbody>
                        {expenseTransactions.map(t => (
                            <tr key={t.id} className="border-b hover:bg-gray-50">
                                <td className="p-2">{formatToJalali(t.date)}</td>
                                <td className="p-2">{t.description}</td>
                                <td className="p-2">{t.costCategory || '-'}</td>
                                <td className="p-2">
                                    {t.doctorId ? doctors.find(d=>d.id === t.doctorId)?.name : 
                                    (t.personnelId ? personnel.find(p=>p.id === t.personnelId)?.name : '-')}
                                </td>
                                <td className="p-2">{t.accountDebited}</td>
                                <td className="p-2 font-semibold text-red-700">{t.amount.toLocaleString('fa-IR')}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="md:hidden space-y-4">
                {expenseTransactions.map(t => (
                    <div key={t.id} className="bg-gray-50 p-4 rounded-lg border">
                        <p className="font-bold">{t.description}</p>
                        <p className="font-semibold text-lg text-red-700 mt-1">{t.amount.toLocaleString('fa-IR')} تومان</p>
                         <div className="text-sm text-gray-500 mt-2 space-y-1">
                            <p>تاریخ: {formatToJalali(t.date)}</p>
                            {t.costCategory && <p>سرفصل: {t.costCategory}</p>}
                            {t.doctorId && <p>پرداخت به پزشک: {doctors.find(d=>d.id === t.doctorId)?.name}</p>}
                            {t.personnelId && <p>پرداخت به پرسنل: {personnel.find(p=>p.id === t.personnelId)?.name}</p>}
                            {t.accountDebited && <p>از حساب: {t.accountDebited}</p>}
                        </div>
                    </div>
                ))}
            </div>
            {expenseTransactions.length === 0 && <p className="text-center text-gray-500 py-8">هیچ هزینه‌ای در این بازه زمانی یافت نشد.</p>}
        </div>
      )}
      
      {reportView === 'expenseCategories' && (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-red-50 p-6 rounded-lg mb-6">
                <p className="text-red-800">مجموع هزینه‌ها در بازه انتخابی</p>
                <p className="text-2xl font-bold text-red-800">{financialSummary.expense.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
            </div>
            
            {expenseByCategoryData.length > 0 ? (
                <div className="overflow-x-auto">
                    <table className="w-full text-right text-sm">
                        <thead className="bg-gray-50 border-b">
                            <tr>
                                <th className="p-3 font-semibold">سرفصل هزینه</th>
                                <th className="p-3 font-semibold text-center">تعداد تراکنش</th>
                                <th className="p-3 font-semibold text-center">مجموع مبلغ (تومان)</th>
                                <th className="p-3 font-semibold w-1/3">نمودار</th>
                            </tr>
                        </thead>
                        <tbody>
                            {expenseByCategoryData.map(item => {
                                const maxAmount = expenseByCategoryData[0]?.totalAmount || 1;
                                const percentage = (item.totalAmount / maxAmount) * 100;
                                return (
                                    <tr key={item.name} className="border-b hover:bg-gray-50">
                                        <td className="p-3 font-medium">{item.name}</td>
                                        <td className="p-3 text-center">{item.count.toLocaleString('fa-IR')}</td>
                                        <td className="p-3 text-center font-semibold text-red-700">{item.totalAmount.toLocaleString('fa-IR')}</td>
                                        <td className="p-3">
                                            <div className="w-full bg-gray-200 rounded-full h-4">
                                                <div 
                                                    className="bg-red-500 h-4 rounded-full" 
                                                    style={{ width: `${percentage}%` }}
                                                ></div>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-center text-gray-500 py-8">هیچ هزینه‌ای برای نمایش در سرفصل‌ها یافت نشد.</p>
            )}
        </div>
      )}
      
      {reportView === 'referralSources' && (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-indigo-50 p-6 rounded-lg mb-6">
                <p className="text-indigo-800">تعداد کل مراجعین یکتا در بازه انتخابی</p>
                <p className="text-2xl font-bold text-indigo-800">{referralSourceData.total.toLocaleString('fa-IR')} <span className="text-sm font-normal">نفر</span></p>
            </div>
            
            {referralSourceData.data.length > 0 ? (
                <div className="overflow-x-auto">
                    <table className="w-full text-right text-sm">
                        <thead className="bg-gray-50 border-b">
                            <tr>
                                <th className="p-3 font-semibold">منبع جذب</th>
                                <th className="p-3 font-semibold text-center">تعداد مراجعین</th>
                                <th className="p-3 font-semibold text-center">درصد</th>
                                <th className="p-3 font-semibold w-1/3">نمودار</th>
                            </tr>
                        </thead>
                        <tbody>
                            {referralSourceData.data.map(item => {
                                const percentage = referralSourceData.total > 0 ? (item.count / referralSourceData.total) * 100 : 0;
                                return (
                                    <tr key={item.name} className="border-b hover:bg-gray-50">
                                        <td className="p-3 font-medium">{item.name}</td>
                                        <td className="p-3 text-center">{item.count.toLocaleString('fa-IR')}</td>
                                        <td className="p-3 text-center text-xs">{Number(percentage.toFixed(1)).toLocaleString('fa-IR')}%</td>
                                        <td className="p-3">
                                            <div className="w-full bg-gray-200 rounded-full h-4">
                                                <div 
                                                    className="bg-indigo-500 h-4 rounded-full" 
                                                    style={{ width: `${percentage}%` }}
                                                ></div>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-center text-gray-500 py-8">داده‌ای برای نمایش بر اساس منابع جذب یافت نشد.</p>
            )}
        </div>
      )}

      {reportView === 'receivables' && (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-orange-50 p-6 rounded-lg mb-6">
                <p className="text-orange-800">مجموع کل مطالبات از بیماران بدهکار</p>
                <p className="text-2xl font-bold text-orange-800">{receivablesData.totalReceivables.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
            </div>
             <div className="space-y-2">
                {receivablesData.groupedDetails.map(item => {
                    const isExpanded = expandedPatientId === item.patientId;
                    return (
                        <div key={item.patientId} className="border rounded-lg overflow-hidden transition-all duration-300">
                            <button 
                                onClick={() => setExpandedPatientId(isExpanded ? null : item.patientId)}
                                className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 transition"
                            >
                                <span className="font-bold text-gray-800">{item.patientName}</span>
                                <div className="flex items-center gap-4">
                                    <span className="font-semibold text-red-600">{Math.round(item.totalDebt).toLocaleString('fa-IR')} تومان</span>
                                    <ChevronDownIcon className={`w-5 h-5 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                                </div>
                            </button>
                            {isExpanded && (
                                <div className="p-4 border-t bg-white">
                                    <table className="w-full text-right text-sm">
                                        <thead className="bg-white">
                                            <tr>
                                                <th className="p-2 font-semibold">تاریخ</th>
                                                <th className="p-2 font-semibold">شرح</th>
                                                <th className="p-2 font-semibold">نوع</th>
                                                <th className="p-2 font-semibold">مبلغ (تومان)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {item.details.map(detail => (
                                                <tr key={detail.id} className="border-b last:border-b-0 hover:bg-gray-50">
                                                    <td className="p-2">{formatToJalali(detail.date)}</td>
                                                    <td className="p-2">{detail.description}</td>
                                                    <td className="p-2">
                                                        {detail.type === 'fee' ? (
                                                            <span className="text-red-600 font-semibold">بدهی (هزینه)</span>
                                                        ) : (
                                                            <span className="text-green-600 font-semibold">پرداختی</span>
                                                        )}
                                                    </td>
                                                    <td className={`p-2 font-semibold ${detail.type === 'fee' ? 'text-red-700' : 'text-green-700'}`}>
                                                        {Math.round(detail.amount).toLocaleString('fa-IR')}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
            {receivablesData.groupedDetails.length === 0 && <p className="text-center text-gray-500 py-8">هیچ بیمار بدهکاری یافت نشد.</p>}
        </div>
      )}

      {reportView === 'insuranceClaims' && (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-teal-50 p-6 rounded-lg mb-6">
                <p className="text-teal-800">مجموع کل مطالبات از شرکت‌های بیمه</p>
                <p className="text-2xl font-bold text-teal-800">{insuranceClaimsData.total.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p>
            </div>
            <div className="space-y-2">
                {insuranceClaimsData.claims.map(claim => {
                    const isExpanded = expandedProviderId === claim.providerId;
                    return (
                       <div key={claim.providerId} className="border rounded-lg overflow-hidden transition-all duration-300">
                           <button onClick={() => setExpandedProviderId(isExpanded ? null : claim.providerId)} className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 transition">
                                <span className="font-bold text-gray-800">{claim.providerName}</span>
                                <div className="flex items-center gap-4">
                                    <span className="font-semibold text-teal-600">{claim.totalAmount.toLocaleString('fa-IR')} تومان</span>
                                    <ChevronDownIcon className={`w-5 h-5 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                                </div>
                           </button>
                           {isExpanded && (
                               <div className="p-4 border-t bg-white">
                                   <div className="overflow-x-auto">
                                       <table className="w-full text-right text-sm">
                                           <thead className="bg-white">
                                                <tr>
                                                    <th className="p-2 font-semibold">تاریخ</th>
                                                    <th className="p-2 font-semibold">بیمار</th>
                                                    <th className="p-2 font-semibold">پزشک</th>
                                                    <th className="p-2 font-semibold">هزینه جلسه</th>
                                                    <th className="p-2 font-semibold">مبلغ مطالبه</th>
                                                </tr>
                                           </thead>
                                           <tbody>
                                               {claim.details.map(detail => (
                                                   <tr key={detail.appointmentId} className="border-b last:border-b-0 hover:bg-gray-50">
                                                        <td className="p-2">{formatToJalali(detail.date)}</td>
                                                        <td className="p-2">{detail.patientName}</td>
                                                        <td className="p-2">{detail.doctorName}</td>
                                                        <td className="p-2">{detail.sessionFee.toLocaleString('fa-IR')}</td>
                                                        <td className="p-2 font-semibold text-teal-700">{detail.claimAmount.toLocaleString('fa-IR')}</td>
                                                   </tr>
                                               ))}
                                           </tbody>
                                       </table>
                                   </div>
                               </div>
                           )}
                       </div>
                    )
                })}
            </div>
            {insuranceClaimsData.claims.length === 0 && <p className="text-center text-gray-500 py-8">هیچ مطالبه‌ای از بیمه در این بازه زمانی یافت نشد.</p>}
        </div>
      )}

      {reportView === 'doctor' && (
        <>
            {!doctorFinancialProfile || (doctorFinancialProfile.totalGrossIncome === 0 && doctorFinancialProfile.totalPaymentsToDoctor === 0) ? (
              <div className="bg-white p-6 rounded-lg shadow-md text-center text-gray-500">
                <p>اطلاعاتی برای پزشک انتخاب شده در این بازه زمانی یافت نشد.</p>
              </div>
            ) : (
              <div className="space-y-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h4 className="text-xl font-semibold mb-4 text-gray-800">خلاصه عملکرد: {doctorFinancialProfile.doctorName}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-100 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">درآمد ناخالص</p>
                      <p className="text-xl font-bold text-gray-800">{doctorFinancialProfile.totalGrossIncome.toLocaleString('fa-IR')} <span className="text-xs">تومان</span></p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <p className="text-sm text-green-800">سهم پزشک</p>
                      <p className="text-xl font-bold text-green-800">{Math.round(doctorFinancialProfile.totalDoctorShare).toLocaleString('fa-IR')} <span className="text-xs">تومان</span></p>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-blue-800">سهم کلینیک</p>
                      <p className="text-xl font-bold text-blue-800">{Math.round(doctorFinancialProfile.totalClinicShare).toLocaleString('fa-IR')} <span className="text-xs">تومان</span></p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                   <h4 className="text-xl font-semibold mb-4 text-gray-800">وضعیت تسویه حساب</h4>
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                       <div className="bg-gray-100 p-4 rounded-lg">
                          <p className="text-sm text-gray-600">جمع سهم پزشک</p>
                          <p className="text-lg font-bold">{Math.round(doctorFinancialProfile.totalDoctorShare).toLocaleString('fa-IR')} <span className="text-xs">تومان</span></p>
                       </div>
                       <div className="bg-gray-100 p-4 rounded-lg">
                          <p className="text-sm text-gray-600">جمع پرداختی به پزشک</p>
                          <p className="text-lg font-bold">{doctorFinancialProfile.totalPaymentsToDoctor.toLocaleString('fa-IR')} <span className="text-xs">تومان</span></p>
                       </div>
                       <div className="p-4 rounded-lg text-center">
                            <p className="text-sm text-gray-600">وضعیت نهایی</p>
                            {doctorFinancialProfile.balance === 0 ? (
                               <p className="text-xl font-bold text-gray-700">تسویه شده</p>
                            ) : doctorFinancialProfile.balance > 0 ? (
                               <p className="text-xl font-bold text-green-600">{Math.round(doctorFinancialProfile.balance).toLocaleString('fa-IR')} <span className="text-xs">تومان (پزشک بستانکار)</span></p>
                            ) : (
                               <p className="text-xl font-bold text-red-600">{Math.round(Math.abs(doctorFinancialProfile.balance)).toLocaleString('fa-IR')} <span className="text-xs">تومان (پزشک بدهکار)</span></p>
                            )}
                       </div>
                   </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="text-lg font-semibold mb-2">نوبت‌های منجر به درآمد</h4>
                    <div className="hidden md:block overflow-y-auto max-h-96">
                      <table className="w-full text-right text-sm">
                        <thead className="bg-gray-50 border-b sticky top-0">
                          <tr>
                            <th className="p-2 font-semibold">تاریخ</th>
                            <th className="p-2 font-semibold">بیمار</th>
                            <th className="p-2 font-semibold">مبلغ</th>
                            <th className="p-2 font-semibold">درصد سهم</th>
                            <th className="p-2 font-semibold">سهم پزشک</th>
                          </tr>
                        </thead>
                        <tbody>
                          {doctorFinancialProfile.incomeDetails.map(item => (
                            <tr key={item.id} className="border-b hover:bg-gray-50">
                              <td className="p-2">{formatToJalali(item.date)}</td>
                              <td className="p-2 truncate">{item.patientNames}</td>
                              <td className="p-2">{item.sessionFee.toLocaleString('fa-IR')}</td>
                              <td className="p-2">{item.appliedRate}%</td>
                              <td className="p-2 font-semibold">{Math.round(item.doctorShare).toLocaleString('fa-IR')}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div className="md:hidden space-y-3 max-h-96 overflow-y-auto">
                        {doctorFinancialProfile.incomeDetails.map(item => (
                            <div key={item.id} className="bg-gray-50 p-3 rounded-lg border">
                                <p className="font-bold text-sm">{item.patientNames}</p>
                                <p className="text-xs text-gray-500">{formatToJalali(item.date)}</p>
                                <div className="mt-2 text-xs grid grid-cols-3 gap-1">
                                    <div><span className="font-semibold">مبلغ:</span> {item.sessionFee.toLocaleString('fa-IR')}</div>
                                    <div><span className="font-semibold">درصد:</span> {item.appliedRate}%</div>
                                    <div className="font-semibold text-green-700"><span className="text-gray-600">سهم:</span> {Math.round(item.doctorShare).toLocaleString('fa-IR')}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="text-lg font-semibold mb-2">پرداختی‌ها به پزشک</h4>
                    <div className="hidden md:block overflow-y-auto max-h-96">
                      <table className="w-full text-right text-sm">
                        <thead className="bg-gray-50 border-b sticky top-0">
                          <tr>
                            <th className="p-2 font-semibold">تاریخ</th>
                            <th className="p-2 font-semibold">شرح</th>
                            <th className="p-2 font-semibold">مبلغ</th>
                          </tr>
                        </thead>
                        <tbody>
                          {doctorFinancialProfile.paymentTransactions.map(item => (
                            <tr key={item.id} className="border-b hover:bg-gray-50">
                              <td className="p-2">{formatToJalali(item.date)}</td>
                              <td className="p-2">{item.description}</td>
                              <td className="p-2 font-semibold">{item.amount.toLocaleString('fa-IR')}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div className="md:hidden space-y-3 max-h-96 overflow-y-auto">
                        {doctorFinancialProfile.paymentTransactions.map(item => (
                            <div key={item.id} className="bg-gray-50 p-3 rounded-lg border">
                                <p className="font-bold text-sm">{item.description}</p>
                                <p className="text-xs text-gray-500">{formatToJalali(item.date)}</p>
                                <p className="mt-2 font-semibold">{item.amount.toLocaleString('fa-IR')} تومان</p>
                            </div>
                        ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
        </>
      )}

    </div>
  );
};

export default Reports;