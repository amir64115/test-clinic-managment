import React, { useState, useEffect, useRef } from 'react';

declare var jalaali: any;

interface IconProps {
  className?: string;
}

const createIcon = (svgContent: React.ReactNode): React.FC<IconProps> => ({ className = 'w-6 h-6' }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    strokeWidth={2}
  >
    {svgContent}
  </svg>
);

export const MenuIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />);
export const LogoutIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />);
export const UserIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />);
export const KeyIcon = createIcon(<path d="M15.5 7.879a2.5 2.5 0 10-3.536-3.535 2.5 2.5 0 003.536 3.535zM12.5 11.5L15 14h-.5a2 2 0 00-2 2v.5h-1.5v-1a2 2 0 00-2-2H8.5l2.5-2.5 1.5 1.5 1.5-1.5zM4 14.5l1-1h1.5v-1.5l1-1H10v1.5L11.5 15h1v1.5l1 1H15v1.5l1 1h.5v1h-11v-5h.5z" />);
export const DashboardIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2a4 4 0 00-4-4H3V7h2a4 4 0 004-4v-2m0 16l3 0m-3 0l-3 0m3-16l3 0m-3 0l-3 0M9 7l0 10m6-16v2a4 4 0 014 4h2v6h-2a4 4 0 01-4 4v2m0-16l-3 0m3 0l3 0m-3 16l-3 0m3 0l3 0m0-10l-10 0" />);
export const PatientsIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />);
export const DoctorsIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-2a6 6 0 00-12 0v2" />);
export const AppointmentsIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />);
export const FinancialIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />);
export const ReportsIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2a4 4 0 00-4-4H3V7h2a4 4 0 004-4v-2m0 16l3 0m-3 0l-3 0m3-16l3 0m-3 0l-3 0M9 7l0 10M15 7a2 2 0 012 2h2v6h-2a2 2 0 01-2-2V7z" />);
export const PersonnelIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-2a6 6 0 00-12 0v2" />);
export const BackupIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />);
export const SettingsIcon = createIcon(<><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066 2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></>);
export const TrashIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />);
export const DownloadIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />);
export const UploadIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />);
export const EditIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />);
export const UserCircleIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0z" />);
export const IdentificationIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 100 4h4a2 2 0 100-4h-4z" />);
export const DocumentTextIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />);
export const CalendarIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />);
export const StethoscopeIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h1a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.881 5.066A1 1 0 008.942 4h6.116a1 1 0 00.94-1.518l-2.719-4.35a1 1 0 00-1.684.025l-1.33 2.128-1.33-2.128a1 1 0 00-1.685-.025L7.88 5.066zM5 11a2 2 0 100 4 2 2 0 000-4z" />);
export const ShieldCheckIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 20.944A12.02 12.02 0 0012 22c4.64 0 8.563-2.986 10.057-7.056A11.952 11.952 0 0112 2.944a11.952 11.952 0 01-8.618 3.04z" />);
export const PhoneIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />);
export const PlusIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />);
export const SaveIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />);
export const BellIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />);
export const CalendarMonthIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />);
export const CalendarWeekIcon = createIcon(<><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /><path strokeLinecap="round" strokeLinejoin="round" d="M7 15h.01M12 15h.01M17 15h.01" /></>);
export const ClipboardListIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />);
export const ListViewIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16" />);
export const UsersIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-2a6 6 0 00-12 0v2" />);
export const ClockIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />);
export const CalendarDayIcon = createIcon(<><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /><circle cx="12" cy="15" r="1" /></>);
export const ChevronLeftIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />);
export const ChevronRightIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />);
export const ChevronDoubleLeftIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />);
export const ChevronDoubleRightIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" />);
export const TrendingUpIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />);
export const TrendingDownIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" />);
export const ChartBarIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />);
export const FilterIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293.707L3.293 7.293A1 1 0 013 6.586V4z" />);
export const ChevronDownIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />);
export const InfoCircleIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />);
export const MicrophoneIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />);
export const StopIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M5 5h14v14H5z" />);
export const CheckCircleIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />);
export const SendIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />);
export const ClipboardCopyIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />);
export const DocumentReportIcon = createIcon(<path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2a4 4 0 00-4-4H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V7a2 2 0 012-2h2a2 2 0 012 2v12a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />);
export const PhonePlusIcon = createIcon(<><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 7h6m-3-3v6" /></>);



const PERSIAN_MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

interface JalaliDatePickerProps {
  label: string;
  value: string; // ISO string 'YYYY-MM-DD'
  onChange: (date: string) => void;
  required?: boolean;
  minDate?: string;
  disabled?: boolean;
}

export const JalaliDatePicker: React.FC<JalaliDatePickerProps> = ({ label, value, onChange, required, minDate, disabled }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [displayDate, setDisplayDate] = useState(new Date());
  const datePickerRef = useRef<HTMLDivElement>(null);
  
  const [isJalaaliLoaded, setIsJalaaliLoaded] = useState(typeof jalaali !== 'undefined');

  useEffect(() => {
    if (isJalaaliLoaded) return;
    const interval = setInterval(() => {
      if (typeof jalaali !== 'undefined' && jalaali.toJalaali) {
        setIsJalaaliLoaded(true);
        clearInterval(interval);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [isJalaaliLoaded]);

  useEffect(() => {
    if (isJalaaliLoaded) {
      let initialDate;
      if (value) {
          const parts = value.split('-').map(Number);
          initialDate = new Date(parts[0], parts[1] - 1, parts[2]);
      } else {
          initialDate = new Date();
      }
      if (!isNaN(initialDate.getTime())) {
          setDisplayDate(initialDate);
      }
    }
  }, [value, isJalaaliLoaded]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (datePickerRef.current && !datePickerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!isJalaaliLoaded) {
    return (
        <div className="relative">
            <label className="block text-sm font-medium text-gray-700 mb-1">
                {label}
                {required && <span className="text-red-500 mr-1">*</span>}
            </label>
            <div className="relative">
                <div className="w-full p-2.5 border rounded-lg bg-gray-200 animate-pulse text-right h-[46px] flex items-center">
                    <span className="text-transparent">.</span>
                </div>
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <CalendarIcon className="h-5 w-5 text-gray-400" />
                </div>
            </div>
        </div>
    );
  }
  
  const jd = jalaali.toJalaali(displayDate);
  
  const getMonthMatrix = (date: Date): { date: Date, isCurrentMonth: boolean, jalaali: any }[][] => {
      const jd = jalaali.toJalaali(date);
      const { jy, jm } = jd;

      const firstDayOfMonthGregorianInfo = jalaali.toGregorian(jy, jm, 1);
      const firstDayOfMonthGregorian = new Date(firstDayOfMonthGregorianInfo.gy, firstDayOfMonthGregorianInfo.gm - 1, firstDayOfMonthGregorianInfo.gd);

      const firstDayOfWeek = (firstDayOfMonthGregorian.getDay() + 1) % 7; 

      const matrix: { date: Date, isCurrentMonth: boolean, jalaali: any }[][] = [];
      
      let currentDay = new Date(firstDayOfMonthGregorian);
      currentDay.setDate(currentDay.getDate() - firstDayOfWeek);

      for (let i = 0; i < 6; i++) {
        const week: { date: Date, isCurrentMonth: boolean, jalaali: any }[] = [];
        let hasCurrentMonthDay = false;
        for (let j = 0; j < 7; j++) {
          const currentJalaali = jalaali.toJalaali(currentDay);
          const isCurrentMonth = currentJalaali.jm === jm;
          if (isCurrentMonth) hasCurrentMonthDay = true;
          week.push({
            date: new Date(currentDay),
            isCurrentMonth: isCurrentMonth,
            jalaali: currentJalaali
          });
          currentDay.setDate(currentDay.getDate() + 1);
        }
        if (i > 3 && !hasCurrentMonthDay) continue;
        matrix.push(week);
      }
      return matrix;
  };
  
  const monthMatrix = getMonthMatrix(displayDate);

  const changeMonth = (amount: number) => {
    const currentJalaali = jalaali.toJalaali(displayDate);
    let newJm = currentJalaali.jm + amount;
    let newJy = currentJalaali.jy;
    
    if (newJm > 12) {
        newJm = 1;
        newJy += 1;
    } else if (newJm < 1) {
        newJm = 12;
        newJy -= 1;
    }

    const maxDays = jalaali.jalaaliMonthLength(newJy, newJm);
    const newJd = Math.min(currentJalaali.jd, maxDays);
    const gd = jalaali.toGregorian(newJy, newJm, newJd);
    setDisplayDate(new Date(gd.gy, gd.gm - 1, gd.gd));
  };

  const changeYear = (amount: number) => {
    const jd = jalaali.toJalaali(displayDate);
    const newJy = jd.jy + amount;
    const maxDays = jalaali.jalaaliMonthLength(newJy, jd.jm);
    const newJd = Math.min(jd.jd, maxDays);
    const gd = jalaali.toGregorian(newJy, jd.jm, newJd);
    setDisplayDate(new Date(gd.gy, gd.gm - 1, gd.gd));
  };

  const handleDayClick = (dayInfo: { date: Date }) => {
    const date = dayInfo.date;
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const isoDate = `${year}-${month}-${day}`;
    onChange(isoDate);
    setIsOpen(false);
  };

  const handleTitleClick = () => {
    setDisplayDate(new Date());
  };
  
  let formattedValue = '';
  if (value) {
      try {
        const parts = value.split('-').map(Number);
        const localDate = new Date(parts[0], parts[1] - 1, parts[2]);
        if (!isNaN(localDate.getTime())) {
          formattedValue = localDate.toLocaleDateString('fa-IR');
        }
      } catch(e) { /* ignore parse errors */ }
  }
  
  let minDateObj: Date | null = null;
  if (minDate) {
    try {
        const [y, m, d] = minDate.split('-').map(Number);
        minDateObj = new Date(y, m - 1, d);
        minDateObj.setHours(0, 0, 0, 0);
        if(isNaN(minDateObj.getTime())) minDateObj = null;
    } catch(e) {
        minDateObj = null;
    }
  }


  return (
    <div className="relative" ref={datePickerRef}>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
        {required && <span className="text-red-500 mr-1">*</span>}
      </label>
      <div className="relative">
        <input
            type="text"
            readOnly
            value={formattedValue}
            onClick={() => !disabled && setIsOpen(!isOpen)}
            className="w-full p-2.5 border rounded-lg bg-gray-50 cursor-pointer text-right disabled:bg-gray-200 disabled:cursor-not-allowed"
            required={required}
            disabled={disabled}
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <CalendarIcon className="h-5 w-5 text-gray-400" />
        </div>
      </div>
      
      {isOpen && (
        <div className="absolute z-20 mt-2 w-72 bg-white border rounded-lg shadow-lg p-2">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center">
                <button type="button" onClick={() => changeYear(-1)} className="p-1 rounded-full hover:bg-gray-100" title="سال قبل"><ChevronDoubleRightIcon className="w-5 h-5"/></button>
                <button type="button" onClick={() => changeMonth(-1)} className="p-1 rounded-full hover:bg-gray-100" title="ماه قبل"><ChevronRightIcon className="w-5 h-5"/></button>
            </div>
            <span onClick={handleTitleClick} className="font-semibold cursor-pointer hover:text-blue-600" title="رفتن به امروز">{PERSIAN_MONTH_NAMES[jd.jm - 1]} {jd.jy.toLocaleString('fa-IR', { useGrouping: false })}</span>
            <div className="flex items-center">
                <button type="button" onClick={() => changeMonth(1)} className="p-1 rounded-full hover:bg-gray-100" title="ماه بعد"><ChevronLeftIcon className="w-5 h-5"/></button>
                <button type="button" onClick={() => changeYear(1)} className="p-1 rounded-full hover:bg-gray-100" title="سال بعد"><ChevronDoubleLeftIcon className="w-5 h-5"/></button>
            </div>
          </div>
          <div className="grid grid-cols-7 text-center text-xs text-gray-500">
            {['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map(d => <div key={d} className="p-1">{d}</div>)}
          </div>
          <div className="grid grid-cols-7">
            {monthMatrix.flat().map((dayInfo, index) => {
              const isSelected = value && new Date(value).toDateString() === dayInfo.date.toDateString();
              
              let isBeforeMinDate = false;
              if (minDateObj) {
                  const dayDate = new Date(dayInfo.date);
                  dayDate.setHours(0, 0, 0, 0);
                  isBeforeMinDate = dayDate < minDateObj;
              }
              
              return (
                <button
                  key={index}
                  type="button"
                  onClick={() => handleDayClick(dayInfo)}
                  disabled={isBeforeMinDate}
                  className={`p-1 text-center text-sm rounded-full w-8 h-8 mx-auto my-0.5 ${
                    isBeforeMinDate 
                      ? 'text-gray-300 cursor-not-allowed' 
                      : dayInfo.isCurrentMonth 
                        ? 'text-gray-800 hover:bg-gray-100' 
                        : 'text-gray-400'
                  } ${isSelected && !isBeforeMinDate ? 'bg-blue-600 text-white hover:bg-blue-700' : ''}`}
                >
                  {dayInfo.jalaali.jd.toLocaleString('fa-IR', { useGrouping: false })}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};