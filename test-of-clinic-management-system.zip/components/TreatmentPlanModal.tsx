import React, { useState, useEffect } from 'react';
import type { Patient, Doctor, TreatmentPlan, TreatmentService, Personnel } from '../types';
import { PlusIcon, TrashIcon, SaveIcon } from './icons/Icons';
import VoiceEnabledTextarea from './VoiceEnabledTextarea';
import { TREATMENT_SERVICE_NAMES_DATA } from '../constants';

interface TreatmentPlanModalProps {
    isOpen: boolean;
    onClose: () => void;
    patient: Patient;
    doctorsAndTherapists: Doctor[];
    onSave: (plan: Omit<TreatmentPlan, 'id'>) => void;
    planToEdit?: TreatmentPlan | null;
    currentUser: Personnel;
    isReceptionEdit?: boolean;
}

const emptyPlan = (patientId: string): Omit<TreatmentPlan, 'id'> => ({
    patientId,
    createdAt: new Date().toISOString(),
    status: 'pending',
    services: [],
    notes: '',
});

const emptyService = (): Omit<TreatmentService, 'id'> => ({
    serviceName: '',
    sessions: 1,
    frequency: 'هفتگی',
    therapistIds: [],
});


const TreatmentPlanModal: React.FC<TreatmentPlanModalProps> = ({
    isOpen, onClose, patient, doctorsAndTherapists, onSave, planToEdit, currentUser, isReceptionEdit
}) => {
    const [formData, setFormData] = useState<Omit<TreatmentPlan, 'id'>>(() => planToEdit || emptyPlan(patient.id));

    useEffect(() => {
        if (isOpen) {
            setFormData(planToEdit || emptyPlan(patient.id));
        }
    }, [planToEdit, patient.id, isOpen]);


    if (!isOpen) return null;

    const handleAddService = () => {
        setFormData(prev => ({
            ...prev,
            services: [...prev.services, { ...emptyService(), id: String(Date.now()) }]
        }));
    };

    const handleRemoveService = (serviceId: string) => {
        setFormData(prev => ({
            ...prev,
            services: prev.services.filter(s => s.id !== serviceId)
        }));
    };

    const handleServiceChange = (serviceId: string, field: keyof Omit<TreatmentService, 'id' | 'therapistIds'>, value: any) => {
        setFormData(prev => ({
            ...prev,
            services: prev.services.map(s => s.id === serviceId ? { ...s, [field]: value } : s)
        }));
    };
    
    const handleTherapistChange = (serviceId: string, therapistId: string) => {
        setFormData(prev => ({
            ...prev,
            services: prev.services.map(s => {
                if (s.id === serviceId) {
                    const newTherapistIds = s.therapistIds.includes(therapistId)
                        ? s.therapistIds.filter(id => id !== therapistId)
                        : [...s.therapistIds, therapistId];
                    return { ...s, therapistIds: newTherapistIds };
                }
                return s;
            })
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.services.length === 0) {
            alert('حداقل یک خدمت درمانی باید اضافه شود.');
            return;
        }
        if (formData.services.some(s => !s.serviceName || s.sessions < 1 || s.therapistIds.length === 0)) {
            alert('لطفا تمام فیلدهای خدمات درمانی (نام، جلسات و درمانگر) را تکمیل کنید.');
            return;
        }
        onSave(formData);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" onClick={onClose}>
            <div className="flex items-center justify-center min-h-screen p-4">
                <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-3xl" onClick={(e) => e.stopPropagation()}>
                    <h3 className="text-2xl font-bold mb-2">
                        {planToEdit ? (isReceptionEdit ? 'ویرایش طرح درمان' : 'مشاهده طرح درمان') : 'ثبت طرح درمان جدید'}
                    </h3>
                    <p className="text-gray-600 mb-6">برای بیمار: <span className="font-semibold">{patient.name}</span></p>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="p-4 border rounded-lg bg-gray-50/50">
                            <h4 className="font-bold text-gray-800 mb-3">خدمات درمانی مورد نیاز</h4>
                            <div className="space-y-4">
                                {formData.services.map(service => {
                                    const isStandardService = TREATMENT_SERVICE_NAMES_DATA.includes(service.serviceName);

                                    return (
                                        <div key={service.id} className="p-4 border rounded-lg bg-white">
                                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
                                                <div className="w-full">
                                                    <select
                                                        value={isStandardService ? service.serviceName : 'سایر'}
                                                        onChange={e => {
                                                            const value = e.target.value;
                                                            handleServiceChange(service.id, 'serviceName', value === 'سایر' ? '' : value);
                                                        }}
                                                        className="w-full p-2 border rounded-lg"
                                                        required={isStandardService && !service.serviceName}
                                                    >
                                                        <option value="" disabled>انتخاب خدمت...</option>
                                                        {TREATMENT_SERVICE_NAMES_DATA.map(name => (
                                                            <option key={name} value={name}>{name}</option>
                                                        ))}
                                                        <option value="سایر">سایر...</option>
                                                    </select>
                                                    {!isStandardService && (
                                                        <input
                                                            type="text"
                                                            placeholder="نام خدمت سفارشی"
                                                            value={service.serviceName}
                                                            onChange={e => handleServiceChange(service.id, 'serviceName', e.target.value)}
                                                            className="w-full p-2 border rounded-lg mt-2"
                                                            required
                                                        />
                                                    )}
                                                </div>
                                                <div className="grid grid-cols-2 gap-2">
                                                    <input
                                                        type="number"
                                                        min="1"
                                                        placeholder="تعداد"
                                                        value={service.sessions}
                                                        onChange={e => handleServiceChange(service.id, 'sessions', parseInt(e.target.value) || 1)}
                                                        className="w-full p-2 border rounded-lg"
                                                        required
                                                    />
                                                    <select
                                                        value={service.frequency}
                                                        onChange={e => handleServiceChange(service.id, 'frequency', e.target.value as 'هفتگی' | 'ماهانه')}
                                                        className="w-full p-2 border rounded-lg bg-gray-50 h-full"
                                                    >
                                                        <option value="هفتگی">در هفته</option>
                                                        <option value="ماهانه">در ماه</option>
                                                    </select>
                                                </div>
                                                <button
                                                    type="button"
                                                    onClick={() => handleRemoveService(service.id)}
                                                    className="text-red-600 hover:bg-red-50 p-2 rounded-lg text-sm flex items-center justify-center gap-2"
                                                >
                                                    <TrashIcon className="w-5 h-5" /> حذف خدمت
                                                </button>
                                            </div>
                                            <div className="mt-3">
                                                <p className="text-sm font-semibold mb-2 text-gray-700">انتخاب درمانگر(ان)</p>
                                                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                                                    {doctorsAndTherapists.map(therapist => (
                                                        <label key={therapist.id} className={`flex items-center gap-2 p-2 text-sm rounded-lg cursor-pointer border-2 transition ${service.therapistIds.includes(therapist.id) ? 'border-blue-500 bg-blue-50' : 'border-transparent bg-gray-100 hover:bg-gray-200'}`}>
                                                            <input type="checkbox" checked={service.therapistIds.includes(therapist.id)} onChange={() => handleTherapistChange(service.id, therapist.id)} className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500" />
                                                            {therapist.name}
                                                        </label>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                            <button type="button" onClick={handleAddService} className="mt-4 bg-gray-200 text-gray-800 px-4 py-2 text-sm rounded-lg hover:bg-gray-300 flex items-center gap-2">
                                <PlusIcon className="w-5 h-5"/> افزودن خدمت جدید
                            </button>
                        </div>
                        <div>
                            <label className="block text-gray-700 font-semibold mb-1">یادداشت پزشک (اختیاری)</label>
                            <VoiceEnabledTextarea
                                value={formData.notes || ''}
                                onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                                className="w-full p-2 border rounded-lg"
                                rows={3}
                                placeholder="توضیحات تکمیلی برای پذیرش..."
                            />
                        </div>
                         <div className="flex justify-end mt-6 pt-4 border-t">
                            <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">بستن</button>
                            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2">
                                <SaveIcon className="w-5 h-5"/> ذخیره طرح درمان
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default TreatmentPlanModal;