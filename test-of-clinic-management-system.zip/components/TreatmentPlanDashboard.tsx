
import React, { useState, useMemo } from 'react';
import type { TreatmentPlan, Patient, Personnel, Doctor } from '../types';
import { formatToJalali } from '../utils/dateUtils';
import { EditIcon, CheckCircleIcon, TrashIcon, ChevronDownIcon, ClipboardListIcon } from './icons/Icons';
import TreatmentPlanModal from './TreatmentPlanModal';

interface TreatmentPlanDashboardProps {
    treatmentPlans: TreatmentPlan[];
    updateTreatmentPlan: (plan: TreatmentPlan) => Promise<TreatmentPlan>;
    patients: Patient[];
    personnel: Personnel[];
    doctors: Doctor[];
    currentUser: Personnel;
}

const TreatmentPlanDashboard: React.FC<TreatmentPlanDashboardProps> = ({
    treatmentPlans, updateTreatmentPlan, patients, personnel, doctors, currentUser
}) => {
    const [activeTab, setActiveTab] = useState<'pending' | 'confirmed' | 'archived'>('pending');
    const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
    const [editingPlan, setEditingPlan] = useState<TreatmentPlan | null>(null);

    const pendingPlans = useMemo(() => 
        treatmentPlans.filter(p => p.status === 'pending')
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
        [treatmentPlans]
    );

    const confirmedPlans = useMemo(() => 
        treatmentPlans.filter(p => p.status === 'confirmed')
        .sort((a, b) => new Date(b.confirmedAt || b.createdAt).getTime() - new Date(a.confirmedAt || b.createdAt).getTime()),
        [treatmentPlans]
    );
    
    const archivedPlans = useMemo(() => 
        treatmentPlans.filter(p => p.status === 'archived')
        .sort((a, b) => new Date(b.confirmedAt || b.createdAt).getTime() - new Date(a.confirmedAt || b.createdAt).getTime()),
        [treatmentPlans]
    );

    const getPatientName = (id: string) => patients.find(p => p.id === id)?.name || `بیمار #${id}`;
    const getPersonnelName = (id: string) => personnel.find(p => p.id === id)?.name || `کاربر #${id}`;
    
    const getDoctorName = (id?: string) => {
        if (!id) return 'نامشخص';
        // First, try to find by doctor ID directly. This will work for new, correct data.
        let doctor = doctors.find(d => d.id === id);
        if (doctor) return doctor.name;
    
        // If not found, it might be an old record with a Personnel ID.
        // Find the personnel with that ID.
        const person = personnel.find(p => p.id === id);
        if (person) {
            // Now, find the doctor with the same name as the personnel.
            doctor = doctors.find(d => d.name === person.name);
            if (doctor) return doctor.name;
        }
    
        // If still not found, return the fallback.
        return `پزشک #${id}`;
    };

    const handleOpenEditModal = (plan: TreatmentPlan) => {
        setEditingPlan(plan);
        setIsPlanModalOpen(true);
    };
    
    const handleSavePlan = async (planData: Omit<TreatmentPlan, 'id'>) => {
        if (editingPlan) {
            try {
                await updateTreatmentPlan({ ...planData, id: editingPlan.id });
            } catch (error) {
                console.error("Failed to update plan", error);
            }
        }
        setIsPlanModalOpen(false);
        setEditingPlan(null);
    };

    const handleConfirmPlan = (plan: TreatmentPlan) => {
        if(window.confirm('آیا از تایید این طرح درمانی اطمینان دارید؟')) {
            const updatedPlan: TreatmentPlan = {
                ...plan,
                status: 'confirmed',
                confirmedById: currentUser.id,
                confirmedAt: new Date().toISOString()
            };
            updateTreatmentPlan(updatedPlan);
        }
    };

    const handleCancelPlan = (plan: TreatmentPlan) => {
        const reason = prompt("لطفا دلیل انصراف یا لغو طرح درمانی را وارد کنید (مثلا: عدم تطابق زمانی بیمار):");
        if (reason && reason.trim()) {
            const updatedPlan: TreatmentPlan = {
                ...plan,
                status: 'cancelled',
                cancellationReason: reason.trim(),
                cancelledById: currentUser.id,
                cancelledAt: new Date().toISOString()
            };
            updateTreatmentPlan(updatedPlan);
        } else if (reason !== null) { // Not cancelled prompt
            alert('دلیل لغو اجباری است.');
        }
    };
    
    const canManagePlans = currentUser.role === 'مدیر' || currentUser.role === 'منشی';

    return (
        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md border">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <ClipboardListIcon className="w-6 h-6 text-indigo-500"/>
                ارزیابی و طرح درمان
            </h3>
            
            <div className="mb-4">
                {/* Mobile Dropdown */}
                <div className="sm:hidden">
                    <label htmlFor="treatment-plan-tabs" className="sr-only">انتخاب تب</label>
                    <select
                        id="treatment-plan-tabs"
                        name="tabs"
                        className="block w-full rounded-lg border-gray-300 py-2.5 pl-3 pr-10 text-base focus:border-indigo-500 focus:outline-none focus:ring-indigo-500"
                        onChange={(e) => setActiveTab(e.target.value as 'pending' | 'confirmed' | 'archived')}
                        value={activeTab}
                    >
                        <option value="pending">{`در انتظار تایید (${pendingPlans.length.toLocaleString('fa-IR')})`}</option>
                        <option value="confirmed">{`آماده نوبت‌دهی (${confirmedPlans.length.toLocaleString('fa-IR')})`}</option>
                        <option value="archived">{`بایگانی شده (${archivedPlans.length.toLocaleString('fa-IR')})`}</option>
                    </select>
                </div>

                {/* Desktop Tabs */}
                <div className="hidden sm:block">
                    <div className="border-b border-gray-200">
                        <nav className="-mb-px flex space-x-4 space-x-reverse" aria-label="Tabs">
                            <button onClick={() => setActiveTab('pending')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${activeTab === 'pending' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                                در انتظار تایید <span className="bg-yellow-400 text-yellow-900 text-xs font-bold rounded-full px-2 py-0.5">{pendingPlans.length.toLocaleString('fa-IR')}</span>
                            </button>
                            <button onClick={() => setActiveTab('confirmed')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${activeTab === 'confirmed' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                                آماده نوبت‌دهی <span className="bg-green-400 text-green-900 text-xs font-bold rounded-full px-2 py-0.5">{confirmedPlans.length.toLocaleString('fa-IR')}</span>
                            </button>
                            <button onClick={() => setActiveTab('archived')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${activeTab === 'archived' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                                بایگانی شده <span className="bg-gray-400 text-gray-900 text-xs font-bold rounded-full px-2 py-0.5">{archivedPlans.length.toLocaleString('fa-IR')}</span>
                            </button>
                        </nav>
                    </div>
                </div>
            </div>
            
            <div className="max-h-96 overflow-y-auto pr-2 -mr-2 space-y-3">
                {activeTab === 'pending' && (pendingPlans.length > 0 ? pendingPlans.map(plan => (
                    <div key={plan.id} className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                        <div className="flex justify-between items-start">
                            <div>
                                <p className="font-bold text-sm text-yellow-900">{getPatientName(plan.patientId)}</p>
                                <p className="text-xs text-yellow-700 mt-1">
                                    {plan.referringDoctorId && `ارجاع از: ${getDoctorName(plan.referringDoctorId)} - `}
                                    ایجاد در {formatToJalali(plan.createdAt)}
                                </p>
                            </div>
                            {canManagePlans && (
                                <div className="flex items-center gap-1">
                                    <button onClick={() => handleOpenEditModal(plan)} className="p-1.5 rounded-full hover:bg-yellow-100" title="ویرایش/مشاهده جزئیات"><EditIcon className="w-5 h-5 text-yellow-800"/></button>
                                    <button onClick={() => handleConfirmPlan(plan)} className="p-1.5 rounded-full hover:bg-green-100" title="تایید طرح"><CheckCircleIcon className="w-5 h-5 text-green-600"/></button>
                                    <button onClick={() => handleCancelPlan(plan)} className="p-1.5 rounded-full hover:bg-red-100" title="لغو طرح"><TrashIcon className="w-5 h-5 text-red-600"/></button>
                                </div>
                            )}
                        </div>
                    </div>
                )) : <p className="text-center text-sm text-gray-500 py-4">طرح درمانی در انتظار تایید وجود ندارد.</p>)}

                {activeTab === 'confirmed' && (confirmedPlans.length > 0 ? confirmedPlans.map(plan => (
                     <div key={plan.id} className="bg-green-50 p-3 rounded-lg border border-green-200">
                        <div className="flex justify-between items-start">
                             <div>
                                <p className="font-bold text-sm text-green-900">{getPatientName(plan.patientId)}</p>
                                <p className="text-xs text-green-700 mt-1">تایید شده توسط: {getPersonnelName(plan.confirmedById!)} در تاریخ {formatToJalali(plan.confirmedAt!)}</p>
                            </div>
                             <button onClick={() => handleOpenEditModal(plan)} className="p-1.5 rounded-full hover:bg-green-100" title="مشاهده جزئیات"><ChevronDownIcon className="w-5 h-5 text-green-800"/></button>
                        </div>
                    </div>
                )) : <p className="text-center text-sm text-gray-500 py-4">هیچ طرح درمانی آماده نوبت‌دهی نیست.</p>)}

                {activeTab === 'archived' && (archivedPlans.length > 0 ? archivedPlans.map(plan => (
                     <div key={plan.id} className="bg-gray-50 p-3 rounded-lg border border-gray-200 opacity-70">
                        <div className="flex justify-between items-start">
                             <div>
                                <p className="font-bold text-sm text-gray-700">{getPatientName(plan.patientId)}</p>
                                <p className="text-xs text-gray-500 mt-1">تایید شده در: {plan.confirmedAt ? formatToJalali(plan.confirmedAt) : '-'}</p>
                            </div>
                             <button onClick={() => handleOpenEditModal(plan)} className="p-1.5 rounded-full hover:bg-gray-100" title="مشاهده جزئیات"><ChevronDownIcon className="w-5 h-5 text-gray-600"/></button>
                        </div>
                    </div>
                )) : <p className="text-center text-sm text-gray-500 py-4">هیچ طرح درمانی بایگانی نشده است.</p>)}
            </div>

            {isPlanModalOpen && editingPlan && (
                <TreatmentPlanModal
                    isOpen={isPlanModalOpen}
                    onClose={() => { setIsPlanModalOpen(false); setEditingPlan(null); }}
                    patient={patients.find(p => p.id === editingPlan.patientId)!}
                    doctorsAndTherapists={doctors}
                    onSave={handleSavePlan}
                    planToEdit={editingPlan}
                    currentUser={currentUser}
                    isReceptionEdit={canManagePlans}
                />
            )}
        </div>
    );
};

export default TreatmentPlanDashboard;
