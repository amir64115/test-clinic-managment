
import React, { useMemo } from 'react';
import { PatientsIcon, DoctorsIcon, PersonnelIcon, AppointmentsIcon, FinancialIcon, ReportsIcon, ClipboardListIcon } from './icons/Icons';
import type { AppView, AppPermissions, Personnel, RolePermissions, TreatmentPlan, Patient, Doctor, Appointment } from '../types';
import { formatToJalali } from '../utils/dateUtils';

interface DashboardProps {
  setCurrentView: (view: AppView) => void;
  currentUser: Personnel;
  permissions: AppPermissions;
  personnel: Personnel[];
  treatmentPlans: TreatmentPlan[];
  updateTreatmentPlan: (plan: TreatmentPlan) => Promise<TreatmentPlan>;
  patients: Patient[];
  doctors: Doctor[];
  appointments?: Appointment[]; // Optional since it might be added later, but we need it here
}

const Dashboard: React.FC<DashboardProps> = ({ 
  setCurrentView, currentUser, permissions, personnel,
  treatmentPlans, updateTreatmentPlan, patients, doctors, appointments = []
}) => {
  const navItems = useMemo(() => {
    const allItems = [
      { name: 'patients' as AppView, label: 'بیماران', icon: PatientsIcon, description: 'مدیریت پرونده‌ها، اطلاعات و سوابق بیماران', color: 'text-blue-500' },
      { name: 'doctors' as AppView, label: 'پزشکان', icon: DoctorsIcon, description: 'مدیریت اطلاعات و پروفایل پزشکان و درمانگران', color: 'text-green-500' },
      { name: 'personnel' as AppView, label: 'پرسنل', icon: PersonnelIcon, description: 'مدیریت اطلاعات کارکنان کلینیک', color: 'text-orange-500' },
      { name: 'appointments' as AppView, label: 'نوبت‌دهی', icon: AppointmentsIcon, description: 'زمان‌بندی، مشاهده و مدیریت تمام نوبت‌ها', color: 'text-purple-500' },
      { name: 'financial' as AppView, label: 'مالی', icon: FinancialIcon, description: 'ثبت درآمدها، هزینه‌ها و مدیریت حساب‌ها', color: 'text-teal-500' },
      { name: 'reports' as AppView, label: 'گزارشات', icon: ReportsIcon, description: 'تحلیل عملکرد مالی و آماری کلینیک', color: 'text-indigo-500' },
    ];

    const userRole = currentUser.role || '';
    const userPermissions = permissions[userRole] || {};
    
    return allItems.filter(item => !!userPermissions[item.name as keyof RolePermissions]?.view);
  }, [currentUser, permissions]);
  
  const waitingList = useMemo(() => {
      return appointments.filter(app => app.status === 'Waiting');
  }, [appointments]);

  const getPatientName = (id: string) => patients.find(p => p.id === id)?.name || `بیمار #${id}`;
  const getDoctorName = (id: string) => doctors.find(d => d.id === id)?.name || `پزشک #${id}`;

  const getDoctorFrequencyLabel = (appointment: Appointment, doctorId: string) => {
      const doctorName = doctors.find(d => d.id === doctorId)?.name || 'نامشخص';
      
      // 1. Check Appointment suggestedServices first (manual entry)
      if (appointment.suggestedServices) {
          const service = appointment.suggestedServices.find(s => s.doctorId === doctorId);
          if (service) {
              return `${doctorName} (x${service.count})`;
          }
      }

      // 2. Fallback to Treatment Plans if needed
      const patientId = appointment.patientIds[0];
      if (!patientId) return doctorName;

      const activePlan = treatmentPlans.find(p => p.patientId === patientId && p.status === 'confirmed');
      if (!activePlan) return doctorName;

      const service = activePlan.services.find(s => s.therapistIds.includes(doctorId));
      if (service && service.sessions > 0) {
          return `${doctorName} (x${service.sessions})`;
      }
      
      return doctorName;
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2 text-gray-800">داشبورد اصلی</h2>
        <p className="text-gray-600">به سیستم مدیریت کلینیک خوش آمدید, {currentUser.name}.</p>
      </div>
      
      {/* Waiting List Section - Replacing TreatmentPlanDashboard */}
      <div className="bg-white p-6 rounded-xl shadow-md border">
          <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                  <ClipboardListIcon className="w-6 h-6 text-yellow-600"/>
                  لیست انتظار نوبت
                  <span className="bg-yellow-100 text-yellow-800 text-xs font-bold px-2 py-1 rounded-full">{waitingList.length}</span>
              </h3>
              <button 
                  onClick={() => setCurrentView('appointments')} 
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
              >
                  مدیریت نوبت‌ها &rarr;
              </button>
          </div>
          
          {waitingList.length > 0 ? (
              <div className="overflow-x-auto">
                  <table className="w-full text-right text-sm">
                      <thead className="bg-gray-50 border-b">
                          <tr>
                              <th className="p-3 font-semibold text-gray-600">بیمار</th>
                              <th className="p-3 font-semibold text-gray-600">درخواست</th>
                              <th className="p-3 font-semibold text-gray-600">درمانگر پیشنهادی</th>
                              <th className="p-3 font-semibold text-gray-600">تاریخ ثبت</th>
                          </tr>
                      </thead>
                      <tbody>
                          {waitingList.slice(0, 5).map(app => (
                              <tr key={app.id} className="border-b last:border-0 hover:bg-gray-50">
                                  <td className="p-3 font-medium text-gray-800">
                                      {app.patientIds.map(id => getPatientName(id)).join(', ')}
                                  </td>
                                  <td className="p-3 text-gray-600">{app.notes || 'بدون توضیحات'}</td>
                                  <td className="p-3">
                                      {app.doctorId ? (
                                          <span className="text-blue-600 font-medium">{getDoctorName(app.doctorId)}</span>
                                      ) : (
                                          (app.suggestedServices?.length || app.suggestedDoctorIds?.length) ? (
                                              <div className="flex flex-wrap gap-1">
                                                  {(app.suggestedServices || []).map(service => (
                                                      <span key={service.doctorId} className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-xs border border-blue-100">
                                                          {getDoctorFrequencyLabel(app, service.doctorId)}
                                                      </span>
                                                  ))}
                                                  {(!app.suggestedServices || app.suggestedServices.length === 0) && app.suggestedDoctorIds?.map(id => (
                                                      <span key={id} className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-xs border border-blue-100">
                                                          {getDoctorFrequencyLabel(app, id)}
                                                      </span>
                                                  ))}
                                              </div>
                                          ) : <span className="text-gray-400 italic">نامشخص</span>
                                      )}
                                  </td>
                                  <td className="p-3 text-gray-500">
                                      {app.dateAddedToWaitingList ? formatToJalali(app.dateAddedToWaitingList) : '-'}
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
                  {waitingList.length > 5 && (
                      <div className="mt-3 text-center">
                          <span className="text-xs text-gray-500">نمایش ۵ مورد از {waitingList.length} مورد</span>
                      </div>
                  )}
              </div>
          ) : (
              <p className="text-center text-gray-500 py-6 bg-gray-50 rounded-lg">هیچ بیماری در لیست انتظار وجود ندارد.</p>
          )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {navItems.map(item => (
          <div 
            key={item.name}
            onClick={() => setCurrentView(item.name)}
            className="bg-white p-6 rounded-xl shadow-md border-t-4 border-transparent hover:border-blue-500 hover:shadow-lg transition-all transform hover:-translate-y-1 cursor-pointer"
          >
            <item.icon className={`w-10 h-10 mb-4 ${item.color}`} />
            <h3 className="text-xl font-bold text-gray-900 mb-2">{item.label}</h3>
            <p className="text-gray-600 text-sm">{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
