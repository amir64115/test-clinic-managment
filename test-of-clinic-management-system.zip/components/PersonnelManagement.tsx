
import React, { useState, useMemo } from 'react';
import type { Personnel, PermissionSet, AppPermissions } from '../types';
import { TrashIcon, EditIcon, UserCircleIcon, JalaliDatePicker, KeyIcon, UserIcon as UserInputIcon } from './icons/Icons';

interface PersonnelManagementProps {
  personnel: Personnel[];
  permissions: PermissionSet;
  allPermissions: AppPermissions;
  addPersonnel: (personnel: Omit<Personnel, 'id'>) => Promise<Personnel>;
  updatePersonnel: (personnel: Personnel) => Promise<Personnel>;
  deletePersonnel: (id: number | string) => Promise<void>;
}

const emptyPersonnel: Omit<Personnel, 'id'> = {
  name: '',
  nationalId: '',
  phone: '',
  role: '',
  employmentDate: new Date().toISOString().split('T')[0],
  age: 25,
  photoUrl: '',
  username: '',
  password: '',
};

const PersonnelManagement: React.FC<PersonnelManagementProps> = ({ personnel, permissions, allPermissions, addPersonnel, updatePersonnel, deletePersonnel }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<Personnel, 'id'>>(emptyPersonnel);
  const [editingPersonnel, setEditingPersonnel] = useState<Personnel | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const existingRoles = useMemo(() => {
    // Get roles from the permissions object for consistency, filter out the admin role which can't be assigned
    return Object.keys(allPermissions).filter(role => role !== 'مدیر').sort((a, b) => a.localeCompare(b, 'fa'));
  }, [allPermissions]);
  
  const validPersonnel = useMemo(() => {
    // Filter out any invalid objects that might have polluted the personnel data
    return personnel.filter(p => p && p.id && p.username && p.name);
  }, [personnel]);
  

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'age' ? (parseInt(value) || 0) : value }));
  };
  
  const handleDateChange = (name: string, date: string) => {
    setFormData(prev => ({ ...prev, [name]: date }));
  };

  const handleFile = (file: File | null) => {
    if (!file) return;

    const MAX_SIZE_KB = 100;
    const MAX_SIZE_BYTES = MAX_SIZE_KB * 1024;

    if (file.size > MAX_SIZE_BYTES) {
      alert(`حجم عکس نباید بیشتر از ${MAX_SIZE_KB} کیلوبایت باشد.`);
      return;
    }

    if (!['image/png', 'image/jpeg'].includes(file.type)) {
        alert('لطفا یک فایل با فرمت JPG یا PNG انتخاب کنید.');
        return;
    }
    
    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({...prev, photoUrl: reader.result as string}));
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFile(e.target.files ? e.target.files[0] : null);
    if(e.target) e.target.value = '';
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); handleFile(e.dataTransfer.files?.[0] || null); };
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); };
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); };
  const handleRemovePhoto = () => setFormData(prev => ({ ...prev, photoUrl: '' }));


  const closeModal = () => {
    setIsModalOpen(false);
    setEditingPersonnel(null);
    setFormData(emptyPersonnel);
  };

  const openAddModal = () => {
    setEditingPersonnel(null);
    setFormData(emptyPersonnel);
    setIsModalOpen(true);
  };

  const openEditModal = (person: Personnel) => {
    setEditingPersonnel(person);
    setFormData({ ...person, password: '' });
    setIsModalOpen(true);
  };

  const handleSavePersonnel = async (e: React.FormEvent) => {
    e.preventDefault();

    const finalData = { ...formData };

    if (!finalData.name || !finalData.nationalId || !finalData.phone || !finalData.role || !finalData.employmentDate || !finalData.age || finalData.age <= 0 || !finalData.username) {
        alert("لطفا تمام فیلدهای ستاره‌دار را تکمیل کنید.");
        return;
    }
    if (!editingPersonnel && !finalData.password) {
        alert("لطفا برای کاربر جدید یک رمز عبور تعیین کنید.");
        return;
    }
     if (finalData.password && finalData.password.length < 5) {
        alert("رمز عبور باید حداقل ۵ کاراکتر باشد.");
        return;
    }

    const isUsernameTaken = personnel.some(p => 
        p.username.toLowerCase() === finalData.username.toLowerCase() && 
        p.id !== editingPersonnel?.id
    );
    if (isUsernameTaken) {
        alert("این نام کاربری قبلا استفاده شده است. لطفا نام دیگری انتخاب کنید.");
        return;
    }

    try {
        if (editingPersonnel) {
            const finalPassword = finalData.password ? finalData.password : editingPersonnel.password;
            const updatedPerson = { ...finalData, id: editingPersonnel.id, password: finalPassword };
            await updatePersonnel(updatedPerson);
        } else {
            await addPersonnel(finalData as Omit<Personnel, 'id'>);
        }
        closeModal();
    } catch (error) {
        console.error("Save personnel failed:", error);
    }
  };
  
  const handleDeletePersonnel = async (id: string) => {
    if(window.confirm('آیا از حذف این شخص از پرسنل اطمینان دارید؟')) {
       await deletePersonnel(id);
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h2 className="text-2xl sm:text-3xl font-bold">مدیریت پرسنل و کاربران</h2>
        <div className="flex items-center gap-2">
            {permissions.add && (
              <button onClick={openAddModal} className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                افزودن کاربر
              </button>
            )}
        </div>
      </div>

      <div className="bg-white p-2 sm:p-6 rounded-lg shadow-md">
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-3 text-sm font-semibold tracking-wide"></th>
                <th className="p-3 text-sm font-semibold tracking-wide">نام</th>
                <th className="p-3 text-sm font-semibold tracking-wide">سمت</th>
                <th className="p-3 text-sm font-semibold tracking-wide">نام کاربری</th>
                <th className="p-3 text-sm font-semibold tracking-wide">شماره تماس</th>
                <th className="p-3 text-sm font-semibold tracking-wide">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {validPersonnel.map(person => (
                <tr key={person.id} className="border-b hover:bg-gray-50">
                  <td className="p-2">
                    {person.photoUrl ? <img src={person.photoUrl} alt={person.name} className="w-12 h-12 rounded-full object-cover"/> : <UserCircleIcon className="w-12 h-12 text-gray-300"/>}
                  </td>
                  <td className="p-3 font-semibold">{person.name}</td>
                  <td className="p-3">{person.role}</td>
                  <td className="p-3 font-mono text-sm text-gray-600">{person.username}</td>
                  <td className="p-3">{person.phone}</td>
                  <td className="p-3 flex items-center space-x-2 space-x-reverse">
                     {permissions.edit && (
                       <button onClick={() => openEditModal(person)} className="text-gray-500 hover:text-green-600 p-1" title="ویرایش">
                          <EditIcon className="w-6 h-6" />
                       </button>
                     )}
                     {permissions.delete && (
                      <button onClick={() => handleDeletePersonnel(person.id)} className="text-gray-500 hover:text-red-600 p-1" title="حذف">
                          <TrashIcon className="w-6 h-6" />
                      </button>
                     )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="md:hidden space-y-4">
            {validPersonnel.map(person => (
                <div key={person.id} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                           {person.photoUrl ? <img src={person.photoUrl} alt={person.name} className="w-14 h-14 rounded-full object-cover ml-3"/> : <UserCircleIcon className="w-14 h-14 text-gray-300 ml-3"/>}
                           <div>
                              <p className="font-bold text-lg">{person.name}</p>
                              <p className="text-sm text-gray-600">{person.role}</p>
                           </div>
                        </div>
                         <div className="flex items-center space-x-1 space-x-reverse">
                            {permissions.edit && (
                              <button onClick={() => openEditModal(person)} className="text-gray-500 hover:text-green-600 p-2" title="ویرایش">
                                  <EditIcon className="w-6 h-6" />
                              </button>
                            )}
                            {permissions.delete && (
                              <button onClick={() => handleDeletePersonnel(person.id)} className="text-gray-500 hover:text-red-600 p-2" title="حذف">
                                  <TrashIcon className="w-6 h-6"/>
                              </button>
                            )}
                        </div>
                    </div>
                    <div className="text-sm space-y-1">
                        <p><span className="font-semibold">نام کاربری:</span> {person.username}</p>
                        <p><span className="font-semibold">تلفن:</span> {person.phone}</p>
                    </div>
                </div>
            ))}
        </div>
         {validPersonnel.length === 0 && <p className="text-center text-gray-500 py-8">هیچ پرسنلی ثبت نشده است.</p>}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" onClick={closeModal}>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-3xl" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-2xl font-bold mb-6">{editingPersonnel ? 'ویرایش کاربر' : 'افزودن کاربر جدید'}</h3>
              <form onSubmit={handleSavePersonnel}>
                <div className="flex flex-col md:flex-row gap-8">
                    {/* Left Column */}
                    <div className="w-full md:w-1/3 md:border-l-2 md:pl-8 flex flex-col items-center space-y-6">
                         <div 
                            className={`relative group w-40 h-40 border-2 border-dashed rounded-full flex justify-center items-center cursor-pointer transition-colors ${isDragging ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-500 hover:bg-gray-50'}`}
                            onClick={() => document.getElementById('photo-upload-personnel')?.click()}
                            onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}
                          >
                            <input type="file" id="photo-upload-personnel" accept="image/png, image/jpeg" onChange={handlePhotoChange} className="hidden" />
                            {formData.photoUrl ? (
                                <>
                                    <img src={formData.photoUrl} alt="Preview" className="w-full h-full rounded-full object-cover" />
                                    <button type="button" onClick={(e) => { e.stopPropagation(); handleRemovePhoto(); }} className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity" title="حذف عکس"><TrashIcon className="w-4 h-4" /></button>
                                </>
                            ) : (
                                <div className="text-center text-gray-500 p-4"><UserCircleIcon className="w-16 h-16 mx-auto text-gray-400" /><p className="mt-2 text-xs">انتخاب یا کشیدن عکس</p></div>
                            )}
                        </div>
                        
                        <div className="w-full space-y-4">
                            <h4 className="font-semibold text-gray-700 text-center border-b pb-2">اطلاعات ورود</h4>
                            <div>
                                <label className="block text-gray-700 text-sm font-semibold mb-2">نام کاربری<span className="text-red-500 mr-1">*</span></label>
                                <div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3"><UserInputIcon className="h-5 w-5 text-gray-400" /></span><input type="text" name="username" value={formData.username} onChange={handleInputChange} className="w-full p-2 pl-10 border rounded-lg font-mono" required /></div>
                            </div>
                            <div>
                                <label className="block text-gray-700 text-sm font-semibold mb-2">رمز عبور{editingPersonnel ? <span className="text-gray-500 text-xs mr-1">(برای تغییر)</span> : <span className="text-red-500 mr-1">*</span>}</label>
                                <div className="relative">
                                    <span className="absolute inset-y-0 left-0 flex items-center pl-3"><KeyIcon className="h-5 w-5 text-gray-400" /></span>
                                    <input
                                        type="password"
                                        name="password"
                                        value={formData.password || ''}
                                        onChange={handleInputChange}
                                        className="w-full p-2 pl-10 border rounded-lg"
                                        placeholder={editingPersonnel ? 'برای عدم تغییر، خالی بگذارید' : ''}
                                        required={!editingPersonnel}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {/* Right Column */}
                    <div className="w-full md:w-2/3 space-y-6">
                        <div className="space-y-4">
                             <h4 className="font-semibold text-gray-700 border-b pb-2">اطلاعات شخصی و شغلی</h4>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div><label className="block text-gray-700 text-sm font-semibold mb-2">نام کامل<span className="text-red-500 mr-1">*</span></label><input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required /></div>
                                <div>
                                  <label className="block text-gray-700 text-sm font-semibold mb-2">سمت (نقش)<span className="text-red-500 mr-1">*</span></label>
                                    <select name="role" value={formData.role} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg bg-gray-50" required>
                                        <option value="" disabled>یک سمت را انتخاب کنید</option>
                                        {existingRoles.map(r => <option key={r} value={r}>{r}</option>)}
                                    </select>
                                    <p className="text-xs text-gray-500 mt-1">برای مدیریت نقش‌ها به بخش <span className="font-semibold">تنظیمات</span> مراجعه کنید.</p>
                                </div>
                            </div>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div><label className="block text-gray-700 text-sm font-semibold mb-2">کد ملی<span className="text-red-500 mr-1">*</span></label><input type="text" name="nationalId" value={formData.nationalId} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required /></div>
                                <div><label className="block text-gray-700 text-sm font-semibold mb-2">شماره تماس<span className="text-red-500 mr-1">*</span></label><input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required /></div>
                             </div>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div><label className="block text-gray-700 text-sm font-semibold mb-2">سن<span className="text-red-500 mr-1">*</span></label><input type="number" name="age" value={formData.age} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required /></div>
                                <JalaliDatePicker label="تاریخ استخدام*" value={formData.employmentDate} onChange={(date) => handleDateChange('employmentDate', date)} required/>
                             </div>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end pt-6 mt-6 border-t">
                  <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">لغو</button>
                  <button type="submit" className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700">ذخیره کاربر</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PersonnelManagement;
