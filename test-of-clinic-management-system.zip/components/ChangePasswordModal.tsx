
import React, { useState, useEffect } from 'react';
import type { Personnel } from '../types';
import { KeyIcon, SaveIcon } from './icons/Icons';

interface ChangePasswordModalProps {
    isOpen: boolean;
    onClose: () => void;
    currentUser: Personnel;
    updatePersonnel: (personnel: Personnel) => Promise<Personnel>;
}

const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ isOpen, onClose, currentUser, updatePersonnel }) => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (isOpen) {
            // Reset state when modal opens
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
            setError('');
            setIsSaving(false);
        }
    }, [isOpen]);

    const handleSave = async () => {
        setError('');
        
        if (!currentPassword || !newPassword || !confirmPassword) {
            setError('تمام فیلدها اجباری هستند.');
            return;
        }

        if (newPassword !== confirmPassword) {
            setError('رمز عبور جدید با تکرار آن مطابقت ندارد.');
            return;
        }
        
        if (currentUser.password !== currentPassword) {
            setError('رمز عبور فعلی نادرست است.');
            return;
        }

        if (newPassword.length < 5) {
            setError('رمز عبور جدید باید حداقل ۵ کاراکتر باشد.');
            return;
        }

        setIsSaving(true);
        try {
            const updatedUser = { ...currentUser, password: newPassword };
            await updatePersonnel(updatedUser);
            // Also update the user object in localStorage to reflect the change immediately
            localStorage.setItem('currentUser', JSON.stringify(updatedUser));
            alert('رمز عبور با موفقیت تغییر کرد.');
            onClose();
        } catch (e) {
            console.error("Failed to update password:", e);
            setError('خطا در ذخیره رمز عبور. لطفا دوباره تلاش کنید.');
        } finally {
            setIsSaving(false);
        }
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-6 text-gray-800">تغییر رمز عبور</h3>
                <div className="space-y-4">
                    <div>
                        <label className="block text-gray-700 font-semibold mb-2">رمز عبور فعلی</label>
                        <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3"><KeyIcon className="h-5 w-5 text-gray-400" /></span>
                            <input
                                type="password"
                                value={currentPassword}
                                onChange={e => setCurrentPassword(e.target.value)}
                                className="w-full p-2.5 pl-10 border rounded-lg"
                                autoFocus
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-gray-700 font-semibold mb-2">رمز عبور جدید</label>
                         <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3"><KeyIcon className="h-5 w-5 text-gray-400" /></span>
                            <input
                                type="password"
                                value={newPassword}
                                onChange={e => setNewPassword(e.target.value)}
                                className="w-full p-2.5 pl-10 border rounded-lg"
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-gray-700 font-semibold mb-2">تکرار رمز عبور جدید</label>
                         <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3"><KeyIcon className="h-5 w-5 text-gray-400" /></span>
                            <input
                                type="password"
                                value={confirmPassword}
                                onChange={e => setConfirmPassword(e.target.value)}
                                className="w-full p-2.5 pl-10 border rounded-lg"
                            />
                        </div>
                    </div>
                </div>

                {error && <p className="text-red-600 text-sm mt-4 text-center">{error}</p>}
                
                <div className="flex justify-end mt-8 gap-3">
                    <button onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition">
                        انصراف
                    </button>
                    <button 
                        onClick={handleSave} 
                        disabled={isSaving}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2 disabled:bg-gray-400"
                    >
                        <SaveIcon className="w-5 h-5"/>
                        {isSaving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ChangePasswordModal;
