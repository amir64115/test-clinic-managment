
import React, { useMemo, useState } from 'react';
import type { AppPermissions, Personnel, AppView, PermissionSet, RolePermissions } from '../types';
import { 
    ChevronDownIcon, PatientsIcon, DoctorsIcon, PersonnelIcon, 
    AppointmentsIcon, FinancialIcon, ReportsIcon, BackupIcon, PlusIcon, EditIcon, TrashIcon 
} from './icons/Icons';


interface SettingsProps {
  permissions: AppPermissions;
  setPermissions: React.Dispatch<React.SetStateAction<AppPermissions>>;
  personnel: Personnel[];
  setPersonnel: React.Dispatch<React.SetStateAction<Personnel[]>>;
}

const Settings: React.FC<SettingsProps> = ({ permissions, setPermissions, personnel, setPersonnel }) => {
  const roles = useMemo(() => {
    // Get all roles defined in the permissions object and filter out the non-editable 'مدیر' role.
    return Object.keys(permissions).filter(role => role !== 'مدیر').sort((a,b) => a.localeCompare(b, 'fa'));
  }, [permissions]);

  const [openAccordions, setOpenAccordions] = useState<Record<string, AppView | null>>({});
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<string | null>(null); // null for adding, string for editing
  const [roleName, setRoleName] = useState('');
  const [copyFromRole, setCopyFromRole] = useState('');

  const toggleAccordion = (role: string, view: AppView) => {
    setOpenAccordions(prev => ({
        ...prev,
        [role]: prev[role] === view ? null : view
    }));
  };

  const handlePermissionChange = (role: string, view: AppView, action: keyof PermissionSet, isEnabled: boolean) => {
    setPermissions(prev => {
      const newPerms = JSON.parse(JSON.stringify(prev));
      if (!newPerms[role]) newPerms[role] = {};
      if (!newPerms[role][view]) newPerms[role][view] = {};
      
      newPerms[role][view][action] = isEnabled;

      // Logic: if you disable 'view', disable all other actions for that module
      if (action === 'view' && !isEnabled) {
        newPerms[role][view].add = false;
        newPerms[role][view].edit = false;
        newPerms[role][view].delete = false;
      }
      
      // Logic: if you enable any action, 'view' must also be enabled
      if (action !== 'view' && isEnabled) {
          newPerms[role][view].view = true;
      }

      return newPerms;
    });
  };

  const handleOpenRoleModal = (role: string | null) => {
    setEditingRole(role);
    setRoleName(role || '');
    setCopyFromRole('');
    setIsRoleModalOpen(true);
  };

  const handleCloseRoleModal = () => {
    setIsRoleModalOpen(false);
    setEditingRole(null);
    setRoleName('');
    setCopyFromRole('');
  };

  const handleSaveRole = () => {
    const newName = roleName.trim();
    if (!newName) {
      alert('نام نقش نمی‌تواند خالی باشد.');
      return;
    }
    if (newName === 'مدیر') {
      alert('نقش "مدیر" قابل ویرایش یا ایجاد نیست.');
      return;
    }

    const isDuplicate = Object.keys(permissions)
      .some(role => role.toLowerCase() === newName.toLowerCase() && role.toLowerCase() !== editingRole?.toLowerCase());

    if (isDuplicate) {
      alert('نقشی با این نام از قبل وجود دارد.');
      return;
    }

    if (editingRole) { // Editing existing role
      setPermissions(prev => {
        const newPerms = { ...prev };
        const oldPerms = newPerms[editingRole];
        delete newPerms[editingRole];
        newPerms[newName] = oldPerms;
        return newPerms;
      });
      const updatedPersonnel = personnel.map(p => {
        if (p.role === editingRole) {
          return { ...p, role: newName };
        }
        return p;
      });
      setPersonnel(updatedPersonnel);
    } else { // Adding new role
      let initialPermissions: RolePermissions = {};
      if (copyFromRole && permissions[copyFromRole]) {
        initialPermissions = JSON.parse(JSON.stringify(permissions[copyFromRole]));
      }
      setPermissions(prev => ({ ...prev, [newName]: initialPermissions }));
    }
    handleCloseRoleModal();
  };

  const handleDeleteRole = (roleToDelete: string) => {
    if (roleToDelete === 'مدیر') {
      alert('نقش "مدیر" قابل حذف نیست.');
      return;
    }
    const usersWithRole = personnel.filter(p => p.role === roleToDelete);
    if (usersWithRole.length > 0) {
      alert(`امکان حذف این نقش وجود ندارد زیرا ${usersWithRole.length} کاربر (${usersWithRole.map(u => u.name).join(', ')}) از آن استفاده می‌کنند. ابتدا نقش این کاربران را تغییر دهید.`);
      return;
    }
    if (window.confirm(`آیا از حذف نقش "${roleToDelete}" اطمینان دارید؟ این عمل غیرقابل بازگشت است.`)) {
      setPermissions(prev => {
        const newPerms = { ...prev };
        delete newPerms[roleToDelete];
        return newPerms;
      });
    }
  };

  const views: { key: Exclude<AppView, 'settings' | 'dashboard'>, label: string, icon: React.FC<any> }[] = [
    { key: 'patients', label: 'بیماران', icon: PatientsIcon },
    { key: 'doctors', label: 'پزشکان', icon: DoctorsIcon },
    { key: 'personnel', label: 'پرسنل', icon: PersonnelIcon },
    { key: 'appointments', label: 'نوبت‌دهی', icon: AppointmentsIcon },
    { key: 'financial', label: 'مالی', icon: FinancialIcon },
    { key: 'reports', label: 'گزارشات', icon: ReportsIcon },
    { key: 'backup', label: 'پشتیبان‌گیری', icon: BackupIcon },
  ];

  const actions: { key: keyof PermissionSet, label: string }[] = [
      { key: 'view', label: 'مشاهده' },
      { key: 'add', label: 'افزودن' },
      { key: 'edit', label: 'ویرایش' },
      { key: 'delete', label: 'حذف' }
  ];

  return (
    <div>
      <h2 className="text-3xl font-bold mb-8">تنظیمات</h2>
      
      <div className="bg-white p-6 rounded-xl shadow-md border mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-gray-800">مدیریت نقش‌ها</h3>
          <button
            onClick={() => handleOpenRoleModal(null)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2"
          >
            <PlusIcon className="w-5 h-5" />
            افزودن نقش جدید
          </button>
        </div>
        <div className="space-y-3">
          {roles.map(role => (
            <div key={role} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border">
              <span className="font-semibold text-gray-700">{role}</span>
              <div className="flex items-center gap-2">
                <button onClick={() => handleOpenRoleModal(role)} className="p-2 text-gray-500 hover:text-green-600" title="ویرایش نام نقش">
                  <EditIcon className="w-5 h-5" />
                </button>
                <button onClick={() => handleDeleteRole(role)} className="p-2 text-gray-500 hover:text-red-600" title="حذف نقش">
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <h3 className="text-2xl font-bold mb-6">سطوح دسترسی نقش‌ها</h3>
      <p className="text-gray-600 mb-8 max-w-2xl">
        در این بخش می‌توانید مشخص کنید که هر گروه از پرسنل چه اجازه‌هایی (مشاهده، افزودن، ویرایش، حذف) برای هر بخش از نرم‌افزار داشته باشند. دسترسی به داشبورد برای همه نقش‌ها اجباری است.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {roles.length > 0 ? roles.map(role => {
            const isOpen = (viewKey: AppView) => openAccordions[role] === viewKey;
            return (
              <div key={role} className="bg-white p-4 sm:p-6 rounded-xl shadow-md border space-y-2">
                <h3 className="text-xl font-bold text-gray-800 mb-4">نقش: {role}</h3>
                {views.map(view => (
                    <div key={view.key} className="border rounded-lg overflow-hidden transition-all duration-300">
                        <button
                            onClick={() => toggleAccordion(role, view.key)}
                            className="w-full flex justify-between items-center p-4 text-right bg-gray-50 hover:bg-gray-100 transition-colors"
                        >
                            <span className="flex items-center gap-3 font-semibold text-gray-700">
                                <view.icon className="w-6 h-6 text-blue-600" />
                                {view.label}
                            </span>
                            <ChevronDownIcon className={`w-6 h-6 text-gray-500 transition-transform transform ${isOpen(view.key) ? 'rotate-180' : ''}`} />
                        </button>
                        {isOpen(view.key) && (
                            <div className="p-4 bg-white grid grid-cols-2 sm:grid-cols-4 gap-4">
                                {actions.map(action => {
                                    const isDisabled = (view.key === 'reports' && action.key !== 'view') ||
                                                        (view.key === 'backup' && (action.key === 'edit' || action.key === 'delete'));
                                    const isChecked = !!permissions[role]?.[view.key]?.[action.key];

                                    return (
                                        <label key={action.key} className={`flex items-center gap-2 p-2 rounded-md transition-colors ${isDisabled ? 'text-gray-400 cursor-not-allowed' : 'text-gray-700 cursor-pointer hover:bg-gray-100'} ${isChecked && !isDisabled ? 'bg-blue-50' : ''}`}>
                                            <input
                                                type="checkbox"
                                                className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500 border-gray-300 disabled:text-gray-300 disabled:border-gray-200 cursor-pointer disabled:cursor-not-allowed"
                                                checked={isChecked}
                                                onChange={e => handlePermissionChange(role, view.key, action.key, e.target.checked)}
                                                disabled={isDisabled}
                                            />
                                            <span className="font-medium">{action.label}</span>
                                        </label>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                ))}
              </div>
            );
        }) : (
             <div className="lg:col-span-2 text-center p-8 bg-white rounded-lg shadow-md">
                <p className="text-gray-600">نقش دیگری به جز "مدیر" برای تنظیم دسترسی یافت نشد. برای استفاده از این بخش، از منوی پرسنل، نقش‌های جدید (مانند منشی، حسابدار) تعریف کنید.</p>
            </div>
        )}
      </div>

       {isRoleModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-6">{editingRole ? 'ویرایش نقش' : 'افزودن نقش جدید'}</h3>
                <div className="space-y-4">
                    <div>
                        <label className="block text-gray-700 font-semibold mb-2">نام نقش</label>
                        <input
                            type="text"
                            value={roleName}
                            onChange={e => setRoleName(e.target.value)}
                            className="w-full p-2 border rounded-lg"
                            autoFocus
                        />
                    </div>
                    {!editingRole && (
                        <div>
                            <label className="block text-gray-700 font-semibold mb-2">کپی دسترسی‌ها از (اختیاری)</label>
                            <select
                                value={copyFromRole}
                                onChange={e => setCopyFromRole(e.target.value)}
                                className="w-full p-2 border rounded-lg bg-gray-50"
                            >
                                <option value="">شروع با دسترسی خالی</option>
                                {roles.map(r => <option key={r} value={r}>{r}</option>)}
                            </select>
                        </div>
                    )}
                </div>
                <div className="flex justify-end mt-8 gap-3">
                    <button onClick={handleCloseRoleModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">انصراف</button>
                    <button onClick={handleSaveRole} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">ذخیره</button>
                </div>
            </div>
        </div>
    )}
    </div>
  );
};

export default Settings;
