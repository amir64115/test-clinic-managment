
import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Patient, Doctor, Appointment, InsuranceProvider, PermissionSet, Personnel, TreatmentPlan, PatientFileAttachment, ClinicalRecord, ClinicalRecordMessage, Transaction } from '../types';
import { TrashIcon, DownloadIcon, EditIcon, UserCircleIcon, IdentificationIcon, DocumentTextIcon, PlusIcon, CalendarIcon, StethoscopeIcon, ChevronDownIcon, DocumentReportIcon, PhoneIcon, UploadIcon, SaveIcon, TrendingUpIcon, TrendingDownIcon, UserIcon, SendIcon, ClockIcon, FinancialIcon } from './icons/Icons';
import { exportToExcel } from '../utils/exportToExcel';
import { formatToJalali } from '../utils/dateUtils';
import { areNamesEquivalent } from '../utils/textUtils';
import VoiceEnabledTextarea from './VoiceEnabledTextarea';
import { REFERRAL_SOURCES_DATA } from '../constants';

interface PatientManagementProps {
  patients: Patient[];
  setPatients: React.Dispatch<React.SetStateAction<Patient[]>>;
  doctors: Doctor[];
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  insuranceProviders: InsuranceProvider[];
  permissions: PermissionSet;
  currentUser: Personnel;
  personnel: Personnel[];
  treatmentPlans: TreatmentPlan[];
  setTreatmentPlans: React.Dispatch<React.SetStateAction<TreatmentPlan[]>>;
  clinicalRecords: ClinicalRecord[];
  addPatient: (patient: Omit<Patient, 'id'>) => Promise<Patient>;
  updatePatient: (patient: Patient) => Promise<Patient>;
  deletePatient: (id: string) => Promise<void>;
  addClinicalRecord: (record: Omit<ClinicalRecord, 'id'>) => Promise<ClinicalRecord>;
  updateClinicalRecord: (record: ClinicalRecord) => Promise<ClinicalRecord>;
  updateTreatmentPlan: (plan: TreatmentPlan) => Promise<TreatmentPlan>;
  addTreatmentPlan: (plan: Omit<TreatmentPlan, 'id'>) => Promise<TreatmentPlan>;
  transactions: Transaction[];
}

const emptyPatient: Omit<Patient, 'id'> = {
  name: '',
  nationalId: '',
  phone1: '',
  phone2: '',
  age: 30,
  gender: 'مرد',
  diagnosis: '',
  insuranceProviderId: undefined,
  nextSessionPlan: '',
  referredById: undefined,
  photoUrl: '',
  referralSource: '',
  attachments: [],
};

const appointmentStatusPersian: Record<Appointment['status'], string> = {
    Scheduled: 'زمان‌بندی شده',
    Completed: 'تکمیل شده',
    Cancelled: 'لغو شده',
    Waiting: 'در انتظار',
};

type PatientViewTab = 'info' | 'appointments' | 'records' | 'attachments' | 'plans' | 'financial';

const PatientManagement: React.FC<PatientManagementProps> = ({
  patients,
  setPatients,
  doctors,
  appointments,
  setAppointments,
  insuranceProviders,
  permissions,
  currentUser,
  personnel,
  treatmentPlans,
  setTreatmentPlans,
  clinicalRecords,
  addPatient,
  updatePatient,
  deletePatient,
  addClinicalRecord,
  updateClinicalRecord,
  updateTreatmentPlan,
  addTreatmentPlan,
  transactions
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<Patient, 'id'>>(emptyPatient);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [viewingPatient, setViewingPatient] = useState<Patient | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [activeTab, setActiveTab] = useState<PatientViewTab>('info');
  
  // Sorting State
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' }>({ key: 'name', direction: 'asc' });

  // Clinical Record Editing State
  const [editingRecord, setEditingRecord] = useState<Omit<ClinicalRecord, 'id'> | ClinicalRecord | null>(null);
  const [isRecordEditorOpen, setIsRecordEditorOpen] = useState(false);
  
  // Chat State
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Timeline View State
  const [showFullTimeline, setShowFullTimeline] = useState(false);

  const filteredPatients = useMemo(() => {
    return patients.filter(p =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.nationalId.includes(searchTerm) ||
      p.phone1.includes(searchTerm)
    );
  }, [patients, searchTerm]);

  const sortedPatients = useMemo(() => {
    let sortablePatients = [...filteredPatients];
    if (sortConfig.key) {
      sortablePatients.sort((a, b) => {
        let aValue: any = a[sortConfig.key as keyof Patient];
        let bValue: any = b[sortConfig.key as keyof Patient];

        // Handle potential undefined values for diagnosis
        if (sortConfig.key === 'diagnosis') {
            aValue = aValue || '';
            bValue = bValue || '';
        }

        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortablePatients;
  }, [filteredPatients, sortConfig]);

  const requestSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const renderSortIcon = (columnKey: string) => {
      if (sortConfig.key !== columnKey) return <div className="w-4 h-4 inline-block ml-1 opacity-20"><TrendingDownIcon className="w-4 h-4"/></div>;
      return sortConfig.direction === 'asc' 
        ? <div className="w-4 h-4 inline-block ml-1 text-blue-600"><TrendingUpIcon className="w-4 h-4"/></div> 
        : <div className="w-4 h-4 inline-block ml-1 text-blue-600"><TrendingDownIcon className="w-4 h-4"/></div>;
  };

  const isMedicalStaff = ['پزشک', 'درمانگر'].includes(currentUser.role);
  const isTherapist = currentUser.role === 'درمانگر'; // Specific check for restricting contact info
  const isManager = ['مدیر', 'مدیریت'].includes(currentUser.role);
  
  const currentDoctorId = useMemo(() => {
      if (!isMedicalStaff) return null;
      const doc = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
      return doc ? doc.id : null;
  }, [isMedicalStaff, doctors, currentUser.name]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let finalValue: any = value;
    if (['insuranceProviderId', 'referredById'].includes(name)) {
        finalValue = value ? value : undefined;
    } else if (name === 'age') {
        finalValue = value ? parseInt(value, 10) : 0;
    }
    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const handleFile = async (file: File | null, type: 'photo' | 'attachment') => {
    if (!file) return;

    const MAX_SIZE_KB = type === 'photo' ? 500 : 5120; // 500KB for photo, 5MB for docs
    if (file.size > MAX_SIZE_KB * 1024) {
      alert(`حجم فایل نباید بیشتر از ${MAX_SIZE_KB / 1024} مگابایت باشد.`);
      return;
    }

    if (type === 'photo' && !['image/png', 'image/jpeg'].includes(file.type)) {
      alert('لطفا برای عکس پروفایل یک فایل با فرمت JPG یا PNG انتخاب کنید.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const dataUrl = reader.result as string;
      if (type === 'photo') {
        setFormData(prev => ({ ...prev, photoUrl: dataUrl }));
      } else {
        const newAttachment: PatientFileAttachment = {
          id: String(Date.now()),
          fileName: file.name,
          dataUrl: dataUrl,
        };
        
        // If we are in view mode (adding file directly to existing patient)
        if(viewingPatient) {
            const updatedPatient = {
                ...viewingPatient,
                attachments: [...(viewingPatient.attachments || []), newAttachment]
            };
            try {
                await updatePatient(updatedPatient);
                setViewingPatient(updatedPatient); // Update local view state
            } catch (error) {
                console.error("Failed to upload attachment", error);
            }
        } else {
            // Creating new patient or editing in modal
            setFormData(prev => ({ ...prev, attachments: [...(prev.attachments || []), newAttachment] }));
        }
      }
    };
    reader.readAsDataURL(file);
  };
  
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFile(e.target.files?.[0] || null, 'photo');
    if (e.target) e.target.value = '';
  };
  
  const handleAttachmentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFile(e.target.files?.[0] || null, 'attachment');
    if (e.target) e.target.value = '';
  };

  const handleRemoveAttachment = async (attachmentId: string) => {
      if (viewingPatient) {
          if(window.confirm('آیا از حذف این فایل ضمیمه اطمینان دارید؟')) {
              const updatedPatient = {
                  ...viewingPatient,
                  attachments: viewingPatient.attachments?.filter(a => a.id !== attachmentId)
              };
              try {
                  await updatePatient(updatedPatient);
                  setViewingPatient(updatedPatient);
              } catch (error) {
                  console.error("Failed to delete attachment", error);
              }
          }
      } else {
          setFormData(prev => ({...prev, attachments: prev.attachments?.filter(a => a.id !== attachmentId)}));
      }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); handleFile(e.dataTransfer.files?.[0] || null, 'photo'); };
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); };
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); };
  const handleRemovePhoto = () => setFormData(prev => ({ ...prev, photoUrl: '' }));

  const closeModal = () => { setIsModalOpen(false); setEditingPatient(null); setFormData(emptyPatient); };
  const closeViewModal = () => { setIsViewModalOpen(false); setViewingPatient(null); setActiveTab('info'); setIsRecordEditorOpen(false); setEditingRecord(null); setShowFullTimeline(false); };
  
  const openAddModal = () => { setEditingPatient(null); setFormData(emptyPatient); setIsModalOpen(true); };
  const openEditModal = (patient: Patient) => { setEditingPatient(patient); setFormData(patient); setIsModalOpen(true); };
  const openViewModal = (patient: Patient) => { setActiveTab('info'); setViewingPatient(patient); setIsViewModalOpen(true); };
  
  const handleEditFromView = () => { if (viewingPatient) { openEditModal(viewingPatient); closeViewModal(); } };
  
  const handleSavePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.phone1) {
      if (!editingPatient && formData.nationalId.trim()) {
          const isDuplicate = patients.some(p => p.nationalId === formData.nationalId.trim());
          if (isDuplicate) {
              alert('بیماری با این کد ملی از قبل در سیستم ثبت شده است.');
              return;
          }
      }
      try {
        if (editingPatient) {
          await updatePatient({ ...formData, id: editingPatient.id } as Patient);
        } else {
          await addPatient(formData);
        }
        closeModal();
      } catch (error) {
        console.error("Save patient failed:", error);
      }
    } else {
      alert('لطفا فیلدهای نام و شماره تماس ۱ را تکمیل کنید.');
    }
  };

  const handleDeletePatient = async (id: string) => {
    const hasAppointments = appointments.some(app => app.patientIds.includes(id));
    if (hasAppointments) {
      alert('امکان حذف این بیمار وجود ندارد زیرا نوبت‌های ثبت شده‌ای برای او وجود دارد.');
      return;
    }
    if (window.confirm('آیا از حذف این بیمار اطمینان دارید؟')) {
        try {
            await deletePatient(id);
        } catch (error) {
            console.error("Delete patient failed", error);
        }
    }
  };

  const handleExport = () => {
    const dataToExport = filteredPatients.map(p => ({
      'نام کامل': p.name,
      'تشخیص پزشک': p.diagnosis || '-',
      'تلفن ۱': isTherapist ? '---' : p.phone1,
      'سن': p.age,
      'بیمه': insuranceProviders.find(i => i.id === p.insuranceProviderId)?.name || 'آزاد',
    }));
    exportToExcel(dataToExport, 'patients-list.xlsx');
  };
  
  const patientAppointments = useMemo(() => {
    if (!viewingPatient) return [];
    return appointments
      .filter(app => app.patientIds.includes(viewingPatient.id) && app.status !== 'Scheduled')
      .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [viewingPatient, appointments]);

  const patientTreatmentPlans = useMemo(() => {
    if (!viewingPatient) return [];
    return treatmentPlans.filter(plan => plan.patientId === viewingPatient.id).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [viewingPatient, treatmentPlans]);
  
  // Financial Ledger Calculation
  const financialLedger = useMemo(() => {
      if (!viewingPatient || !isManager) return [];
      
      const ledgerItems: Array<{
          id: string;
          date: string;
          type: 'debt' | 'credit';
          description: string;
          amount: number;
          balance?: number;
          details?: any;
      }> = [];

      // 1. Calculate Debts from Completed Appointments
      const completedAppointments = appointments.filter(app => 
          app.patientIds.includes(viewingPatient.id) && app.status === 'Completed'
      );

      completedAppointments.forEach(app => {
          const doctor = doctors.find(d => d.id === app.doctorId);
          let totalFee = app.sessionFee || 0;
          
          // Fallback calculation if sessionFee is missing but duration exists
          if (totalFee === 0 && doctor && app.sessionDuration) {
              totalFee = Math.round((doctor.ratePerHour / 60) * parseInt(app.sessionDuration));
          }

          let insuranceShare = 0;
          let insuranceName = 'آزاد';
          
          if (app.applyInsurance !== false) {
              const provider = insuranceProviders.find(i => i.id === viewingPatient.insuranceProviderId);
              if (provider) {
                  insuranceName = provider.name;
                  if (provider.commissionType === 'percentage') {
                      insuranceShare = Math.round(totalFee * (provider.commissionValue / 100));
                  } else {
                      insuranceShare = Math.min(totalFee, provider.commissionValue);
                  }
              }
          }

          const patientShare = totalFee - insuranceShare;

          if (patientShare > 0) {
              ledgerItems.push({
                  id: `app-${app.id}`,
                  date: app.date,
                  type: 'debt',
                  description: `ویزیت - ${doctor?.name || 'پزشک'} (${insuranceName})`,
                  amount: patientShare,
                  details: {
                      totalFee,
                      insuranceShare,
                      doctorName: doctor?.name
                  }
              });
          }
      });

      // 2. Calculate Credits from Transactions (Payments)
      const patientTransactions = transactions.filter(t => 
          t.patientId === viewingPatient.id && t.type === 'درآمد'
      );

      patientTransactions.forEach(t => {
          ledgerItems.push({
              id: `trans-${t.id}`,
              date: t.date,
              type: 'credit',
              description: `پرداخت: ${t.description} (${t.paymentMethod || 'نامشخص'})`,
              amount: t.amount,
          });
      });

      // 3. Sort by Date
      ledgerItems.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      // 4. Calculate Running Balance
      let runningBalance = 0;
      return ledgerItems.map(item => {
          if (item.type === 'debt') {
              runningBalance += item.amount;
          } else {
              runningBalance -= item.amount;
          }
          return { ...item, balance: runningBalance };
      });

  }, [viewingPatient, appointments, transactions, doctors, insuranceProviders, isManager]);

  const financialSummary = useMemo(() => {
      if (financialLedger.length === 0) return { totalDebt: 0, totalPaid: 0, balance: 0 };
      const lastItem = financialLedger[financialLedger.length - 1];
      const totalDebt = financialLedger.filter(i => i.type === 'debt').reduce((acc, curr) => acc + curr.amount, 0);
      const totalPaid = financialLedger.filter(i => i.type === 'credit').reduce((acc, curr) => acc + curr.amount, 0);
      return { totalDebt, totalPaid, balance: lastItem.balance || 0 };
  }, [financialLedger]);


  // Record Editing Functions
  const openRecordEditor = (appointment: Appointment) => {
      const existingRecord = clinicalRecords.find(r => r.appointmentId === appointment.id);
      if (existingRecord) {
          setEditingRecord({
              ...existingRecord,
              messages: existingRecord.messages || [] // ensure array exists
          });
      } else {
          setEditingRecord({
              appointmentId: appointment.id,
              patientId: viewingPatient!.id,
              doctorId: appointment.doctorId,
              createdAt: appointment.date,
              updatedAt: new Date().toISOString(),
              note: '',
              messages: [],
              subjective: '', objective: '', assessment: '', plan: ''
          });
      }
      setIsRecordEditorOpen(true);
      setChatInput('');
  };

  const handleRecordFieldChange = (field: keyof ClinicalRecord, value: string) => {
      setEditingRecord(prev => prev ? ({...prev, [field]: value}) : null);
  };

  const handleSendMessage = () => {
      if (!chatInput.trim() || !editingRecord) return;
      
      const newMessage: ClinicalRecordMessage = {
          id: String(Date.now()),
          senderId: currentUser.id,
          senderName: currentUser.name,
          senderRole: currentUser.role,
          text: chatInput.trim(),
          createdAt: new Date().toISOString()
      };
      
      setEditingRecord(prev => {
          if (!prev) return null;
          return {
              ...prev,
              messages: [...(prev.messages || []), newMessage]
          };
      });
      setChatInput('');
  };

  // Auto scroll to bottom of chat
  useEffect(() => {
      if (isRecordEditorOpen && chatEndRef.current) {
          chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
      }
  }, [editingRecord?.messages, isRecordEditorOpen]);

  const handleSaveRecord = async () => {
      if (!editingRecord) return;
      try {
          if ('id' in editingRecord) {
              await updateClinicalRecord(editingRecord as ClinicalRecord);
          } else {
              await addClinicalRecord(editingRecord);
          }
          setIsRecordEditorOpen(false);
          setEditingRecord(null);
      } catch (error) {
          console.error("Failed to save clinical record", error);
          alert("خطا در ذخیره پرونده.");
      }
  };
  
  // Timeline Data Generation
  const timelineEvents = useMemo(() => {
      if (!viewingPatient) return [];
      
      const events: Array<{
          date: string;
          type: 'record' | 'appointment';
          title: string;
          description?: string;
          doctorName?: string;
          messages?: ClinicalRecordMessage[];
      }> = [];

      // Add Clinical Records to Timeline
      clinicalRecords.filter(r => r.patientId === viewingPatient.id).forEach(record => {
          const doctor = doctors.find(d => d.id === record.doctorId);
          events.push({
              date: record.createdAt,
              type: 'record',
              title: `یادداشت بالینی - ${doctor?.name || 'نامشخص'}`,
              description: record.note,
              doctorName: doctor?.name,
              messages: record.messages
          });
      });

      return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [viewingPatient, clinicalRecords, doctors]);
  
    const TABS: { id: PatientViewTab, label: string, icon: React.FC<{className?: string}>, show: boolean }[] = [
        { id: 'info', label: 'اطلاعات', icon: IdentificationIcon, show: true },
        { id: 'appointments', label: 'نوبت‌ها', icon: CalendarIcon, show: true },
        { id: 'records', label: 'پرونده بالینی', icon: DocumentReportIcon, show: true },
        { id: 'attachments', label: 'فایل‌ها', icon: DocumentTextIcon, show: true },
        { id: 'plans', label: 'طرح درمان', icon: StethoscopeIcon, show: true },
        { id: 'financial', label: 'پرونده مالی', icon: FinancialIcon, show: isManager },
    ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h2 className="text-2xl sm:text-3xl font-bold">مدیریت بیماران</h2>
        <div className="flex items-center gap-2">
            <button onClick={handleExport} className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition flex items-center gap-2 text-sm sm:text-base">
              <DownloadIcon className="w-5 h-5" />
              <span className="hidden sm:inline">خروجی اکسل</span>
            </button>
            {permissions.add && (
              <button onClick={openAddModal} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
                <PlusIcon className="w-5 h-5" />
                <span>افزودن بیمار</span>
              </button>
            )}
        </div>
      </div>
      
      <div className="mb-4">
        <input
          type="text"
          placeholder="جستجو بر اساس نام، کد ملی یا شماره تلفن..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full p-3 border rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 outline-none"
        />
      </div>

      <div className="bg-white p-0 sm:p-6 rounded-lg shadow-none sm:shadow-md bg-transparent sm:bg-white">
        {/* Desktop View */}
        <div className="hidden md:block overflow-x-auto bg-white rounded-lg shadow-sm border">
          <table className="w-full text-right">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-3 text-sm font-semibold tracking-wide"></th>
                <th className="p-3 text-sm font-semibold tracking-wide cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('name')}>نام {renderSortIcon('name')}</th>
                <th className="p-3 text-sm font-semibold tracking-wide cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('diagnosis')}>تشخیص پزشک {renderSortIcon('diagnosis')}</th>
                <th className="p-3 text-sm font-semibold tracking-wide cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('phone1')}>شماره تماس {renderSortIcon('phone1')}</th>
                <th className="p-3 text-sm font-semibold tracking-wide cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('age')}>سن {renderSortIcon('age')}</th>
                <th className="p-3 text-sm font-semibold tracking-wide">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {sortedPatients.map(patient => (
                <tr key={patient.id} className="border-b hover:bg-gray-50 cursor-pointer transition-colors" onClick={() => openViewModal(patient)}>
                  <td className="p-2">
                    {patient.photoUrl ? <img src={patient.photoUrl} alt={patient.name} className="w-10 h-10 rounded-full object-cover border"/> : <UserCircleIcon className="w-10 h-10 text-gray-300"/>}
                  </td>
                  <td className="p-3 font-semibold">{patient.name}</td>
                  <td className="p-3 text-gray-600">{patient.diagnosis || '-'}</td>
                  <td className="p-3">{isTherapist ? '---' : patient.phone1}</td>
                  <td className="p-3">{patient.age}</td>
                  <td className="p-3 flex items-center space-x-2 space-x-reverse">
                     {permissions.edit && (
                       <button onClick={(e) => {e.stopPropagation(); openEditModal(patient)}} className="text-gray-500 hover:text-blue-600 p-1.5 rounded-full hover:bg-blue-50 transition" title="ویرایش">
                          <EditIcon className="w-5 h-5" />
                       </button>
                     )}
                     {permissions.delete && (
                      <button onClick={(e) => {e.stopPropagation(); handleDeletePatient(patient.id)}} className="text-gray-500 hover:text-red-600 p-1.5 rounded-full hover:bg-red-50 transition" title="حذف">
                          <TrashIcon className="w-5 h-5" />
                      </button>
                     )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile View Cards */}
        <div className="md:hidden space-y-4">
            {sortedPatients.map(patient => (
                <div key={patient.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 active:scale-[0.99] transition-transform duration-100" onClick={() => openViewModal(patient)}>
                    <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                           {patient.photoUrl ? <img src={patient.photoUrl} alt={patient.name} className="w-14 h-14 rounded-full object-cover border-2 border-gray-100"/> : <UserCircleIcon className="w-14 h-14 text-gray-300"/>}
                           <div>
                              <p className="font-bold text-gray-900 text-lg">{patient.name}</p>
                              <p className="text-sm text-gray-500 flex items-center gap-1 mt-0.5">
                                {patient.diagnosis && <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-xs">{patient.diagnosis}</span>}
                              </p>
                           </div>
                        </div>
                        <span className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded-full font-medium">{patient.age} ساله</span>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-gray-50 flex items-center justify-between">
                        <div className="flex items-center text-gray-600 text-sm">
                            <PhoneIcon className="w-4 h-4 ml-1 text-gray-400" />
                            {isTherapist ? '---' : patient.phone1}
                        </div>
                        <div className="flex items-center gap-2">
                            {permissions.edit && (
                                <button onClick={(e) => {e.stopPropagation(); openEditModal(patient)}} className="p-2 bg-gray-100 rounded-full text-blue-600 hover:bg-blue-100 transition">
                                    <EditIcon className="w-5 h-5" />
                                </button>
                            )}
                            {permissions.delete && (
                                <button onClick={(e) => {e.stopPropagation(); handleDeletePatient(patient.id)}} className="p-2 bg-red-50 rounded-full text-red-600 hover:bg-red-100 transition">
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            ))}
        </div>
        {sortedPatients.length === 0 && <p className="text-center py-12 text-gray-500 bg-white rounded-lg border border-dashed">بیماری با این مشخصات یافت نشد.</p>}
      </div>

      {/* View Modal */}
      {isViewModalOpen && viewingPatient && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-40 backdrop-blur-sm transition-opacity" onClick={closeViewModal}>
          <div className="flex items-end sm:items-center justify-center h-full p-0 sm:p-4">
            <div className="bg-gray-50 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-5xl max-h-[95vh] sm:max-h-[90vh] flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()}>
               
               {/* Modal Header */}
               <div className="bg-white px-6 py-4 border-b flex justify-between items-center sticky top-0 z-10">
                  <div className="flex items-center gap-3">
                      {viewingPatient.photoUrl ? <img src={viewingPatient.photoUrl} alt={viewingPatient.name} className="w-12 h-12 rounded-full object-cover border-2 border-gray-100"/> : <UserCircleIcon className="w-12 h-12 text-gray-300"/>}
                      <div>
                         <h3 className="text-lg font-bold text-gray-900">{viewingPatient.name}</h3>
                         <p className="text-xs text-gray-500">{isTherapist ? '---' : viewingPatient.phone1}</p>
                      </div>
                  </div>
                  <button onClick={closeViewModal} className="bg-gray-100 p-2 rounded-full hover:bg-gray-200 transition">
                      <ChevronDownIcon className="w-6 h-6 text-gray-600" />
                  </button>
               </div>

               {/* Scrollable Tabs */}
                <div className="bg-white shadow-sm z-0">
                    <nav className="flex space-x-4 space-x-reverse overflow-x-auto px-4 no-scrollbar" aria-label="Tabs">
                        {TABS.filter(t => t.show).map(tab => (
                            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                                className={`whitespace-nowrap py-3 px-3 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors ${activeTab === tab.id ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-800'}`}>
                                <tab.icon className="w-5 h-5"/> {tab.label}
                            </button>
                        ))}
                    </nav>
                </div>
               
               <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-50 safe-area-pb">
                 {activeTab === 'info' && (
                    <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
                            <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                <span className="block text-xs text-gray-500 mb-1">تشخیص پزشک</span>
                                <span className="font-semibold text-gray-800 text-lg">{viewingPatient.diagnosis || '-'}</span>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                <span className="block text-xs text-gray-500 mb-1">کد ملی</span>
                                <span className="font-semibold text-gray-800 text-lg">{viewingPatient.nationalId}</span>
                            </div>
                            {!isTherapist && (
                                <>
                                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                        <span className="block text-xs text-gray-500 mb-1">تلفن همراه</span>
                                        <span className="font-semibold text-gray-800 text-lg">{viewingPatient.phone1}</span>
                                    </div>
                                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                        <span className="block text-xs text-gray-500 mb-1">تلفن ثابت</span>
                                        <span className="font-semibold text-gray-800">{viewingPatient.phone2 || '-'}</span>
                                    </div>
                                </>
                            )}
                            <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                <span className="block text-xs text-gray-500 mb-1">سن و جنسیت</span>
                                <span className="font-semibold text-gray-800">{viewingPatient.age} ساله - {viewingPatient.gender}</span>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                <span className="block text-xs text-gray-500 mb-1">بیمه</span>
                                <span className="font-semibold text-gray-800">{insuranceProviders.find(i => i.id === viewingPatient.insuranceProviderId)?.name || 'آزاد'}</span>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                <span className="block text-xs text-gray-500 mb-1">پزشک معرف</span>
                                <span className="font-semibold text-gray-800">{doctors.find(d => d.id === viewingPatient.referredById)?.name || '-'}</span>
                            </div>
                            {!isTherapist && (
                                <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                                    <span className="block text-xs text-gray-500 mb-1">نحوه آشنایی</span>
                                    <span className="font-semibold text-gray-800">{viewingPatient.referralSource || '-'}</span>
                                </div>
                            )}
                        </div>
                        {viewingPatient.nextSessionPlan && (
                            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mt-4">
                                <span className="block text-xs font-bold text-blue-800 mb-2">یادداشت / طرح درمان</span>
                                <p className="text-gray-700 whitespace-pre-wrap">{viewingPatient.nextSessionPlan}</p>
                            </div>
                        )}
                        
                        {permissions.edit && (
                            <div className="pt-4 border-t flex justify-end">
                                <button type="button" onClick={handleEditFromView} className="bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 flex items-center gap-2 shadow-md active:scale-95 transition">
                                    <EditIcon className="w-5 h-5"/> ویرایش اطلاعات
                                </button>
                            </div>
                        )}
                    </div>
                 )}
                 
                 {activeTab === 'appointments' && (
                       <div className="space-y-3">
                            {patientAppointments.length > 0 ? patientAppointments.map(app => (
                                <div key={app.id} className={`p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center ${['Completed', 'Cancelled'].includes(app.status) ? 'bg-gray-100 opacity-80' : 'bg-white'}`}>
                                    <div>
                                        <p className={`font-bold text-sm ${['Completed', 'Cancelled'].includes(app.status) ? 'text-gray-600' : 'text-gray-800'}`}>نوبت با {doctors.find(d=>d.id===app.doctorId)?.name}</p>
                                        <p className="text-xs text-gray-500 mt-1">{formatToJalali(app.date)} ساعت {app.time}</p>
                                    </div>
                                    <span className={`text-xs px-2 py-1 rounded-full ${app.status === 'Completed' ? 'bg-green-100 text-green-700' : (app.status === 'Cancelled' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700')}`}>
                                        {appointmentStatusPersian[app.status]}
                                    </span>
                                </div>
                            )) : <div className="text-center py-10 text-gray-400">سابقه‌ای یافت نشد.</div>}
                        </div>
                 )}

                 {activeTab === 'records' && (
                     <div className="space-y-4">
                         {/* Toggle Timeline View */}
                         <div className="flex justify-end mb-4">
                             <button 
                                 onClick={() => setShowFullTimeline(!showFullTimeline)}
                                 className="text-blue-600 hover:bg-blue-50 px-3 py-2 rounded-lg transition text-sm font-medium flex items-center gap-2"
                             >
                                 {showFullTimeline ? 'بازگشت به لیست جلسات' : 'مشاهده تاریخچه کامل درمان (Timeline)'}
                                 <ClockIcon className="w-4 h-4" />
                             </button>
                         </div>

                         {/* Timeline View */}
                         {showFullTimeline ? (
                             <div className="relative border-r-2 border-gray-200 mr-3 space-y-8">
                                 {timelineEvents.length > 0 ? timelineEvents.map((event, idx) => (
                                     <div key={idx} className="relative mr-6 mb-6">
                                         <div className="absolute -right-[31px] top-1 w-4 h-4 bg-blue-500 rounded-full border-2 border-white ring-2 ring-blue-100"></div>
                                         <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                             <div className="flex justify-between items-center mb-2">
                                                 <h4 className="font-bold text-gray-800 text-sm">{event.title}</h4>
                                                 <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">{formatToJalali(event.date)}</span>
                                             </div>
                                             <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{event.description}</div>
                                             
                                             {/* Show messages in timeline if exist */}
                                             {event.messages && event.messages.length > 0 && (
                                                 <div className="mt-4 pt-3 border-t border-gray-100">
                                                     <p className="text-xs font-bold text-gray-500 mb-2">نظرات و گفتگوها:</p>
                                                     <div className="space-y-2">
                                                         {event.messages.map(msg => (
                                                             <div key={msg.id} className={`text-xs p-2 rounded-lg ${msg.senderId === currentUser.id ? 'bg-blue-50 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                                                                 <span className="font-bold block mb-1">{msg.senderName} ({msg.senderRole}):</span>
                                                                 {msg.text}
                                                             </div>
                                                         ))}
                                                     </div>
                                                 </div>
                                             )}
                                         </div>
                                     </div>
                                 )) : <p className="text-center py-10 text-gray-400">هیچ سابقه درمانی ثبت نشده است.</p>}
                             </div>
                         ) : (
                             <>
                                 {/* Record Editor Sub-Modal */}
                                 {isRecordEditorOpen && editingRecord && (
                                     <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onClick={() => setIsRecordEditorOpen(false)}>
                                         <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[95vh] flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()}>
                                             <div className="p-4 sm:p-6 border-b bg-gray-50 flex justify-between items-center">
                                                 <div>
                                                     <h3 className="text-lg font-bold text-gray-800">پرونده بالینی (طرح درمان)</h3>
                                                     <p className="text-xs text-gray-500 mt-1">
                                                         {doctors.find(d => d.id === editingRecord.doctorId)?.name} - {formatToJalali((editingRecord as any).createdAt)}
                                                     </p>
                                                 </div>
                                                 <button onClick={() => setIsRecordEditorOpen(false)} className="text-gray-500 hover:text-red-500 text-2xl">&times;</button>
                                             </div>
                                             
                                             <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col md:flex-row gap-6">
                                                 {/* Left Column: Treatment Plan */}
                                                 <div className="w-full md:w-1/2 space-y-4">
                                                    <label className="block text-sm font-bold text-gray-700 border-b pb-2">شرح حال و طرح درمان</label>
                                                    <VoiceEnabledTextarea 
                                                        value={editingRecord.note || ''} 
                                                        onChange={(e) => handleRecordFieldChange('note', e.target.value)} 
                                                        rows={12} 
                                                        className="w-full border p-3 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600 disabled:cursor-not-allowed resize-none h-full min-h-[300px]"
                                                        placeholder="یادداشت‌های بالینی و طرح درمان..."
                                                        disabled={!(currentUser.role === 'مدیر' || (currentDoctorId && editingRecord.doctorId === currentDoctorId))}
                                                    />
                                                    {!(currentUser.role === 'مدیر' || (currentDoctorId && editingRecord.doctorId === currentDoctorId)) && (
                                                        <p className="text-xs text-gray-500 italic">فقط پزشک معالج این جلسه می‌تواند طرح درمان را ویرایش کند.</p>
                                                    )}
                                                 </div>
                                                 
                                                 {/* Right Column: Chat Box */}
                                                 <div className="w-full md:w-1/2 flex flex-col bg-gray-50 rounded-xl border overflow-hidden">
                                                    <div className="p-3 bg-gray-100 border-b font-bold text-gray-700 text-sm flex items-center gap-2">
                                                        <UserIcon className="w-4 h-4"/> گفتگو و نظرات (مدیر داخلی / درمانگر)
                                                    </div>
                                                    
                                                    {/* Messages List */}
                                                    <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[250px]">
                                                        {editingRecord.messages && editingRecord.messages.length > 0 ? (
                                                            editingRecord.messages.map((msg) => {
                                                                const isMe = msg.senderId === currentUser.id;
                                                                return (
                                                                    <div key={msg.id} className={`flex flex-col ${isMe ? 'items-start' : 'items-end'}`}>
                                                                        <div className={`max-w-[85%] p-3 rounded-xl text-sm ${isMe ? 'bg-blue-100 text-blue-900 rounded-tr-none' : 'bg-white border text-gray-800 rounded-tl-none shadow-sm'}`}>
                                                                            <span className="text-xs font-bold block mb-1 opacity-70">{msg.senderName} <span className="font-normal">({msg.senderRole})</span></span>
                                                                            {msg.text}
                                                                        </div>
                                                                        <span className="text-[10px] text-gray-400 mt-1 mx-1">{formatToJalali(msg.createdAt)}</span>
                                                                    </div>
                                                                );
                                                            })
                                                        ) : (
                                                            <p className="text-center text-gray-400 text-xs mt-10">هیچ پیامی ثبت نشده است.</p>
                                                        )}
                                                        <div ref={chatEndRef} />
                                                    </div>

                                                    {/* Input Area */}
                                                    <div className="p-3 bg-white border-t flex gap-2 items-center">
                                                        <VoiceEnabledTextarea 
                                                            value={chatInput}
                                                            onChange={(e) => setChatInput(e.target.value)}
                                                            className="flex-1 border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 max-h-20"
                                                            placeholder="پیام خود را بنویسید..."
                                                            rows={1}
                                                        />
                                                        <button 
                                                            onClick={handleSendMessage}
                                                            disabled={!chatInput.trim()}
                                                            className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 disabled:bg-gray-300 transition"
                                                        >
                                                            <SendIcon className="w-5 h-5" />
                                                        </button>
                                                    </div>
                                                 </div>
                                             </div>

                                             <div className="p-4 border-t flex justify-end gap-2 bg-gray-50">
                                                 <button onClick={() => setIsRecordEditorOpen(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg transition">بستن</button>
                                                 <button onClick={handleSaveRecord} className="px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg flex items-center gap-2 shadow transition"><SaveIcon className="w-5 h-5"/> ذخیره تغییرات</button>
                                             </div>
                                         </div>
                                     </div>
                                 )}

                                 {/* List of Appointments to add records to */}
                                 <h4 className="font-bold text-gray-700 mb-2">جلسات درمانی</h4>
                                 {patientAppointments.length > 0 ? patientAppointments.map(app => {
                                     const hasRecord = clinicalRecords.some(r => r.appointmentId === app.id);
                                     const doctor = doctors.find(d => d.id === app.doctorId);
                                     const record = clinicalRecords.find(r => r.appointmentId === app.id);
                                     const hasMessages = record?.messages && record.messages.length > 0;
                                     const isFinished = ['Completed', 'Cancelled'].includes(app.status);
                                     
                                     return (
                                         <div key={app.id} className={`p-4 rounded-xl shadow-sm border ${hasRecord ? 'border-green-200 bg-green-50/30' : 'border-gray-200'} flex justify-between items-center transition hover:shadow-md ${isFinished ? 'bg-gray-100 opacity-90' : 'bg-white'}`}>
                                             <div>
                                                 <div className="flex items-center gap-2">
                                                     <span className={`font-bold ${isFinished ? 'text-gray-600' : 'text-gray-800'}`}>{formatToJalali(app.date)}</span>
                                                     {hasRecord && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">پرونده دارد</span>}
                                                     {hasMessages && <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full flex items-center gap-1">پیام جدید</span>}
                                                 </div>
                                                 <p className="text-xs text-gray-500 mt-1">{doctor?.name}</p>
                                             </div>
                                             <button 
                                                onClick={() => openRecordEditor(app)} 
                                                className={`px-3 py-1.5 rounded-lg text-sm flex items-center gap-1 transition ${hasRecord ? 'bg-blue-50 text-blue-600 hover:bg-blue-100' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}
                                             >
                                                 <DocumentTextIcon className="w-4 h-4"/>
                                                 {hasRecord ? 'مشاهده / ویرایش' : 'ثبت پرونده'}
                                             </button>
                                         </div>
                                     );
                                 }) : <div className="text-center py-10 text-gray-400">هیچ جلسه درمانی ثبت نشده است.</div>}
                             </>
                         )}
                     </div>
                 )}

                 {activeTab === 'attachments' && (
                     <div className="space-y-4">
                         {/* Upload Area for View Modal */}
                         <div 
                            className={`border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition-colors bg-white ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'}`}
                            onClick={() => document.getElementById('attachment-upload-view')?.click()}
                            onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={(e) => {e.preventDefault(); e.stopPropagation(); setIsDragging(false); handleFile(e.dataTransfer.files?.[0] || null, 'attachment');}}
                         >
                             <input type="file" id="attachment-upload-view" accept="image/jpeg,application/pdf" onChange={handleAttachmentChange} className="hidden" />
                             <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-3"><UploadIcon className="w-6 h-6"/></div>
                             <p className="text-sm font-medium text-gray-700">برای آپلود فایل کلیک کنید یا فایل را اینجا رها کنید</p>
                             <p className="text-xs text-gray-400 mt-1">JPG یا PDF (حداکثر 5MB)</p>
                         </div>

                         {viewingPatient.attachments && viewingPatient.attachments.length > 0 ? (
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                 {viewingPatient.attachments.map(att => (
                                     <div key={att.id} className="flex items-center justify-between p-3 bg-white border rounded-lg shadow-sm">
                                         <div className="flex items-center gap-3 overflow-hidden">
                                             <div className="min-w-[2.5rem] h-10 bg-gray-100 rounded-lg flex items-center justify-center text-gray-500 font-bold text-xs uppercase">{att.fileName.split('.').pop()}</div>
                                             <div className="truncate">
                                                 <p className="text-sm font-medium text-gray-800 truncate">{att.fileName}</p>
                                                 <a href={att.dataUrl} download={att.fileName} className="text-xs text-blue-600 hover:underline">دانلود فایل</a>
                                             </div>
                                         </div>
                                         <button onClick={() => handleRemoveAttachment(att.id)} className="text-gray-400 hover:text-red-500 p-1"><TrashIcon className="w-5 h-5"/></button>
                                     </div>
                                 ))}
                             </div>
                         ) : <p className="text-center py-8 text-gray-400">هیچ فایلی ضمیمه نشده است.</p>}
                     </div>
                 )}

                 {activeTab === 'plans' && (
                     <div className="space-y-4">
                         {patientTreatmentPlans.length > 0 ? patientTreatmentPlans.map(plan => (
                             <div key={plan.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                 <div className="flex justify-between items-center mb-2">
                                     <span className={`text-xs px-2 py-1 rounded-full ${plan.status === 'confirmed' ? 'bg-green-100 text-green-800' : (plan.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800')}`}>
                                         {plan.status === 'confirmed' ? 'تایید شده' : (plan.status === 'pending' ? 'در انتظار' : 'بایگانی')}
                                     </span>
                                     <span className="text-xs text-gray-500">{formatToJalali(plan.createdAt)}</span>
                                 </div>
                                 <div className="space-y-2">
                                     {plan.services.map((s, idx) => (
                                         <div key={idx} className="text-sm text-gray-800 flex justify-between">
                                             <span>{s.serviceName} ({s.sessions} جلسه {s.frequency})</span>
                                         </div>
                                     ))}
                                 </div>
                             </div>
                         )) : <p className="text-center py-8 text-gray-400">طرح درمانی ثبت نشده است.</p>}
                     </div>
                 )}

                 {activeTab === 'financial' && isManager && (
                     <div className="space-y-6">
                         {/* Financial Summary Cards */}
                         <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                             <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                 <p className="text-gray-500 text-xs mb-1">کل بدهی (هزینه جلسات)</p>
                                 <p className="text-xl font-bold text-red-600">{financialSummary.totalDebt.toLocaleString('fa-IR')} <span className="text-xs font-normal">تومان</span></p>
                             </div>
                             <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                 <p className="text-gray-500 text-xs mb-1">کل پرداختی (تراکنش‌ها)</p>
                                 <p className="text-xl font-bold text-green-600">{financialSummary.totalPaid.toLocaleString('fa-IR')} <span className="text-xs font-normal">تومان</span></p>
                             </div>
                             <div className={`bg-white p-4 rounded-xl shadow-sm border border-gray-100 ${financialSummary.balance > 0 ? 'bg-red-50' : (financialSummary.balance < 0 ? 'bg-green-50' : '')}`}>
                                 <p className="text-gray-500 text-xs mb-1">مانده حساب</p>
                                 <p className={`text-xl font-bold ${financialSummary.balance > 0 ? 'text-red-700' : (financialSummary.balance < 0 ? 'text-green-700' : 'text-gray-700')}`}>
                                     {Math.abs(financialSummary.balance).toLocaleString('fa-IR')} <span className="text-xs font-normal">تومان {financialSummary.balance > 0 ? '(بدهکار)' : (financialSummary.balance < 0 ? '(بستانکار)' : '(تسویه)')}</span>
                                 </p>
                             </div>
                         </div>

                         {/* Detailed Ledger Table */}
                         <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                             <div className="p-4 bg-gray-50 border-b font-bold text-gray-700 flex items-center gap-2">
                                 <FinancialIcon className="w-5 h-5"/>
                                 ریز تراکنش‌ها و خدمات
                             </div>
                             {financialLedger.length > 0 ? (
                                 <div className="overflow-x-auto">
                                     <table className="w-full text-right text-sm">
                                         <thead className="bg-gray-50 border-b">
                                             <tr>
                                                 <th className="p-3 font-semibold text-gray-600">تاریخ</th>
                                                 <th className="p-3 font-semibold text-gray-600">شرح</th>
                                                 <th className="p-3 font-semibold text-center text-gray-600">بدهکار (هزینه)</th>
                                                 <th className="p-3 font-semibold text-center text-gray-600">بستانکار (پرداخت)</th>
                                                 <th className="p-3 font-semibold text-center text-gray-600">مانده</th>
                                             </tr>
                                         </thead>
                                         <tbody>
                                             {financialLedger.map((item, idx) => (
                                                 <tr key={item.id} className="border-b last:border-0 hover:bg-gray-50 transition-colors">
                                                     <td className="p-3 text-gray-800 whitespace-nowrap">{formatToJalali(item.date)}</td>
                                                     <td className="p-3 text-gray-800">
                                                         <div>{item.description}</div>
                                                         {item.details && (
                                                             <div className="text-xs text-gray-500 mt-1">
                                                                 کل هزینه: {item.details.totalFee.toLocaleString('fa-IR')} | سهم بیمه: {item.details.insuranceShare.toLocaleString('fa-IR')}
                                                             </div>
                                                         )}
                                                     </td>
                                                     <td className="p-3 text-center">
                                                         {item.type === 'debt' ? (
                                                             <span className="font-medium text-red-600">{item.amount.toLocaleString('fa-IR')}</span>
                                                         ) : '-'}
                                                     </td>
                                                     <td className="p-3 text-center">
                                                         {item.type === 'credit' ? (
                                                             <span className="font-medium text-green-600">{item.amount.toLocaleString('fa-IR')}</span>
                                                         ) : '-'}
                                                     </td>
                                                     <td className="p-3 text-center">
                                                         <span className={`font-bold ${item.balance! > 0 ? 'text-red-700' : (item.balance! < 0 ? 'text-green-700' : 'text-gray-400')}`}>
                                                             {Math.abs(item.balance!).toLocaleString('fa-IR')} {item.balance! > 0 ? 'بد' : (item.balance! < 0 ? 'بس' : '')}
                                                         </span>
                                                     </td>
                                                 </tr>
                                             ))}
                                         </tbody>
                                     </table>
                                 </div>
                             ) : (
                                 <p className="text-center py-10 text-gray-400">هیچ سابقه مالی برای این بیمار یافت نشد.</p>
                             )}
                         </div>
                     </div>
                 )}
               </div>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" onClick={closeModal}>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-2xl font-bold mb-6">{editingPatient ? 'ویرایش بیمار' : 'افزودن بیمار جدید'}</h3>
              <form onSubmit={handleSavePatient} className="space-y-6">
                <div className="flex flex-col md:flex-row gap-8">
                    <div className="w-full md:w-1/3 flex flex-col items-center space-y-4">
                        <div 
                            className={`relative group w-40 h-40 border-2 border-dashed rounded-full flex justify-center items-center cursor-pointer transition-colors ${isDragging ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-500 hover:bg-gray-50'}`}
                            onClick={() => document.getElementById('photo-upload')?.click()}
                            onDragOver={handleDragOver}
                            onDragLeave={handleDragLeave}
                            onDrop={handleDrop}
                        >
                            <input type="file" id="photo-upload" accept="image/png, image/jpeg" onChange={handlePhotoChange} className="hidden" />
                            {formData.photoUrl ? (
                                <>
                                    <img src={formData.photoUrl} alt="Preview" className="w-full h-full rounded-full object-cover" />
                                    <button type="button" onClick={(e) => { e.stopPropagation(); handleRemovePhoto(); }} className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity" title="حذف عکس"><TrashIcon className="w-4 h-4" /></button>
                                </>
                            ) : (
                                <div className="text-center text-gray-500 p-4"><UserCircleIcon className="w-16 h-16 mx-auto text-gray-400" /><p className="mt-2 text-xs">انتخاب یا کشیدن عکس</p></div>
                            )}
                        </div>
                        <p className="text-xs text-gray-500 text-center">حداکثر حجم: ۵۰۰ کیلوبایت (JPG, PNG)</p>
                    </div>

                    <div className="w-full md:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="col-span-2 sm:col-span-1">
                            <label className="block text-gray-700 mb-2 font-medium">نام کامل<span className="text-red-500 mr-1">*</span></label>
                            <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" required />
                        </div>
                        <div className="col-span-2 sm:col-span-1">
                            <label className="block text-gray-700 mb-2 font-medium">تشخیص پزشک</label>
                            <input type="text" name="diagnosis" value={formData.diagnosis || ''} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" placeholder="مثال: دیسک کمر" />
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">شماره تماس ۱<span className="text-red-500 mr-1">*</span></label>
                            <input type="tel" name="phone1" value={formData.phone1} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" required />
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">شماره تماس ۲</label>
                            <input type="tel" name="phone2" value={formData.phone2 || ''} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" />
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">کد ملی</label>
                            <input type="text" name="nationalId" value={formData.nationalId} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" />
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">سن</label>
                            <input type="number" name="age" value={formData.age} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" />
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">جنسیت</label>
                            <select name="gender" value={formData.gender} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg bg-white">
                                <option value="مرد">مرد</option>
                                <option value="زن">زن</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">بیمه</label>
                            <select name="insuranceProviderId" value={formData.insuranceProviderId || ''} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg bg-white">
                                <option value="">آزاد</option>
                                {insuranceProviders.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">پزشک معرف</label>
                            <select name="referredById" value={formData.referredById || ''} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg bg-white">
                                <option value="">انتخاب کنید</option>
                                {doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2 font-medium">نحوه آشنایی</label>
                            <select name="referralSource" value={formData.referralSource || ''} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg bg-white">
                                <option value="">انتخاب کنید</option>
                                {REFERRAL_SOURCES_DATA.map(src => <option key={src} value={src}>{src}</option>)}
                            </select>
                        </div>
                    </div>
                </div>
                
                <div>
                    <label className="block text-gray-700 mb-2 font-medium">یادداشت / طرح کلی درمان</label>
                    <VoiceEnabledTextarea name="nextSessionPlan" value={formData.nextSessionPlan || ''} onChange={handleInputChange} className="w-full p-2.5 border rounded-lg" rows={3} />
                </div>

                {/* File Upload Section in Add/Edit Modal */}
                <div className="border-t pt-4">
                    <label className="block text-gray-700 mb-2 font-medium">فایل‌های ضمیمه</label>
                    <div className="flex items-center gap-4">
                        <div className="relative overflow-hidden inline-block">
                            <button type="button" onClick={() => document.getElementById('attachment-upload-edit')?.click()} className="bg-gray-100 text-gray-700 hover:bg-gray-200 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
                                <UploadIcon className="w-5 h-5"/> انتخاب فایل
                            </button>
                            <input type="file" id="attachment-upload-edit" accept="image/jpeg,application/pdf" onChange={handleAttachmentChange} className="absolute inset-0 opacity-0 cursor-pointer w-full"/>
                        </div>
                        <span className="text-xs text-gray-500">فایل‌های انتخاب شده پس از ذخیره فرم آپلود می‌شوند.</span>
                    </div>
                    {formData.attachments && formData.attachments.length > 0 && (
                        <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {formData.attachments.map(att => (
                                <div key={att.id} className="flex justify-between items-center p-2 bg-gray-50 rounded border text-sm">
                                    <span className="truncate max-w-[200px]">{att.fileName}</span>
                                    <button type="button" onClick={() => handleRemoveAttachment(att.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-4 h-4"/></button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="flex justify-end mt-6 pt-4 border-t">
                  <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400 transition">لغو</button>
                  <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">ذخیره</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientManagement;