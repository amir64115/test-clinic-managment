import React, { useState } from 'react';
import VoiceEnabledTextarea from './VoiceEnabledTextarea';
import { ClipboardListIcon, SaveIcon, PhoneIcon, UserIcon } from './icons/Icons';

interface QuickIntakeProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (phone: string, name: string, description: string) => Promise<void>;
}

const QuickIntake: React.FC<QuickIntakeProps> = ({ isOpen, onClose, onSave }) => {
    const [phone, setPhone] = useState('');
    const [patientName, setPatientName] = useState('');
    const [description, setDescription] = useState('');
    const [isSaving, setIsSaving] = useState(false);

    const resetState = () => {
        setPhone('');
        setPatientName('');
        setDescription('');
        setIsSaving(false);
    };

    const handleClose = () => {
        resetState();
        onClose();
    };

    const handleSave = async () => {
        if (!phone.trim() || !patientName.trim() || !description.trim()) {
            alert('لطفا نام بیمار، شماره تماس و شرح درخواست را وارد کنید.');
            return;
        }
        setIsSaving(true);
        
        try {
            await onSave(phone.trim(), patientName.trim(), description.trim());
            handleClose();
        } catch (error) {
            console.error("Failed to save quick intake:", error);
            alert("خطا در ثبت تماس. لطفا دوباره تلاش کنید.");
            setIsSaving(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 sm:p-6">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b">
                    <h3 className="text-xl font-bold text-gray-800">ثبت تماس و افزودن به لیست انتظار</h3>
                    <p className="text-sm text-gray-500 mt-1">اطلاعات تماس بیمار را برای افزودن به لیست انتظار وارد کنید.</p>
                </div>

                <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6">
                    <div>
                        <label htmlFor="patient-phone" className="flex items-center text-gray-700 font-semibold mb-2">
                            <PhoneIcon className="w-5 h-5 ml-2 text-gray-400"/>
                            شماره تماس بیمار
                            <span className="text-red-500 mr-1">*</span>
                        </label>
                        <input 
                            id="patient-phone"
                            type="tel"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="w-full p-3 border rounded-lg bg-white focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="مثال: 09123456789"
                            required
                            autoFocus
                        />
                    </div>
                     <div>
                        <label htmlFor="patient-name" className="flex items-center text-gray-700 font-semibold mb-2">
                            <UserIcon className="w-5 h-5 ml-2 text-gray-400"/>
                            نام بیمار
                            <span className="text-red-500 mr-1">*</span>
                        </label>
                        <input 
                            id="patient-name"
                            type="text"
                            value={patientName}
                            onChange={(e) => setPatientName(e.target.value)}
                            className="w-full p-3 border rounded-lg bg-white focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="نام کامل بیمار را وارد کنید"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="call-description" className="flex items-center text-gray-700 font-semibold mb-2">
                            <ClipboardListIcon className="w-5 h-5 ml-2 text-gray-400"/>
                            شرح تماس و درخواست بیمار
                            <span className="text-red-500 mr-1">*</span>
                        </label>
                        <VoiceEnabledTextarea
                            id="call-description"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            className="w-full p-3 border rounded-lg h-32 bg-white focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="خلاصه ای از تماس و درخواست بیمار را اینجا وارد کنید..."
                            required
                        />
                    </div>
                </div>

                <div className="flex flex-col-reverse sm:flex-row sm:justify-end items-center p-6 gap-3 bg-gray-50 border-t rounded-b-xl">
                    <button type="button" onClick={handleClose} className="w-full sm:w-auto bg-gray-200 text-gray-800 px-6 py-2.5 rounded-lg hover:bg-gray-300 font-semibold transition">
                        انصراف
                    </button>
                    <button 
                        type="button" 
                        onClick={handleSave} 
                        disabled={isSaving}
                        className="w-full sm:w-auto bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2 font-semibold disabled:bg-gray-400 disabled:cursor-not-allowed transition"
                    >
                        <SaveIcon className="w-5 h-5"/>
                        {isSaving ? 'در حال افزودن...' : 'افزودن به لیست انتظار'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default QuickIntake;
