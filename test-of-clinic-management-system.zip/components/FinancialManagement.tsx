
import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Transaction, Patient, Doctor, Personnel, BankAccount, InsuranceProvider, CostCategory, PermissionSet } from '../types';
import { TrashIcon, EditIcon, JalaliDatePicker, TrendingUpIcon, TrendingDownIcon, FilterIcon } from './icons/Icons';
import { formatToJalali } from '../utils/dateUtils';
import { formatNumberWithCommas, parseFormattedNumber } from '../utils/numberUtils';
import VoiceEnabledTextarea from './VoiceEnabledTextarea';

interface FinancialManagementProps {
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction>;
  updateTransaction: (transaction: Transaction) => Promise<Transaction>;
  deleteTransaction: (id: string) => Promise<void>;
  patients: Patient[];
  doctors: Doctor[];
  personnel: Personnel[];
  bankAccounts: BankAccount[];
  addBankAccount: (account: Omit<BankAccount, 'id'>) => Promise<BankAccount>;
  updateBankAccount: (account: BankAccount) => Promise<BankAccount>;
  deleteBankAccount: (id: string) => Promise<void>;
  insuranceProviders: InsuranceProvider[];
  addInsuranceProvider: (provider: Omit<InsuranceProvider, 'id'>) => Promise<InsuranceProvider>;
  updateInsuranceProvider: (provider: InsuranceProvider) => Promise<InsuranceProvider>;
  deleteInsuranceProvider: (id: string) => Promise<void>;
  costCategories: CostCategory[];
  addCostCategory: (category: Omit<CostCategory, 'id'>) => Promise<CostCategory>;
  updateCostCategory: (category: CostCategory) => Promise<CostCategory>;
  deleteCostCategory: (id: string) => Promise<void>;
  permissions: PermissionSet;
}

const emptyTransaction: Omit<Transaction, 'id'> = {
  type: 'هزینه',
  description: '',
  amount: 0,
  date: new Date().toISOString().split('T')[0],
};

const SimpleListManager = <T extends { id: string; name: string;[key: string]: any }>({ title, items, addItem, updateItem, deleteItem, formContent, emptyItem, permissions }: {
  title: string;
  items: T[];
  addItem: (item: Omit<T, 'id'>) => Promise<T>;
  updateItem: (item: T) => Promise<T>;
  deleteItem: (id: string) => Promise<void>;
  formContent: (formData: Omit<T, 'id'>, setFormData: React.Dispatch<React.SetStateAction<Omit<T, 'id'>>>) => React.ReactNode;
  emptyItem: Omit<T, 'id'>;
  permissions: PermissionSet;
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<T, 'id'>>(emptyItem);
  const [editingItem, setEditingItem] = useState<T | null>(null);

  const openModal = (item: T | null) => {
    setEditingItem(item);
    setFormData(item || emptyItem);
    setIsModalOpen(true);
  };
  const closeModal = () => setIsModalOpen(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if ('name' in formData && !(formData as any).name) {
        alert('فیلد نام اجباری است.');
        return;
    }
    try {
        if (editingItem) {
          await updateItem({ ...formData, id: editingItem.id } as T);
        } else {
          await addItem(formData);
        }
        closeModal();
    } catch(error) {
        console.error(`Failed to save ${title}`, error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm(`آیا از حذف این مورد اطمینان دارید؟`)) {
        try {
            await deleteItem(id);
        } catch(error) {
            console.error(`Failed to delete ${title}`, error);
        }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-gray-800">{title}</h3>
        {permissions.add && <button onClick={() => openModal(null)} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">افزودن مورد جدید</button>}
      </div>
      
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead className="bg-gray-50 border-b">
             <tr>
                <th className="p-3 font-semibold">نام</th>
                <th className="p-3 font-semibold"></th>
             </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.id} className="border-b hover:bg-gray-50">
                <td className="p-3 font-medium">{item.name}</td>
                <td className="p-3 flex items-center justify-end space-x-2 space-x-reverse">
                  {permissions.edit && <button onClick={() => openModal(item)} className="text-gray-500 hover:text-green-600 p-1" title="ویرایش"><EditIcon className="w-5 h-5" /></button>}
                  {permissions.delete && <button onClick={() => handleDelete(item.id)} className="text-gray-500 hover:text-red-600 p-1" title="حذف"><TrashIcon className="w-5 h-5" /></button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-4">
        {items.map(item => (
          <div key={item.id} className="bg-gray-50 p-4 rounded-lg border">
            <div className="flex justify-between items-center">
              <p className="font-bold">{item.name}</p>
              <div className="flex items-center space-x-1 space-x-reverse">
                {permissions.edit && <button onClick={() => openModal(item)} className="text-gray-500 hover:text-green-600 p-2" title="ویرایش"><EditIcon className="w-5 h-5" /></button>}
                {permissions.delete && <button onClick={() => handleDelete(item.id)} className="text-gray-500 hover:text-red-600 p-2" title="حذف"><TrashIcon className="w-5 h-5" /></button>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {items.length === 0 && <p className="text-center text-gray-500 py-8">موردی برای نمایش وجود ندارد.</p>}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" onClick={closeModal}>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-4">{editingItem ? 'ویرایش' : 'افزودن'}</h3>
              <form onSubmit={handleSave} className="space-y-4">
                {formContent(formData, setFormData)}
                <div className="flex justify-end mt-6">
                  <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">لغو</button>
                  <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">ذخیره</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


const FinancialManagement: React.FC<FinancialManagementProps> = (props) => {
    const {
    transactions, addTransaction, updateTransaction, deleteTransaction,
    patients, doctors, personnel,
    bankAccounts, addBankAccount, updateBankAccount, deleteBankAccount,
    insuranceProviders, addInsuranceProvider, updateInsuranceProvider, deleteInsuranceProvider,
    costCategories, addCostCategory, updateCostCategory, deleteCostCategory,
    permissions
  } = props;
  
  const [activeTab, setActiveTab] = useState<'transactions' | 'accounts' | 'insurance' | 'categories'>('transactions');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<Transaction, 'id'>>(emptyTransaction);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'درآمد' | 'هزینه'>('all');

  const [patientSearch, setPatientSearch] = useState('');
  const [isPatientDropdownOpen, setIsPatientDropdownOpen] = useState(false);
  const patientSearchRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (patientSearchRef.current && !patientSearchRef.current.contains(event.target as Node)) {
            setIsPatientDropdownOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const availablePatients = useMemo(() => {
    if (!patientSearch) return [];
    return patients.filter(p => 
      p.name.toLowerCase().includes(patientSearch.toLowerCase())
    );
  }, [patients, patientSearch]);


  const filteredTransactions = useMemo(() => {
    return transactions
      .filter(t => filterType === 'all' || t.type === filterType)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, filterType]);

  const financialSummary = useMemo(() => {
    const income = filteredTransactions.filter(t => t.type === 'درآمد').reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    const expense = filteredTransactions.filter(t => t.type === 'هزینه').reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    return { income, expense, profit: income - expense };
  }, [filteredTransactions]);

  const openAddModal = () => { 
    setEditingTransaction(null); 
    setFormData(emptyTransaction); 
    setPatientSearch('');
    setIsModalOpen(true); 
  };
  const openEditModal = (transaction: Transaction) => { 
    setEditingTransaction(transaction); 
    setFormData(transaction); 
    setPatientSearch('');
    setIsModalOpen(true); 
  };
  const closeModal = () => {
    setIsModalOpen(false);
    setEditingTransaction(null);
    setFormData(emptyTransaction);
    setPatientSearch('');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let finalValue: any = value;
    if (name === 'amount') finalValue = parseFormattedNumber(value);
    else if (['doctorId', 'personnelId'].includes(name)) finalValue = value ? value : undefined;
    
    setFormData(prev => {
        const newState = { ...prev, [name]: finalValue };
        if (name === 'type') {
            if (value === 'درآمد') {
                newState.costCategory = undefined;
                newState.personnelId = undefined;
                newState.paymentMethod = 'نقد'; // Default for income
            } else { // It's 'هزینه'
                newState.patientId = undefined;
                newState.paymentMethod = undefined; // Clear for expense
            }
        }
        return newState;
    });
  };
  
  const handlePatientSelect = (patientId: string) => {
    setFormData(prev => ({ ...prev, patientId }));
    setPatientSearch('');
    setIsPatientDropdownOpen(false);
  };
  
  const handleDateChange = (date: string) => setFormData(prev => ({ ...prev, date }));

  const handleSaveTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.description || formData.amount <= 0) {
        alert('لطفا شرح و مبلغ تراکنش را به درستی وارد کنید.');
        return;
    }
    // Removed check for patientId requirement for income transactions as requested.

    try {
        if (editingTransaction) {
            await updateTransaction({ ...formData, id: editingTransaction.id });
        } else {
            await addTransaction(formData);
        }
        closeModal();
    } catch(error) {
        console.error('Failed to save transaction:', error);
    }
  };

  const handleDeleteTransaction = async (id: string) => {
    if (window.confirm('آیا از حذف این تراکنش اطمینان دارید؟')) {
      try {
        await deleteTransaction(id);
      } catch(error) {
          console.error('Failed to delete transaction:', error);
      }
    }
  };
  
  const tabs = [
    { id: 'transactions', label: 'تراکنش‌ها' },
    { id: 'accounts', label: 'حساب‌های بانکی' },
    { id: 'insurance', label: 'بیمه‌ها' },
    { id: 'categories', label: 'سرفصل‌های هزینه' },
  ];

  return (
    <div>
      <h2 className="text-2xl sm:text-3xl font-bold mb-6">مدیریت مالی</h2>
      <div className="mb-6 border-b border-gray-200">
        <nav className="-mb-px flex space-x-4 space-x-reverse overflow-x-auto">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`whitespace-nowrap py-3 px-4 border-b-2 font-medium text-sm ${activeTab === tab.id ? 'border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {activeTab === 'transactions' && (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                <div className="bg-green-50 p-6 rounded-lg flex items-center gap-4"><div className="bg-green-500 text-white p-3 rounded-full"><TrendingUpIcon className="w-6 h-6"/></div><div><p className="text-gray-500">مجموع درآمد</p><p className="text-xl font-bold text-green-800">{financialSummary.income.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p></div></div>
                <div className="bg-red-50 p-6 rounded-lg flex items-center gap-4"><div className="bg-red-500 text-white p-3 rounded-full"><TrendingDownIcon className="w-6 h-6"/></div><div><p className="text-gray-500">مجموع هزینه</p><p className="text-xl font-bold text-red-800">{financialSummary.expense.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p></div></div>
                <div className="bg-blue-50 p-6 rounded-lg flex items-center gap-4"><div className="bg-blue-500 text-white p-3 rounded-full"><FilterIcon className="w-6 h-6"/></div><div><p className="text-gray-500">سود خالص</p><p className={`text-xl font-bold ${financialSummary.profit < 0 ? 'text-red-600' : 'text-green-600'}`}>{financialSummary.profit.toLocaleString('fa-IR')} <span className="text-sm font-normal">تومان</span></p></div></div>
            </div>
            <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
                <select onChange={(e) => setFilterType(e.target.value as any)} value={filterType} className="p-2 border rounded-lg bg-white shadow-sm">
                    <option value="all">همه تراکنش‌ها</option>
                    <option value="درآمد">فقط درآمدها</option>
                    <option value="هزینه">فقط هزینه‌ها</option>
                </select>
                {permissions.add && <button onClick={openAddModal} className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition">ثبت تراکنش جدید</button>}
            </div>

            <div className="bg-white p-2 sm:p-4 rounded-lg shadow-md">
                 <div className="hidden md:block overflow-x-auto">
                    <table className="w-full text-right text-sm">
                        <thead className="bg-gray-50 border-b">
                            <tr>
                                <th className="p-3 font-semibold">تاریخ</th><th className="p-3 font-semibold">شرح</th><th className="p-3 font-semibold">نوع</th><th className="p-3 font-semibold">مبلغ</th><th className="p-3 font-semibold">عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredTransactions.map(t => (
                                <tr key={t.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3">{formatToJalali(t.date)}</td>
                                    <td className="p-3">{t.description}</td>
                                    <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${t.type === 'درآمد' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{t.type}</span></td>
                                    <td className={`p-3 font-semibold ${t.type === 'درآمد' ? 'text-green-700' : 'text-red-700'}`}>{t.amount.toLocaleString('fa-IR')}</td>
                                    <td className="p-3 flex items-center space-x-2 space-x-reverse">
                                        {permissions.edit && <button onClick={() => openEditModal(t)} className="text-gray-500 hover:text-green-600 p-1"><EditIcon className="w-5 h-5"/></button>}
                                        {permissions.delete && <button onClick={() => handleDeleteTransaction(t.id)} className="text-gray-500 hover:text-red-600 p-1"><TrashIcon className="w-5 h-5"/></button>}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 <div className="md:hidden space-y-4">
                    {filteredTransactions.map(t => (
                        <div key={t.id} className="bg-gray-50 p-4 rounded-lg border">
                            <div className="flex justify-between items-start">
                                <div><p className="font-bold">{t.description}</p><p className={`font-semibold text-lg mt-1 ${t.type === 'درآمد' ? 'text-green-700' : 'text-red-700'}`}>{t.amount.toLocaleString('fa-IR')} تومان</p></div>
                                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${t.type === 'درآمد' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{t.type}</span>
                            </div>
                             <div className="flex justify-between items-center mt-2 pt-2 border-t">
                                 <p className="text-sm text-gray-500">{formatToJalali(t.date)}</p>
                                 <div className="flex items-center gap-2">
                                     {permissions.edit && <button onClick={() => openEditModal(t)} className="text-gray-500 hover:text-green-600 p-1"><EditIcon className="w-5 h-5"/></button>}
                                     {permissions.delete && <button onClick={() => handleDeleteTransaction(t.id)} className="text-gray-500 hover:text-red-600 p-1"><TrashIcon className="w-5 h-5"/></button>}
                                 </div>
                             </div>
                        </div>
                    ))}
                </div>
                {filteredTransactions.length === 0 && <p className="text-center py-8 text-gray-500">تراکنشی یافت نشد.</p>}
            </div>
        </div>
      )}

      {activeTab === 'accounts' && <SimpleListManager title="حساب‌های بانکی" items={bankAccounts} addItem={addBankAccount} updateItem={updateBankAccount} deleteItem={deleteBankAccount} emptyItem={{ name: '', accountNumber: '' }} permissions={permissions} formContent={(formData, setFormData) => (
          <>
            <div><label className="block mb-1">نام حساب*</label><input type="text" value={formData.name} onChange={e => setFormData(p => ({...p, name: e.target.value}))} className="w-full p-2 border rounded-lg" required /></div>
            <div><label className="block mb-1">شماره حساب (اختیاری)</label><input type="text" value={formData.accountNumber || ''} onChange={e => setFormData(p => ({...p, accountNumber: e.target.value}))} className="w-full p-2 border rounded-lg" /></div>
          </>
      )} />}

      {activeTab === 'insurance' && <SimpleListManager title="بیمه‌ها" items={insuranceProviders} addItem={addInsuranceProvider} updateItem={updateInsuranceProvider} deleteItem={deleteInsuranceProvider} emptyItem={{ name: '', commissionType: 'percentage', commissionValue: 0 }} permissions={permissions} formContent={(formData, setFormData) => (
          <>
            <div><label className="block mb-1">نام بیمه*</label><input type="text" value={formData.name} onChange={e => setFormData(p => ({...p, name: e.target.value}))} className="w-full p-2 border rounded-lg" required /></div>
            <div><label className="block mb-1">نوع فرانشیز</label><select value={formData.commissionType} onChange={e => setFormData(p => ({...p, commissionType: e.target.value as any}))} className="w-full p-2 border rounded-lg"><option value="percentage">درصدی</option><option value="fixed">مبلغ ثابت</option></select></div>
            <div><label className="block mb-1">مقدار فرانشیز*</label><input type="number" value={formData.commissionValue} onChange={e => setFormData(p => ({...p, commissionValue: Number(e.target.value)}))} className="w-full p-2 border rounded-lg" required /></div>
          </>
      )} />}

      {activeTab === 'categories' && <SimpleListManager title="سرفصل‌های هزینه" items={costCategories} addItem={addCostCategory} updateItem={updateCostCategory} deleteItem={deleteCostCategory} emptyItem={{ name: '' }} permissions={permissions} formContent={(formData, setFormData) => (
          <div><label className="block mb-1">نام سرفصل*</label><input type="text" value={formData.name} onChange={e => setFormData(p => ({...p, name: e.target.value}))} className="w-full p-2 border rounded-lg" required /></div>
      )} />}
      
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" onClick={closeModal}>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-6">{editingTransaction ? 'ویرایش تراکنش' : 'ثبت تراکنش جدید'}</h3>
              <form onSubmit={handleSaveTransaction} className="space-y-4">
                
                <div className="p-4 border rounded-lg bg-gray-50/50">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-gray-700 mb-1">نوع*</label>
                            {editingTransaction ? (
                                <input 
                                    type="text" 
                                    value={formData.type} 
                                    disabled 
                                    className="w-full p-2.5 border rounded-lg bg-gray-200 cursor-not-allowed" 
                                />
                            ) : (
                                <select 
                                    name="type"
                                    value={formData.type}
                                    onChange={handleInputChange}
                                    className="w-full p-2.5 border rounded-lg bg-white"
                                >
                                    <option value="هزینه">هزینه</option>
                                    <option value="درآمد">درآمد</option>
                                </select>
                            )}
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-1">مبلغ (تومان)*</label>
                            <input type="text" name="amount" value={formatNumberWithCommas(formData.amount)} onChange={handleInputChange} className="w-full p-2 border rounded-lg bg-white" required />
                        </div>
                        <JalaliDatePicker label="تاریخ*" value={formData.date} onChange={handleDateChange} required />
                    </div>
                     <div className="mt-4">
                        <label className="block text-gray-700 mb-1">شرح*</label>
                        <VoiceEnabledTextarea name="description" value={formData.description} onChange={handleInputChange} className="w-full p-2 border rounded-lg bg-white" required rows={2}/>
                    </div>
                </div>

                <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold text-gray-700 mb-3 -mt-1">جزئیات تراکنش</h4>
                    {formData.type === 'درآمد' && (
                        <div className="space-y-4">
                            <div>
                                <label className="block text-gray-700 mb-1">مربوط به بیمار <span className="text-gray-500 text-xs">(اختیاری)</span></label>
                                <div ref={patientSearchRef} className="relative">
                                    {formData.patientId ? (
                                        <div className="w-full p-2 border rounded-lg bg-gray-100 flex justify-between items-center">
                                            <span>{patients.find(p => p.id === formData.patientId)?.name}</span>
                                            <button type="button" onClick={() => setFormData(prev => ({...prev, patientId: undefined}))} className="text-red-500 hover:font-bold">&times;</button>
                                        </div>
                                    ) : (
                                        <>
                                            <input
                                                type="text"
                                                placeholder="جستجوی بیمار..."
                                                value={patientSearch}
                                                onChange={e => { setPatientSearch(e.target.value); setIsPatientDropdownOpen(true); }}
                                                onFocus={() => setIsPatientDropdownOpen(true)}
                                                className="w-full p-2 border rounded-lg"
                                            />
                                            {isPatientDropdownOpen && availablePatients.length > 0 && (
                                                <div className="absolute z-10 w-full bg-white border rounded-lg mt-1 max-h-48 overflow-y-auto shadow-lg">
                                                    {availablePatients.map(p => (
                                                        <div key={p.id} onClick={() => handlePatientSelect(p.id)} className="p-2 hover:bg-gray-100 cursor-pointer">{p.name}</div>
                                                    ))}
                                                </div>
                                            )}
                                        </>
                                    )}
                                </div>
                            </div>
                            <div>
                                <label className="block text-gray-700 mb-1">مربوط به پزشک (اختیاری)</label>
                                <select name="doctorId" value={formData.doctorId || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg"><option value="">هیچکدام</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
                            </div>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-gray-700 mb-1">روش پرداخت</label>
                                    <select name="paymentMethod" value={formData.paymentMethod || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg">
                                        <option value="نقد">نقد</option>
                                        <option value="کارت به کارت">کارت به کارت</option>
                                        <option value="پوز">پوز</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-gray-700 mb-1">به حساب</label>
                                    <select name="accountDebited" value={formData.accountDebited || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg">
                                        <option value="">انتخاب کنید</option>
                                        {bankAccounts.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                                    </select>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {formData.type === 'هزینه' && (
                         <div className="space-y-4">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div><label className="block text-gray-700 mb-1">سرفصل هزینه*</label><select name="costCategory" value={formData.costCategory || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg" required><option value="">انتخاب کنید</option>{costCategories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}</select></div>
                                <div>
                                    <label className="block text-gray-700 mb-1">از حساب</label>
                                    <select name="accountDebited" value={formData.accountDebited || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg">
                                        <option value="">انتخاب کنید</option>
                                        {bankAccounts.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                                    </select>
                                </div>
                            </div>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div><label className="block text-gray-700 mb-1">پرداخت به پزشک (اختیاری)</label><select name="doctorId" value={formData.doctorId || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg"><option value="">هیچکدام</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
                                <div><label className="block text-gray-700 mb-1">پرداخت به پرسنل (اختیاری)</label><select name="personnelId" value={formData.personnelId || ''} onChange={handleInputChange} className="w-full p-2 border rounded-lg"><option value="">هیچکدام</option>{personnel.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex justify-end mt-6">
                  <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg ml-2 hover:bg-gray-400">لغو</button>
                  <button type="submit" className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700">ذخیره</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FinancialManagement;
