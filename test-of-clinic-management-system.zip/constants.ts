
import type { Patient, Doctor, Appointment, Transaction, BankAccount, InsuranceProvider, Personnel, CostCategory, AppPermissions, TreatmentPlan, ClinicalRecord } from './types';

export const TREATMENT_SERVICE_NAMES_DATA: string[] = [
  'کار درمانی',
  'گفتار درمانی',
  'بازی درمانی',
  'روانشناسی',
  'آموزش',
  'مشاوره',
  'ارزیابی',
];

export const REFERRAL_SOURCES_DATA: string[] = [
  'وبسایت کلینیک',
  'اینستاگرام',
  'معرفی توسط بیمار دیگر',
  'معرفی توسط پزشک',
  'تابلوی کلینیک',
  'جستجوی اینترنتی',
  'سایر',
];

export const BANK_ACCOUNTS_DATA: BankAccount[] = [
  { id: '1', name: 'حساب بانک ملت', accountNumber: '123-456-789' },
  { id: '2', name: 'حساب بانک ملی', accountNumber: '987-654-321' },
  { id: '3', name: 'صندوق نقدی کلینیک' },
];

export const INSURANCE_PROVIDERS_DATA: InsuranceProvider[] = [
  { id: '1', name: 'تامین اجتماعی', commissionType: 'percentage', commissionValue: 70 },
  { id: '2', name: 'خدمات درمانی', commissionType: 'percentage', commissionValue: 85 },
  { id: '3', name: 'بیمه تکمیلی ایران', commissionType: 'percentage', commissionValue: 90 },
  { id: '4', name: 'بیمه البرز (طرح ویژه)', commissionType: 'fixed', commissionValue: 150000 },
];

export const COST_CATEGORIES_DATA: CostCategory[] = [
    { id: '1', name: 'حقوق و دستمزد' },
    { id: '2', name: 'اجاره' },
    { id: '3', name: 'قبوض و شارژ' },
    { id: '4', name: 'ملزومات مصرفی' },
    { id: '5', name: 'تعمیر و نگهداری' },
    { id: '6', name: 'تبلیغات و بازاریابی' },
    { id: '7', name: 'مالیات و عوارض' },
    { id: '8', name: 'پذیرایی و تشریفات' },
    { id: '9', name: 'ایاب و ذهاب' },
    { id: '10', name: 'سایر' },
];

export const TREATMENT_PLANS_DATA: TreatmentPlan[] = [];

export const CLINICAL_RECORDS_DATA: ClinicalRecord[] = [
  {
    id: '1',
    appointmentId: '101',
    patientId: '1',
    doctorId: '1',
    createdAt: "2024-05-10T10:00:00Z",
    updatedAt: "2024-05-10T10:15:00Z",
    note: "بیمار از درد قفسه سینه هنگام ورزش شکایت دارد. درد را به صورت فشاری توصیف می‌کند. فشار خون 130/80. نوار قلب در حالت استراحت ریتم سینوسی نرمال را نشان می‌دهد. معاینه قلبی بدون سوفل. آنژین پایدار. شروع درمان با متوپرولول 25 میلی‌گرم روزانه. برنامه‌ریزی برای تست ورزش در هفته آینده.",
    messages: [],
    subjective: "بیمار از درد قفسه سینه هنگام ورزش شکایت دارد. درد را به صورت فشاری توصیف می‌کند.",
    objective: "فشار خون 130/80. نوار قلب در حالت استراحت ریتم سینوسی نرمال را نشان می‌دهد. معاینه قلبی بدون سوفل.",
    assessment: "آنژین پایدار.",
    plan: "شروع درمان با متوپرولول 25 میلی‌گرم روزانه. برنامه‌ریزی برای تست ورزش در هفته آینده."
  },
  {
    id: '2',
    appointmentId: '102',
    patientId: '2',
    doctorId: '2',
    createdAt: "2024-05-11T11:30:00Z",
    updatedAt: "2024-05-11T11:40:00Z",
    note: "مادر گزارش می‌دهد کودک 3 ساله از 3 روز پیش تب 38.5 درجه و سرفه دارد. کودک هوشیار. گلوی قرمز و ملتهب. ریه‌ها در سمع پاک هستند. گوش‌ها نرمال. فارنژیت ویروسی. توصیه به مراقبت‌های حمایتی شامل استراحت، مصرف مایعات فراوان و استامینوفن برای تب. نیازی به آنتی‌بیوتیک نیست.",
    messages: [],
    subjective: "مادر گزارش می‌دهد کودک 3 ساله از 3 روز پیش تب 38.5 درجه و سرفه دارد.",
    objective: "کودک هوشیار. گلوی قرمز و ملتهب. ریه‌ها در سمع پاک هستند. گوش‌ها نرمال.",
    assessment: "فارنژیت ویروسی.",
    plan: "توصیه به مراقبت‌های حمایتی شامل استراحت، مصرف مایعات فراوان و استامینوفن برای تب. نیازی به آنتی‌بیوتیک نیست."
  }
];


export const DEFAULT_PERMISSIONS: AppPermissions = {
    'مدیر': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true },
        doctors: { view: true, add: true, edit: true, delete: true },
        personnel: { view: true, add: true, edit: true, delete: true },
        appointments: { view: true, add: true, edit: true, delete: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: true, add: true }, // view = backup, add = restore
        settings: { view: true },
    },
    'مدیریت': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true },
        doctors: { view: true, add: true, edit: true, delete: true },
        personnel: { view: true, add: true, edit: true, delete: true },
        appointments: { view: true, add: true, edit: true, delete: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: true, add: true },
        settings: { view: true },
    },
    'مدیر داخلی': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true },
        doctors: { view: true, add: true, edit: true, delete: true },
        personnel: { view: false },
        appointments: { view: true, add: true, edit: true, delete: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: true, add: true },
        settings: { view: false },
    },
    'حسابدار': {
        dashboard: { view: true },
        patients: { view: true },
        doctors: { view: true },
        personnel: { view: false },
        appointments: { view: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: false },
        settings: { view: false },
    },
    'پزشک': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true }, // Doctors can manage clinical notes
        doctors: { view: true },
        personnel: { view: false },
        appointments: { view: true, edit: true }, // Can view appointments and edit to add notes
        financial: { view: false },
        reports: { view: true },
        backup: { view: false },
        settings: { view: false },
    },
    'منشی': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: false },
        doctors: { view: true },
        personnel: { view: false },
        appointments: { view: true, add: true, edit: true, delete: false },
        financial: { view: false },
        reports: { view: true }, // Enabled access to reports for secretary
        backup: { view: false },
        settings: { view: false },
    }
};

export const PATIENTS_DATA: Patient[] = [
  { id: '1', name: 'علی محمدی', nationalId: '1234567890', phone1: '09123456789', phone2: '02188888888', age: 39, gender: 'مرد', diagnosis: 'مشکلات قلبی', insuranceProviderId: '1', nextSessionPlan: 'بررسی نتایج آزمایش خون و تنظیم دوز دارو. جلسه بعدی روی تکنیک‌های مدیریت استرس تمرکز می‌کنیم.', referredById: '2', referralSource: 'وبسایت کلینیک', attachments: [] },
  { id: '2', name: 'زهرا رضایی', nationalId: '0987654321', phone1: '09129876543', age: 32, gender: 'زن', diagnosis: 'فارنژیت', insuranceProviderId: '2', referralSource: 'معرفی توسط بیمار دیگر', attachments: [] },
  { id: '3', name: 'حسین احمدی', nationalId: '1122334455', phone1: '09351234567', age: 46, gender: 'مرد', diagnosis: 'پسوریازیس', referredById: '1', attachments: [] },
  { id: '4', name: 'امیرعباس کریمی', nationalId: '2233445566', phone1: '09121112233', age: 34, gender: 'مرد', diagnosis: 'میگرن', insuranceProviderId: '3', referralSource: 'اینستاگرام', attachments: [] },
  { id: '5', name: 'نازنین موسوی', nationalId: '3344556677', phone1: '09124445566', age: 36, gender: 'زن', diagnosis: 'ریفلاکس معده', referredById: '4', attachments: [] },
  { id: '6', name: 'محمدطاها جعفری', nationalId: '4455667788', phone1: '09127778899', age: 23, gender: 'مرد', diagnosis: 'پارگی منیسک', insuranceProviderId: '1', attachments: [] },
  { id: '7', name: 'آوا قاسمی', nationalId: '5566778899', phone1: '09128889900', age: 29, gender: 'زن', diagnosis: 'افسردگی', insuranceProviderId: '4', referredById: '5', attachments: [] },
  { id: '8', name: 'ابوالفضل ابراهیمی', nationalId: '6677889900', phone1: '09129990011', age: 44, gender: 'مرد', diagnosis: 'چکاپ سالانه', attachments: [] },
  { id: '9', name: 'یسنا حیدری', nationalId: '7788990011', phone1: '09120001122', age: 26, gender: 'زن', diagnosis: 'خال پوستی', referredById: '7', attachments: [] },
  { id: '10', name: 'آراد مرادی', nationalId: '8899001122', phone1: '09121112233', age: 31, gender: 'مرد', diagnosis: 'کمردرد', insuranceProviderId: '2', attachments: [] },
];

export const DOCTORS_DATA: Doctor[] = [
  { id: '1', name: 'دکتر مریم کریمی', specialty: 'متخصص قلب', education: 'فوق تخصص قلب و عروق از دانشگاه علوم پزشکی تهران', phone: '09101112233', photoUrl: 'https://picsum.photos/seed/doc1/200', officeHours: 'شنبه تا چهارشنبه، ۹ صبح تا ۵ عصر', ratePerHour: 450000, participationRate: 25, referralParticipationRate: 35 },
  { id: '2', name: 'دکتر رضا قاسمی', specialty: 'متخصص اطفال', education: 'دانشگاه علوم پزشکی شهید بهشتی', phone: '09104445566', photoUrl: 'https://picsum.photos/seed/doc2/200', officeHours: 'یکشنبه و سه‌شنبه، ۱۰ صبح تا ۶ عصر', ratePerHour: 300000, participationRate: 20, referralParticipationRate: 30 },
  { id: '3', name: 'دکتر سارا نوری', specialty: 'متخصص پوست', education: 'بورد تخصصی پوست، مو و زیبایی', phone: '09107778899', photoUrl: 'https://picsum.photos/seed/doc3/200', officeHours: 'روزهای زوج، ۴ عصر تا ۸ شب', ratePerHour: 500000, participationRate: 30, referralParticipationRate: 40 },
  { id: '4', name: 'دکتر آرین فتحی', specialty: 'مغز و اعصاب', phone: '09101234567', photoUrl: 'https://picsum.photos/seed/doc4/200', officeHours: 'شنبه و دوشنبه، ۹ صبح تا ۱ ظهر', ratePerHour: 600000, participationRate: 35, referralParticipationRate: 45 },
  { id: '5', name: 'دکتر نگین رستگار', specialty: 'گوارش و کبد', education: 'دانشگاه علوم پزشکی اصفهان', phone: '09102345678', photoUrl: 'https://picsum.photos/seed/doc5/200', officeHours: 'سه‌شنبه‌ها، ۱۰ صبح تا ۴ عصر', ratePerHour: 480000, participationRate: 28, referralParticipationRate: 38 },
  { id: '6', name: 'دکتر کیانوش زند', specialty: 'ارتوپدی', phone: '09103456789', photoUrl: 'https://picsum.photos/seed/doc6/200', officeHours: 'چهارشنبه‌ها، ۳ عصر تا ۷ شب', ratePerHour: 400000, participationRate: 22, referralParticipationRate: 32 },
  { id: '7', name: 'دکتر الهام جعفری', specialty: 'روانپزشک', education: 'متخصص اعصاب و روان - روان‌درمانگر', phone: '09104567890', photoUrl: 'https://picsum.photos/seed/doc7/200', officeHours: 'روزهای فرد، ۹ صبح تا ۵ عصر', ratePerHour: 550000, participationRate: 40, referralParticipationRate: 50 },
  { id: '8', name: 'دکتر برنا میلانی', specialty: 'گوش و حلق و بینی', phone: '09105678901', photoUrl: 'https://picsum.photos/seed/doc8/200', officeHours: 'شنبه و چهارشنبه، ۲ ظهر تا ۶ عصر', ratePerHour: 350000, participationRate: 20, referralParticipationRate: 25 },
  { id: '9', name: 'دکتر گلناز حکیمی', specialty: 'زنان و زایمان', phone: '09106789012', photoUrl: 'https://picsum.photos/seed/doc9/200', officeHours: 'روزهای زوج، ۱۰ صبح تا ۲ ظهر', ratePerHour: 420000, participationRate: 25, referralParticipationRate: 35 },
  { id: '10', name: 'دکتر آرش کمالی', specialty: 'اورولوژی', phone: '09107890123', photoUrl: 'https://picsum.photos/seed/doc10/200', officeHours: 'دوشنبه‌ها، ۴ عصر تا ۸ شب', ratePerHour: 470000, participationRate: 30, referralParticipationRate: 40 }
];

export const PERSONNEL_DATA: Personnel[] = [
    { id: '1', name: 'شیما محمدی', nationalId: '1112223334', phone: '09121112233', role: 'منشی', employmentDate: '2022-01-15', age: 29, photoUrl: 'https://picsum.photos/seed/staff1/200', username: 'secretary', password: '12345' },
    { id: '2', name: 'کامران تهرانی', nationalId: '4445556667', phone: '09367778899', role: 'مدیر', employmentDate: '2021-06-01', age: 36, photoUrl: 'https://picsum.photos/seed/staff2/200', username: 'manager', password: '12345' },
    { id: '3', name: 'دکتر الهام جعفری', nationalId: '7778889990', phone: '09104567890', role: 'پزشک', employmentDate: '2023-02-01', age: 39, username: 'doctor', password: '12345' },
    { id: '4', name: 'آقای حسابی', nationalId: '1231231231', phone: '09123214567', role: 'حسابدار', employmentDate: '2022-09-20', age: 34, username: 'accountant', password: '12345' },
    { id: '5', name: 'دکتر آرین فتحی', nationalId: '5556667778', phone: '09101234567', role: 'پزشک', employmentDate: '2023-03-01', age: 42, username: 'doctor_fathi', password: '12345' },
    { id: '6', name: 'دکتر رضا قاسمی', nationalId: '8889990001', phone: '09104445566', role: 'پزشک', employmentDate: '2023-04-01', age: 45, username: 'doctor_ghasemi', password: '12345' },
];

const formatDate = (date: Date) => date.toISOString().split('T')[0];

const generateAppointments = (): Appointment[] => {
  const appointments: Appointment[] = [];
  const patientIds = PATIENTS_DATA.map(p => p.id);
  const doctorIds = DOCTORS_DATA.map(d => d.id);
  const durations = ['30', '45', '60'];
  const paymentMethods: Array<'نقد' | 'کارت به کارت' | 'پوز'> = ['نقد', 'کارت به کارت', 'پوز'];
  const cancellationReasons = ['عدم حضور بیمار', 'درخواست بیمار', 'مشکل شخصی پزشک'];
  
  let appointmentIdCounter = 100; // Increased counter to avoid collision with static ones
  const occupiedSlots = new Set<string>();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let i = -90; i <= 90; i++) {
    const currentDate = new Date(today);
    currentDate.setDate(today.getDate() + i);
    const dateString = formatDate(currentDate);
    const appointmentsPerDay = Math.floor(Math.random() * 15) + 5; // Increased appointments per day

    for (let j = 0; j < appointmentsPerDay; j++) {
      const doctorId = doctorIds[Math.floor(Math.random() * doctorIds.length)];
      const patientId = patientIds[Math.floor(Math.random() * patientIds.length)];
      
      const hour = Math.floor(Math.random() * 12) + 9; // 9 AM to 8 PM
      const minuteOptions = ['00', '15', '30', '45'];
      const minute = minuteOptions[Math.floor(Math.random() * minuteOptions.length)];
      const time = `${String(hour).padStart(2, '0')}:${minute}`;

      const slotKey = `${dateString}-${doctorId}-${time}`;
      if (occupiedSlots.has(slotKey)) continue;
      occupiedSlots.add(slotKey);

      const doctor = DOCTORS_DATA.find(d => d.id === doctorId);
      const sessionDuration = durations[Math.floor(Math.random() * durations.length)];
      const sessionFee = doctor ? Math.round((doctor.ratePerHour / 60) * parseInt(sessionDuration, 10)) : 0;
      
      const appointmentDate = new Date(`${dateString}T${time}`);
      let status: Appointment['status'] = 'Scheduled';
      let paymentStatus: Appointment['paymentStatus'] = 'Unpaid';

      if (appointmentDate < today) {
          status = Math.random() > 0.1 ? 'Cancelled' : 'Completed';
          if (status === 'Completed') {
              paymentStatus = Math.random() > 0.2 ? 'Paid' : 'Unpaid';
          }
      }

      const newAppointment: Appointment = {
        id: String(appointmentIdCounter++),
        patientIds: [patientId],
        doctorId,
        date: dateString,
        time,
        sessionDuration,
        sessionFee,
        status,
        paymentStatus,
        paymentMethod: status === 'Completed' && paymentStatus === 'Paid' ? paymentMethods[Math.floor(Math.random() * paymentMethods.length)] : undefined,
        cancellationReason: status === 'Cancelled' ? cancellationReasons[Math.floor(Math.random() * cancellationReasons.length)] : undefined,
      };
      
      appointments.push(newAppointment);
    }
  }

  appointments.push({
    id: '98',
    patientIds: ['5'],
    doctorId: '7',
    date: formatDate(today),
    status: 'Waiting',
    paymentStatus: 'Unpaid',
    notes: 'نیاز فوری به مشاوره دارد.',
    dateAddedToWaitingList: formatDate(new Date(new Date().setDate(new Date().getDate() - 3))),
  });
  appointments.push({
    id: '99',
    patientIds: ['8'],
    doctorId: '4',
    date: formatDate(today),
    status: 'Waiting',
    paymentStatus: 'Unpaid',
    notes: 'درخواست برای اولین فرصت ممکن.',
    dateAddedToWaitingList: formatDate(new Date(new Date().setDate(new Date().getDate() - 5))),
  });
  
  return appointments;
};

export const APPOINTMENTS_DATA: Appointment[] = generateAppointments();

const generateTransactions = (appointments: Appointment[]): Transaction[] => {
    const transactions: Transaction[] = [];
    let transactionIdCounter = 1;

    appointments.forEach(app => {
        if (app.status === 'Completed' && app.paymentStatus === 'Paid' && app.sessionFee) {
            const patientNames = app.patientIds.map(id => PATIENTS_DATA.find(p => p.id === id)?.name || `بیمار #${id}`).join(', ');
            transactions.push({
                id: String(transactionIdCounter++),
                appointmentId: app.id,
                type: 'درآمد',
                description: `ویزیت بیمار: ${patientNames}`,
                amount: app.sessionFee,
                date: app.date,
                patientId: app.patientIds[0],
                doctorId: app.doctorId,
                paymentMethod: app.paymentMethod,
                accountDebited: app.paymentMethod === 'نقد' ? 'صندوق نقدی کلینیک' : (BANK_ACCOUNTS_DATA.find(b => b.name !== 'صندوق نقدی کلینیک')?.name || ''),
            });
        }
    });
    
    // Add some random expense transactions
    const today = new Date();
    for (let i = 0; i < 50; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - Math.floor(Math.random() * 180));
        const category = COST_CATEGORIES_DATA[Math.floor(Math.random() * COST_CATEGORIES_DATA.length)];
        const amount = Math.floor(Math.random() * 450000) + 50000;
        transactions.push({
            id: String(transactionIdCounter++),
            type: 'هزینه',
            description: `هزینه ${category.name}`,
            amount: amount,
            date: formatDate(date),
            costCategory: category.name,
            accountDebited: BANK_ACCOUNTS_DATA[Math.floor(Math.random() * BANK_ACCOUNTS_DATA.length)].name,
        });
    }

    return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const TRANSACTIONS_DATA: Transaction[] = generateTransactions(APPOINTMENTS_DATA);