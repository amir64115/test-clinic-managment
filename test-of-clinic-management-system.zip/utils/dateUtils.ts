// Declare the jalaali library loaded via script tag to resolve reference errors.
declare var jalaali: any;

const PERSIAN_MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

/**
 * Formats an ISO date string (YYYY-MM-DD) to a Jalali date string (YYYY/MM/DD).
 * Returns a placeholder if the date is invalid or the jalaali library is not loaded.
 */
export const formatToJalali = (isoDate?: string): string => {
  if (!isoDate) return '';
  // Check if jalaali library is available on the window object
  if (typeof jalaali === 'undefined' || !jalaali.toJalaali) {
    console.warn('jalaali-moment library is not available.');
    // Fallback for environments where the script might not have loaded
    try {
        const datePart = isoDate.split('T')[0];
        const [year, month, day] = datePart.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return date.toLocaleDateString('fa-IR');
    } catch {
        return isoDate;
    }
  }
  try {
    const datePart = isoDate.split('T')[0];
    const [year, month, day] = datePart.split('-').map(Number);
    // Create date in local timezone to avoid UTC interpretation of 'YYYY-MM-DD'
    const date = new Date(year, month - 1, day);
    
    if (isNaN(date.getTime())) return 'تاریخ نامعتبر';

    const jd = jalaali.toJalaali(date);
    return `${jd.jy}/${String(jd.jm).padStart(2, '0')}/${String(jd.jd).padStart(2, '0')}`;
  } catch (e) {
    console.error('Error formatting date to Jalali:', e);
    return 'تاریخ نامعتبر';
  }
};

/**
 * Checks if a given ISO date and optional time string is in the past.
 */
export const isPastDateTime = (isoDate: string, time?: string): boolean => {
  if (!isoDate) return true;
  try {
    const now = new Date();
    
    if (time) {
      // This is generally safe as 'YYYY-MM-DDTHH:MM' is parsed as local time by `new Date()`
      const targetDateTime = new Date(`${isoDate}T${time}`);
      if (isNaN(targetDateTime.getTime())) return true;
      return targetDateTime < now;
    } else {
      // new Date('YYYY-MM-DD') is parsed as UTC midnight, which can cause off-by-one day errors.
      // We parse it manually to treat it as a local date.
      const datePart = isoDate.split('T')[0];
      const [year, month, day] = datePart.split('-').map(Number);
      const targetDate = new Date(year, month - 1, day);
      
      if (isNaN(targetDate.getTime())) return true;
      
      const endOfTargetDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), 23, 59, 59, 999);
      
      return endOfTargetDay < now;
    }
  } catch (e) {
    return true; // Errors are considered "past" for safety
  }
};


/**
 * Returns the Persian name of a Jalali month (1-12).
 */
export const getJalaliMonthName = (month: number): string => {
  if (month >= 1 && month <= 12) {
    return PERSIAN_MONTH_NAMES[month - 1];
  }
  return '';
};


/**
 * Checks if two Date objects represent the same calendar day.
 */
export const isSameDay = (d1: Date, d2: Date): boolean => {
  if (!d1 || !d2 || !(d1 instanceof Date) || !(d2 instanceof Date)) return false;
  if (isNaN(d1.getTime()) || isNaN(d2.getTime())) return false;
  
  return d1.getFullYear() === d2.getFullYear() &&
         d1.getMonth() === d2.getMonth() &&
         d1.getDate() === d2.getDate();
};


/**
 * Returns an array of 7 Date objects representing the week (Sat-Fri) containing the given date.
 */
export const getWeekDays = (date: Date): Date[] => {
  const startOfWeek = new Date(date);
  // Persian week starts on Saturday. JS getDay() is Sun=0, Sat=6.
  const dayOfWeek = startOfWeek.getDay();
  // If today is Saturday (6), diff = 0. If Sunday (0), diff = 1. If Monday (1), diff = 2...
  const diff = dayOfWeek === 6 ? 0 : dayOfWeek + 1;
  startOfWeek.setDate(startOfWeek.getDate() - diff);
  
  const week = [];
  for (let i = 0; i < 7; i++) {
    const day = new Date(startOfWeek);
    day.setDate(startOfWeek.getDate() + i);
    week.push(day);
  }
  return week;
};


/**
 * Generates a matrix of days for a calendar month view, based on Jalali calendar.
 * The week starts on Saturday.
 */
export const getMonthMatrix = (date: Date): { date: Date, isCurrentMonth: boolean, jalaali: any }[][] => {
  if (typeof jalaali === 'undefined' || !jalaali.toJalaali) {
      console.warn('jalaali library is not available for getMonthMatrix.');
      return [];
  }
  const jd = jalaali.toJalaali(date);
  const { jy, jm } = jd;

  const firstDayOfMonthGregorianInfo = jalaali.toGregorian(jy, jm, 1);
  const firstDayOfMonthGregorian = new Date(firstDayOfMonthGregorianInfo.gy, firstDayOfMonthGregorianInfo.gm - 1, firstDayOfMonthGregorianInfo.gd);

  // Persian week starts on Saturday. Day mapping: Sat=0, Sun=1, ..., Fri=6
  const firstDayOfWeek = (firstDayOfMonthGregorian.getDay() + 1) % 7; 

  const matrix: { date: Date, isCurrentMonth: boolean, jalaali: any }[][] = [];
  
  let currentDay = new Date(firstDayOfMonthGregorian);
  currentDay.setDate(currentDay.getDate() - firstDayOfWeek);

  for (let i = 0; i < 6; i++) { // Max 6 weeks in a month view
    const week: { date: Date, isCurrentMonth: boolean, jalaali: any }[] = [];
    let hasCurrentMonthDay = false;
    for (let j = 0; j < 7; j++) {
      const currentJalaali = jalaali.toJalaali(currentDay);
      const isCurrentMonth = currentJalaali.jm === jm;
      if (isCurrentMonth) hasCurrentMonthDay = true;
      week.push({
        date: new Date(currentDay),
        isCurrentMonth: isCurrentMonth,
        jalaali: currentJalaali
      });
      currentDay.setDate(currentDay.getDate() + 1);
    }
    // Optimization to not show a 6th week if it only contains days from the next month
    if (i > 3 && !hasCurrentMonthDay) continue;
    matrix.push(week);
  }
  return matrix;
};