// Since we are loading xlsx via a script tag, we need to declare it for TypeScript
declare var XLSX: any;

export const exportToExcel = (data: any[], fileName: string): void => {
  if (typeof XLSX === 'undefined') {
    console.error("XLSX library is not loaded. Make sure the script tag is in index.html");
    alert("خطا در خروجی گرفتن اکسل. کتابخانه مورد نیاز بارگذاری نشده است.");
    return;
  }
  
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');
  
  // To trigger the download
  XLSX.writeFile(workbook, fileName);
};
