
/**
 * Normalizes a name string by removing common prefixes like "دکتر", "آقای", "خانم"
 * and trimming extra whitespace.
 */
export const normalizeName = (name: string | undefined | null): string => {
  if (!name) return '';
  // Remove "دکتر", "آقای", "خانم", "Dr." prefixes (case insensitive) and trim
  return name
    .replace(/^(دکتر|آقای|خانم|dr\.|dr)\s*/i, '')
    .trim()
    .replace(/\s+/g, ' ');
};

/**
 * Checks if two names are equivalent after normalization.
 * Useful for linking Personnel Usernames to Doctor Names even if one has a prefix and the other doesn't.
 */
export const areNamesEquivalent = (name1: string | undefined | null, name2: string | undefined | null): boolean => {
  if (!name1 || !name2) return false;
  
  // Direct strict equality check first for performance
  if (name1 === name2) return true;

  const n1 = normalizeName(name1);
  const n2 = normalizeName(name2);
  
  return n1 === n2;
};
