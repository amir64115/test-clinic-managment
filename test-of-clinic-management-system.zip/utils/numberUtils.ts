/**
 * Removes non-digit characters (except for a decimal point) from a string.
 * It also handles Persian digits.
 */
const cleanNumberString = (value: string): string => {
    if (typeof value !== 'string') return '';
    // Replace Persian digits with English digits, remove commas and other non-numeric chars
    return value
        .replace(/[\u0660-\u0669]/g, c => String.fromCharCode(c.charCodeAt(0) - 0x0660 + 0x0030)) // Persian to English digits
        .replace(/[\u06F0-\u06F9]/g, c => String.fromCharCode(c.charCodeAt(0) - 0x06F0 + 0x0030)) // Arabic to English digits
        .replace(/[^0-9.]/g, ''); 
};


/**
 * Formats a number or a string into a Persian locale string with thousand separators.
 * Handles empty strings, null, and undefined by returning an empty string.
 */
export const formatNumberWithCommas = (value: number | string | null | undefined): string => {
    if (value === null || value === undefined || value === '') {
        return '';
    }
    const cleaned = cleanNumberString(String(value));
    if (cleaned === '') return '';

    const num = Number(cleaned);
    if (isNaN(num)) {
        return '';
    }
    return num.toLocaleString('fa-IR', { useGrouping: true });
};

/**
 * Parses a formatted string (with Persian or English commas) into a number.
 * Returns 0 if the string is empty or invalid.
 */
export const parseFormattedNumber = (value: string): number => {
    if (!value) return 0;
    const cleaned = cleanNumberString(String(value));
    if (cleaned === '') return 0;
    
    const num = parseFloat(cleaned);
    return isNaN(num) ? 0 : num;
};
