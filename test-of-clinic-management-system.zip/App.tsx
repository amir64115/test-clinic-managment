import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import { db } from './db';
import type { Patient, Doctor, Appointment, Transaction, BankAccount, InsuranceProvider, Personnel, CostCategory, AppPermissions, AppView, TreatmentPlan, ClinicalRecord, PatientFileAttachment } from './types';
import { MenuIcon, LogoutIcon, ChevronDownIcon, PhonePlusIcon, KeyIcon } from './components/icons/Icons';
import { formatToJalali } from './utils/dateUtils';
import LoginPage from './pages/LoginPage';
import QuickIntake from './components/QuickVoiceMemo';
import { areNamesEquivalent } from './utils/textUtils';

// Import page components
import DashboardPage from './pages/DashboardPage';
import PatientManagementPage from './pages/PatientManagementPage';
import DoctorManagementPage from './pages/DoctorManagementPage';
import PersonnelManagementPage from './pages/PersonnelManagementPage';
import AppointmentManagementPage from './pages/AppointmentManagementPage';
import FinancialManagementPage from './pages/FinancialManagementPage';
import ReportsPage from './pages/ReportsPage';
import BackupRestorePage from './pages/BackupRestorePage';
import SettingsPage from './pages/SettingsPage';
import ChangePasswordModal from './components/ChangePasswordModal';

type View = AppView;

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<Personnel | null>(null);
  
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  
  const [isQuickIntakeModalOpen, setIsQuickIntakeModalOpen] = useState(false);
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false);
  
  const [patients, setPatientsState] = useState<Patient[]>([]);
  const [doctors, setDoctorsState] = useState<Doctor[]>([]);
  const [personnel, setPersonnelState] = useState<Personnel[]>([]);
  const [appointments, setAppointmentsState] = useState<Appointment[]>([]);
  const [transactions, setTransactionsState] = useState<Transaction[]>([]);
  const [bankAccounts, setBankAccountsState] = useState<BankAccount[]>([]);
  const [insuranceProviders, setInsuranceProvidersState] = useState<InsuranceProvider[]>([]);
  const [costCategories, setCostCategoriesState] = useState<CostCategory[]>([]);
  const [treatmentPlans, setTreatmentPlansState] = useState<TreatmentPlan[]>([]);
  const [clinicalRecords, setClinicalRecordsState] = useState<ClinicalRecord[]>([]);
  const [permissions, setPermissionsState] = useState<AppPermissions>({});

  // Initial data loading
  useEffect(() => {
    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            let [
                patientsData, doctorsData, personnelData, appointmentsData,
                transactionsData, bankAccountsData, insuranceProvidersData,
                costCategoriesData, permissionsData, treatmentPlansData, clinicalRecordsData
            ] = await Promise.all([
                db.getPatients(), db.getDoctors(), db.getPersonnel(),
                db.getAppointments(), db.getTransactions(), db.getBankAccounts(),
                db.getInsuranceProviders(), db.getCostCategories(), db.getPermissions(),
                db.getTreatmentPlans(), db.getClinicalRecords()
            ]);

            // Data migration for TreatmentService structure
            const migratedTreatmentPlans = treatmentPlansData.map(plan => {
                const needsMigration = plan.services.some(s => (s as any).sessionsPerWeek !== undefined);
                if (!needsMigration) return plan;
                
                return {
                    ...plan,
                    services: plan.services.map(service => {
                        const oldService = service as any;
                        if (oldService.sessionsPerWeek !== undefined && oldService.sessions === undefined) {
                            const { sessionsPerWeek, ...rest } = oldService;
                            return {
                                ...rest,
                                sessions: sessionsPerWeek,
                                frequency: 'هفتگی',
                            };
                        }
                        return service;
                    })
                };
            });
            
            if (JSON.stringify(migratedTreatmentPlans) !== JSON.stringify(treatmentPlansData)) {
                await db.saveTreatmentPlans(migratedTreatmentPlans);
            }
            
            // Migration for session notes from string to structured ClinicalRecord
            let finalClinicalRecords = clinicalRecordsData;
            const appointmentsWithOldNotes = appointmentsData.filter(app => (app as any).therapistNotes || (typeof (app as any).sessionNotes === 'object' && (app as any).sessionNotes !== null));
            let finalAppointmentsData = appointmentsData;

            if (appointmentsWithOldNotes.length > 0) {
                console.log("Running one-time migration for therapist notes to clinical records...");
                const newRecords: ClinicalRecord[] = [];
                const migratedAppointmentIds = new Set<number|string>();

                for (const app of appointmentsWithOldNotes) {
                    const oldApp = app as any;
                    if (finalClinicalRecords.some(r => r.appointmentId === oldApp.id)) continue;

                    const record: Omit<ClinicalRecord, 'id'> = {
                        appointmentId: oldApp.id,
                        patientId: oldApp.patientIds[0],
                        doctorId: oldApp.doctorId,
                        createdAt: oldApp.date,
                        updatedAt: oldApp.date,
                        note: '', 
                        messages: [],
                        subjective: '', objective: '', assessment: '', plan: ''
                    };
                    
                    let notesString = '';
                    if (typeof oldApp.sessionNotes === 'object' && oldApp.sessionNotes !== null) {
                        const notesArray = [
                            oldApp.sessionNotes.subjective ? `بیمار: ${oldApp.sessionNotes.subjective}` : '',
                            oldApp.sessionNotes.objective ? `مشاهده: ${oldApp.sessionNotes.objective}` : '',
                            oldApp.sessionNotes.assessment ? `ارزیابی: ${oldApp.sessionNotes.assessment}` : '',
                            oldApp.sessionNotes.plan ? `طرح بعدی: ${oldApp.sessionNotes.plan}` : '',
                        ];
                        notesString = notesArray.filter(Boolean).join('\n');
                    } else if (oldApp.therapistNotes) {
                        notesString = oldApp.therapistNotes;
                    } else if (oldApp.therapistAssessment) {
                        notesString = oldApp.therapistAssessment;
                    }
                    
                    record.note = notesString;

                    if (notesString) {
                        newRecords.push({ ...record, id: String(Date.now() + Math.random()) });
                        migratedAppointmentIds.add(app.id);
                    }
                }
                
                if (newRecords.length > 0) {
                    finalClinicalRecords = [...finalClinicalRecords, ...newRecords];
                    finalAppointmentsData = appointmentsData.map(app => {
                        if (migratedAppointmentIds.has(app.id)) {
                            const { therapistNotes, sessionNotes, therapistAssessment, ...rest } = app as any;
                            return rest;
                        }
                        return app;
                    });
                    await db.saveClinicalRecords(finalClinicalRecords);
                    await db.saveAppointments(finalAppointmentsData);
                    console.log(`${newRecords.length} clinical records created from old notes.`);
                }
            }

            // New Migration: Convert old managerComment to messages array
            let recordsModified = false;
            finalClinicalRecords = finalClinicalRecords.map(record => {
                if (record.managerComment && (!record.messages || record.messages.length === 0)) {
                    recordsModified = true;
                    return {
                        ...record,
                        messages: [{
                            id: String(Date.now() + Math.random()),
                            senderId: 'migration',
                            senderName: 'مدیر داخلی',
                            senderRole: 'مدیر داخلی',
                            text: record.managerComment,
                            createdAt: record.updatedAt || new Date().toISOString()
                        }],
                        managerComment: undefined // Clear old field
                    };
                } else if (!record.messages) {
                    // Initialize messages array if missing
                    return { ...record, messages: [] };
                }
                return record;
            });

            if (recordsModified) {
                await db.saveClinicalRecords(finalClinicalRecords);
                console.log("Migrated manager comments to chat messages.");
            }


            // Data migration for moving attachments from Appointments to Patients
            const needsAttachmentMigration = finalAppointmentsData.some(app => (app as any).attachments && (app as any).attachments.length > 0);
            let finalPatientsData = patientsData;

            if (needsAttachmentMigration) {
                console.log("Running one-time migration for patient attachments...");
                const patientAttachmentsMap = new Map<string, PatientFileAttachment[]>();

                for (const app of finalAppointmentsData as any[]) {
                    if (app.attachments && app.attachments.length > 0) {
                        for (const patientId of app.patientIds) {
                            if (!patientAttachmentsMap.has(patientId)) {
                                patientAttachmentsMap.set(patientId, []);
                            }
                            const existingAttachments = patientAttachmentsMap.get(patientId)!;
                            for (const attachment of app.attachments) {
                                if (!existingAttachments.some(a => a.dataUrl === attachment.dataUrl && a.fileName === attachment.fileName)) {
                                    existingAttachments.push(attachment);
                                }
                            }
                        }
                    }
                }

                finalPatientsData = patientsData.map(patient => {
                    if (patientAttachmentsMap.has(patient.id)) {
                        const newAttachments = patientAttachmentsMap.get(patient.id)!;
                        const combinedAttachments = [...(patient.attachments || []), ...newAttachments];
                        const uniqueAttachments = Array.from(new Map(combinedAttachments.map(item => [item.id, item])).values());
                        return { ...patient, attachments: uniqueAttachments };
                    }
                    return patient;
                });

                finalAppointmentsData = finalAppointmentsData.map(({ attachments, ...rest }: any) => rest);

                await db.savePatients(finalPatientsData);
                await db.saveAppointments(finalAppointmentsData);
                console.log("Attachment migration completed successfully.");
            }

            setPatientsState(finalPatientsData);
            setAppointmentsState(finalAppointmentsData);
            setDoctorsState(doctorsData);
            setPersonnelState(personnelData);
            setTransactionsState(transactionsData);
            setBankAccountsState(bankAccountsData);
            setInsuranceProvidersState(insuranceProvidersData);
            setCostCategoriesState(costCategoriesData);
            setPermissionsState(permissionsData);
            setTreatmentPlansState(migratedTreatmentPlans);
            setClinicalRecordsState(finalClinicalRecords);

        } catch (error) {
            console.error("Failed to load application data from backend", error);
        } finally {
            setIsLoading(false);
        }
    };

    loadInitialData();
  }, []);

  useEffect(() => {
    const checkAuth = () => {
      const storedUser = localStorage.getItem('currentUser');
      if (storedUser) {
        try {
          const user = JSON.parse(storedUser) as Personnel;
          setCurrentUser(user);
        } catch (e) {
          console.error("Failed to parse stored user", e);
          localStorage.removeItem('currentUser');
          setCurrentUser(null);
        }
      } else {
        setCurrentUser(null);
      }
    };

    if (!isLoading) {
      checkAuth();
    }
  }, [isLoading]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
            setIsUserMenuOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const checkAndSendScheduledReminders = () => {
        if (isLoading || typeof Notification === 'undefined' || Notification.permission !== 'granted') {
            return;
        }

        const now = new Date();
        let shouldUpdateState = false;

        const updatedAppointments = appointments.map(app => {
            if (app.reminderDateTime && !app.reminderSent && new Date(app.reminderDateTime) <= now) {
                const getPatientName = (id: string) => patients.find(p => p.id === id)?.name || `بیمار #${id}`;
                const getDoctorName = (id: string) => doctors.find(d => d.id === id)?.name || `پزشک #${id}`;
                const patientNames = app.patientIds.map(getPatientName).join('، ');
                const doctorName = getDoctorName(app.doctorId);

                const notificationTitle = 'یادآوری سفارشی نوبت';
                const notificationBody = `این یک یادآوری برای نوبت بیمار ${patientNames} با ${doctorName} در تاریخ ${formatToJalali(app.date)} ساعت ${app.time || ''} می‌باشد.`;

                new Notification(notificationTitle, {
                    body: notificationBody,
                    icon: '/logo192.png',
                    tag: `custom-reminder-${app.id}`
                });

                shouldUpdateState = true;
                return { ...app, reminderSent: true };
            }
            return app;
        });

        if (shouldUpdateState) {
            setAppointmentsState(updatedAppointments);
            db.saveAppointments(updatedAppointments);
        }
    };

    const intervalId = setInterval(checkAndSendScheduledReminders, 30 * 1000);
    return () => clearInterval(intervalId);

  }, [appointments, patients, doctors, isLoading]);

  const createCrudHandlers = <T extends {id: any}>(
    stateSetter: React.Dispatch<React.SetStateAction<T[]>>,
    dbMethods: { add: (item: Omit<T, 'id'>) => Promise<T>, update: (item: T) => Promise<T>, remove: (id: any) => Promise<void> },
    itemName: string
  ) => ({
      add: async (itemData: Omit<T, 'id'>): Promise<T> => {
        try {
          const newItem = await dbMethods.add(itemData);
          stateSetter(prev => [...prev, newItem]);
          return newItem;
        } catch (error) {
          console.error(`Failed to add ${itemName}:`, error);
          alert(`خطا در افزودن ${itemName}. لطفا دوباره تلاش کنید.`);
          throw error;
        }
      },
      update: async (item: T): Promise<T> => {
        try {
          const updatedItem = await dbMethods.update(item);
          stateSetter(prev => prev.map(i => i.id === updatedItem.id ? updatedItem : i));
          return updatedItem;
        } catch (error) {
          console.error(`Failed to update ${itemName}:`, error);
          alert(`خطا در ویرایش ${itemName}. لطفا دوباره تلاش کنید.`);
          throw error;
        }
      },
      remove: async (id: number | string): Promise<void> => {
        try {
          await dbMethods.remove(id);
          stateSetter(prev => prev.filter(i => i.id !== id));
        } catch (error) {
          console.error(`Failed to delete ${itemName}:`, error);
          alert(`خطا در حذف ${itemName}. لطفا دوباره تلاش کنید.`);
          throw error;
        }
      }
  });

  const { add: addPatient, update: updatePatient, remove: deletePatient } = createCrudHandlers(setPatientsState, { add: db.addPatient, update: db.updatePatient, remove: db.deletePatient }, 'بیمار');
  const { add: addDoctor, update: updateDoctor, remove: deleteDoctor } = createCrudHandlers(setDoctorsState, { add: db.addDoctor, update: db.updateDoctor, remove: db.deleteDoctor }, 'پزشک');
  const { add: addPersonnel, update: updatePersonnel, remove: deletePersonnel } = createCrudHandlers(setPersonnelState, { add: db.addPersonnel, update: db.updatePersonnel, remove: db.deletePersonnel }, 'پرسنل');
  const { add: addAppointment, update: updateAppointment, remove: deleteAppointment } = createCrudHandlers(setAppointmentsState, { add: db.addAppointment, update: db.updateAppointment, remove: db.deleteAppointment }, 'نوبت');
  const { add: addTransaction, update: updateTransaction, remove: deleteTransaction } = createCrudHandlers(setTransactionsState, { add: db.addTransaction, update: db.updateTransaction, remove: db.deleteTransaction }, 'تراکنش');
  const { add: addBankAccount, update: updateBankAccount, remove: deleteBankAccount } = createCrudHandlers(setBankAccountsState, { add: db.addBankAccount, update: db.updateBankAccount, remove: db.deleteBankAccount }, 'حساب بانکی');
  const { add: addInsuranceProvider, update: updateInsuranceProvider, remove: deleteInsuranceProvider } = createCrudHandlers(setInsuranceProvidersState, { add: db.addInsuranceProvider, update: db.updateInsuranceProvider, remove: db.deleteInsuranceProvider }, 'بیمه');
  const { add: addCostCategory, update: updateCostCategory, remove: deleteCostCategory } = createCrudHandlers(setCostCategoriesState, { add: db.addCostCategory, update: db.updateCostCategory, remove: db.deleteCostCategory }, 'سرفصل هزینه');
  const { add: addTreatmentPlan, update: updateTreatmentPlan, remove: deleteTreatmentPlan } = createCrudHandlers(setTreatmentPlansState, { add: db.addTreatmentPlan, update: db.updateTreatmentPlan, remove: db.deleteTreatmentPlan }, 'طرح درمان');
  const { add: addClinicalRecord, update: updateClinicalRecord, remove: deleteClinicalRecord } = createCrudHandlers(setClinicalRecordsState, { add: db.addClinicalRecord, update: db.updateClinicalRecord, remove: db.deleteClinicalRecord }, 'پرونده بالینی');

  const setPermissions = (updater: React.SetStateAction<AppPermissions>) => {
    setPermissionsState(prevState => {
      const newState = typeof updater === 'function' 
        ? (updater as (prevState: AppPermissions) => AppPermissions)(prevState) 
        : updater;
      db.savePermissions(newState);
      return newState;
    });
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setCurrentUser(null);
    setCurrentView('dashboard');
  };

  const handleLoginSuccess = (user: Personnel) => {
      setCurrentUser(user);
      setCurrentView('dashboard');
  };

  const renderView = () => {
    if (!currentUser) return null;

    const userRole = currentUser.role || '';
    const userPermissions = permissions[userRole] || {};

    if (!userPermissions[currentView]?.view) {
      // Admins should always be able to see settings, regardless of permissions object
      if (currentView === 'settings' && ['مدیر', 'مدیریت'].includes(userRole)) {
        // allow fallback
      } else {
        return (
          <div className="text-center p-8 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-bold text-red-600">عدم دسترسی</h2>
            <p className="text-gray-600 mt-2">شما اجازه مشاهده این بخش را ندارید.</p>
          </div>
        );
      }
    }
    
    const viewPermissions = userPermissions[currentView] || {};
    
    switch (currentView) {
      case 'patients': {
        // Filter patients AND appointments if the user is a doctor or therapist
        let viewablePatients = patients;
        let viewableAppointments = appointments;

        if (['پزشک', 'درمانگر'].includes(currentUser.role)) {
            const doctorRecord = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
            if (doctorRecord) {
                // 1. Identify patients treated by THIS doctor (via their appointments)
                const myAppointments = appointments.filter(app => app.doctorId === doctorRecord.id);
                const myPatientIds = new Set<string>();
                myAppointments.forEach(app => app.patientIds.forEach(id => myPatientIds.add(id)));

                // 2. Filter the patients list to only show these patients
                viewablePatients = patients.filter(p => myPatientIds.has(p.id));

                // 3. Filter appointments to include ALL appointments for these specific patients
                // (This allows seeing history from other docs for shared patients, requested by user)
                viewableAppointments = appointments.filter(app => 
                    app.patientIds.some(id => myPatientIds.has(id))
                );
            } else {
                viewablePatients = [];
                viewableAppointments = [];
            }
        }

        return <PatientManagementPage 
            patients={viewablePatients}
            setPatients={setPatientsState}
            addPatient={addPatient}
            updatePatient={updatePatient}
            deletePatient={deletePatient}
            doctors={doctors} 
            appointments={viewableAppointments} 
            setAppointments={setAppointmentsState}
            insuranceProviders={insuranceProviders} 
            permissions={viewPermissions}
            currentUser={currentUser}
            personnel={personnel}
            treatmentPlans={treatmentPlans}
            setTreatmentPlans={setTreatmentPlansState}
            addTreatmentPlan={addTreatmentPlan}
            updateTreatmentPlan={updateTreatmentPlan}
            clinicalRecords={clinicalRecords}
            addClinicalRecord={addClinicalRecord}
            updateClinicalRecord={updateClinicalRecord}
            transactions={transactions} // Passed transactions for financial ledger
          />;
      }
      case 'doctors':
        return <DoctorManagementPage 
            doctors={doctors} 
            addDoctor={addDoctor}
            updateDoctor={updateDoctor}
            deleteDoctor={deleteDoctor}
            permissions={viewPermissions} 
            currentUser={currentUser}
            appointments={appointments}
        />;
      case 'personnel':
        return <PersonnelManagementPage 
            personnel={personnel} 
            addPersonnel={addPersonnel}
            updatePersonnel={updatePersonnel}
            deletePersonnel={deletePersonnel}
            permissions={viewPermissions} 
            allPermissions={permissions}
        />;
      case 'appointments': {
        let viewableAppointments = appointments;
        let viewablePatients = patients;

        if (['پزشک', 'درمانگر'].includes(currentUser.role)) {
          const doctorRecord = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
          if (doctorRecord) {
            const doctorId = doctorRecord.id;
            // For Appointment Management, they only see their OWN schedule
            viewableAppointments = appointments.filter(app => app.doctorId === doctorId);
            
            // Calculate viewable patients based on appointment history for this doctor
            const patientIds = new Set(viewableAppointments.flatMap(app => app.patientIds));
            viewablePatients = patients.filter(p => patientIds.has(p.id));
          } else {
            viewableAppointments = [];
            viewablePatients = [];
          }
        }
        
        return <AppointmentManagementPage 
          appointments={viewableAppointments} 
          addAppointment={addAppointment}
          updateAppointment={updateAppointment}
          deleteAppointment={deleteAppointment}
          patients={viewablePatients} 
          doctors={doctors} 
          addTransaction={addTransaction} 
          updateTransaction={updateTransaction}
          deleteTransaction={deleteTransaction}
          transactions={transactions}
          bankAccounts={bankAccounts} 
          permissions={viewPermissions} 
          currentUser={currentUser}
          clinicalRecords={clinicalRecords}
          addClinicalRecord={addClinicalRecord}
          updateClinicalRecord={updateClinicalRecord}
          treatmentPlans={treatmentPlans}
          addTreatmentPlan={addTreatmentPlan}
          updateTreatmentPlan={updateTreatmentPlan}
          deleteTreatmentPlan={deleteTreatmentPlan}
          insuranceProviders={insuranceProviders}
          updatePatient={updatePatient}
        />;
      }
      case 'financial':
        return <FinancialManagementPage 
            transactions={transactions} 
            addTransaction={addTransaction}
            updateTransaction={updateTransaction}
            deleteTransaction={deleteTransaction}
            patients={patients} 
            doctors={doctors} 
            personnel={personnel} 
            bankAccounts={bankAccounts} 
            addBankAccount={addBankAccount}
            updateBankAccount={updateBankAccount}
            deleteBankAccount={deleteBankAccount}
            insuranceProviders={insuranceProviders} 
            addInsuranceProvider={addInsuranceProvider}
            updateInsuranceProvider={updateInsuranceProvider}
            deleteInsuranceProvider={deleteInsuranceProvider}
            costCategories={costCategories} 
            addCostCategory={addCostCategory}
            updateCostCategory={updateCostCategory}
            deleteCostCategory={deleteCostCategory}
            permissions={viewPermissions} 
        />;
      case 'reports': {
        let reportTransactions = transactions;
        let reportPatients = patients;
        let reportAppointments = appointments;

        if (['پزشک', 'درمانگر'].includes(currentUser.role)) {
          const doctorRecord = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
          if (doctorRecord) {
            const doctorId = doctorRecord.id;
            reportAppointments = appointments.filter(app => app.doctorId === doctorId);
            const doctorPatientIds = new Set<string>();
            reportAppointments.forEach(app => app.patientIds.forEach(pId => doctorPatientIds.add(pId)));
            reportPatients = patients.filter(p => p.id && doctorPatientIds.has(p.id));
            reportTransactions = transactions.filter(t => t.doctorId === doctorId);
          } else {
            reportTransactions = [];
            reportPatients = [];
            reportAppointments = [];
          }
        }
        
        return <ReportsPage 
          transactions={reportTransactions} 
          patients={reportPatients} 
          doctors={doctors} 
          appointments={reportAppointments} 
          insuranceProviders={insuranceProviders} 
          bankAccounts={bankAccounts} 
          personnel={personnel} 
          currentUser={currentUser}
          costCategories={costCategories}
        />;
      }
      case 'backup':
        return <BackupRestorePage permissions={viewPermissions} />;
      case 'settings':
        return <SettingsPage 
          permissions={permissions} 
          setPermissions={setPermissions} 
          personnel={personnel} 
          setPersonnel={setPersonnelState}
        />;
      case 'dashboard':
      default:
        return <DashboardPage 
            setCurrentView={setCurrentView} 
            currentUser={currentUser} 
            permissions={permissions} 
            personnel={personnel}
            treatmentPlans={treatmentPlans}
            updateTreatmentPlan={updateTreatmentPlan}
            patients={patients}
            doctors={doctors}
        />;
    }
  };

  if (isLoading) {
    return (
        <div className="flex h-screen w-screen items-center justify-center bg-gray-100">
            <div className="text-center">
                <svg className="mx-auto h-12 w-12 animate-spin text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <h2 className="mt-4 text-xl font-semibold text-gray-700">...در حال بارگذاری اطلاعات کلینیک</h2>
                <p className="text-gray-500">لطفا کمی صبر کنید</p>
            </div>
        </div>
    );
  }

  if (!currentUser) {
      return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }
  
  return (
    <div className="flex h-screen bg-gray-100 text-gray-800 overflow-hidden">
      <Sidebar 
        setCurrentView={setCurrentView} 
        currentView={currentView} 
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
        currentUser={currentUser}
        permissions={permissions}
      />
      <main className="flex-1 flex flex-col overflow-hidden h-full">
        <header className="bg-white shadow-sm p-4 flex justify-between items-center sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button className="lg:hidden text-gray-600 hover:text-gray-800 focus:outline-none" onClick={() => setIsSidebarOpen(true)}>
              <MenuIcon className="w-7 h-7" />
            </button>
            <h1 className="text-lg sm:text-2xl font-bold text-gray-700 truncate">سیستم مدیریت کلینیک</h1>
          </div>
          <div className="flex items-center gap-2">
            {currentUser && (currentUser.role === 'مدیر' || currentUser.role === 'منشی') && (
              <button
                onClick={() => setIsQuickIntakeModalOpen(true)}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors active:scale-95"
                title="ثبت تماس سریع بیمار"
              >
                <PhonePlusIcon className="w-6 h-6 text-gray-600" />
              </button>
            )}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setIsUserMenuOpen(prev => !prev)}
                className="flex items-center gap-2 p-1 rounded-full hover:bg-gray-100 transition-colors focus:outline-none active:scale-95"
              >
                {currentUser.photoUrl ? (
                  <img src={currentUser.photoUrl} alt={currentUser.name} className="w-9 h-9 rounded-full object-cover border-2 border-gray-200" />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold text-sm border-2 border-gray-200">
                    {currentUser.name.charAt(0)}
                  </div>
                )}
                <span className="font-semibold text-sm hidden sm:block text-gray-700">{currentUser.name}</span>
                <ChevronDownIcon className="w-4 h-4 text-gray-500 hidden sm:block mr-1" />
              </button>
              {isUserMenuOpen && (
                <div className="absolute left-0 mt-2 w-56 bg-white rounded-md shadow-lg py-1 z-50 border origin-top-left animate-fade-in-down">
                  <div className="px-4 py-3 border-b bg-gray-50 rounded-t-md">
                    <p className="font-semibold text-sm text-gray-800 truncate">{currentUser.name}</p>
                    <p className="text-xs text-gray-500">{currentUser.role}</p>
                  </div>
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      setIsChangePasswordModalOpen(true);
                    }}
                    className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-100 w-full text-right transition-colors"
                  >
                    <KeyIcon className="w-5 h-5 text-gray-500" />
                    تغییر رمز عبور
                  </button>
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      handleLogout();
                    }}
                    className="flex items-center gap-3 px-4 py-3 text-sm text-red-600 hover:bg-red-50 w-full text-right transition-colors border-t"
                  >
                    <LogoutIcon className="w-5 h-5" />
                    خروج
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto overflow-x-hidden bg-gray-100 safe-area-pb">
          {renderView()}
        </div>
      </main>

      <QuickIntake 
          isOpen={isQuickIntakeModalOpen}
          onClose={() => setIsQuickIntakeModalOpen(false)}
          onSave={async (phone, name, notes) => {
              let patient = patients.find(p => p.phone1 === phone.trim());
          
              if (!patient) {
                  const newPatientData: Omit<Patient, 'id'> = { name: name.trim(), phone1: phone.trim(), nationalId: phone.trim(), age: 30, gender: 'مرد' };
                  patient = await addPatient(newPatientData);
              }
          
              if (!patient) { throw new Error("Failed to find or create patient"); }
              
              const newAppointmentData: Omit<Appointment, 'id'> = {
                  patientIds: [patient.id],
                  doctorId: doctors.length > 0 ? doctors[0].id : '',
                  date: new Date().toISOString().split('T')[0],
                  status: 'Waiting',
                  paymentStatus: 'Unpaid',
                  notes,
                  dateAddedToWaitingList: new Date().toISOString().split('T')[0],
              };
              await createCrudHandlers(setAppointmentsState, { add: db.addAppointment, update: db.updateAppointment, remove: db.deleteAppointment }, 'نوبت').add(newAppointmentData);
          }}
      />
      {currentUser && (
        <ChangePasswordModal 
          isOpen={isChangePasswordModalOpen}
          onClose={() => setIsChangePasswordModalOpen(false)}
          currentUser={currentUser}
          updatePersonnel={updatePersonnel}
        />
      )}
    </div>
  );
};

export default App;