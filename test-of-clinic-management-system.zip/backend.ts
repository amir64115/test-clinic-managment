// SETUP INSTRUCTIONS (دستورالعمل راه‌اندازی)
// 1. Install necessary packages (نصب پکیج‌های مورد نیاز):
//    npm install express cors
//    npm install -D typescript ts-node @types/express @types/cors
//
// 2. Make sure this file is in the root of your project, next to `src`, `package.json`, etc.
//    (اطمینان حاصل کنید که این فایل در ریشه پروژه شما قرار دارد)
//
// 3. Run the server (اجرای سرور):
//    npx ts-node backend.ts
//
// 4. The server will be running at http://localhost:3001
//    (سرور روی آدرس http://localhost:3001 اجرا خواهد شد)
//
// 5. To use this backend, you need to modify your `db.ts` file in the frontend
//    to make API calls to these endpoints instead of using localStorage.
//    (برای استفاده از این بک‌اند، فایل db.ts را در فرانت‌اند تغییر دهید تا به این اندپوینت‌ها درخواست شبکه ارسال کند)

import express from 'express';
import cors from 'cors';

// Import data types and initial data from your project files
import type { 
    Patient, Doctor, Appointment, Transaction, BankAccount, 
    InsuranceProvider, Personnel, CostCategory, AppPermissions, 
    TreatmentPlan, ClinicalRecord 
} from './types';
import { 
    PATIENTS_DATA, DOCTORS_DATA, APPOINTMENTS_DATA, TRANSACTIONS_DATA, 
    BANK_ACCOUNTS_DATA, INSURANCE_PROVIDERS_DATA, PERSONNEL_DATA, 
    COST_CATEGORIES_DATA, DEFAULT_PERMISSIONS, TREATMENT_PLANS_DATA, 
    CLINICAL_RECORDS_DATA 
} from './constants';


// Initialize Express app
const app = express();
const port = 3001;

// Middleware setup
app.use(cors()); // Enable Cross-Origin Resource Sharing
// FIX: The "No overload matches this call" error indicates a TypeScript type resolution issue with app.use(). Explicitly providing the root path '/' resolves this overload ambiguity.
app.use('/', express.json({ limit: '50mb' })); // To parse JSON bodies and increase payload limit for base64 images
app.use('/', express.urlencoded({ extended: true, limit: '50mb' })); // To parse URL-encoded bodies

// In-memory database, initialized with data from constants
// این یک پایگاه داده موقت در حافظه است. با هر بار ری‌استارت سرور، اطلاعات به حالت اولیه بازنشانی می‌شود.
const db = {
    patients: [...PATIENTS_DATA],
    doctors: [...DOCTORS_DATA],
    personnel: [...PERSONNEL_DATA],
    appointments: [...APPOINTMENTS_DATA],
    transactions: [...TRANSACTIONS_DATA],
    bankAccounts: [...BANK_ACCOUNTS_DATA],
    insuranceProviders: [...INSURANCE_PROVIDERS_DATA],
    costCategories: [...COST_CATEGORIES_DATA],
    permissions: JSON.parse(JSON.stringify(DEFAULT_PERMISSIONS)), // Deep copy for permissions object
    treatmentPlans: [...TREATMENT_PLANS_DATA],
    clinicalRecords: [...CLINICAL_RECORDS_DATA],
};

type DbKey = keyof typeof db;

// ----- Generic CRUD Endpoints -----

// Helper function to find an item by ID (supports string and number IDs)
const findItemById = (collection: any[], id: string | number) => {
    return collection.find(item => String(item.id) === String(id));
};

const createCrudEndpoints = <T extends { id: string | number }>(resource: Exclude<DbKey, 'permissions'>) => {
    // GET all
    app.get(`/api/${resource}`, (req, res) => {
        // @ts-ignore
        res.json(db[resource]);
    });

    // GET by ID
    app.get(`/api/${resource}/:id`, (req, res) => {
        // @ts-ignore
        const item = findItemById(db[resource], req.params.id);
        if (item) {
            res.json(item);
        } else {
            res.status(404).json({ message: `${resource} item not found` });
        }
    });

    // POST (create new)
    app.post(`/api/${resource}`, (req, res) => {
        const newItem = { ...req.body, id: String(Date.now() + Math.random()) };
        // @ts-ignore
        db[resource].push(newItem);
        res.status(201).json(newItem);
    });

    // PUT (update by ID)
    app.put(`/api/${resource}/:id`, (req, res) => {
        // @ts-ignore
        const index = db[resource].findIndex(item => String(item.id) === req.params.id);
        if (index !== -1) {
            // @ts-ignore
            db[resource][index] = { ...db[resource][index], ...req.body };
            // @ts-ignore
            res.json(db[resource][index]);
        } else {
            res.status(404).json({ message: `${resource} item not found` });
        }
    });

    // DELETE by ID
    app.delete(`/api/${resource}/:id`, (req, res) => {
        // @ts-ignore
        const initialLength = db[resource].length;
        // @ts-ignore
        db[resource] = db[resource].filter(item => String(item.id) !== req.params.id);
        // @ts-ignore
        if (db[resource].length < initialLength) {
            res.status(204).send();
        } else {
            res.status(404).json({ message: `${resource} item not found` });
        }
    });
};

// Create routes for all array-based resources
createCrudEndpoints<Patient>('patients');
createCrudEndpoints<Doctor>('doctors');
createCrudEndpoints<Personnel>('personnel');
createCrudEndpoints<Appointment>('appointments');
createCrudEndpoints<Transaction>('transactions');
createCrudEndpoints<BankAccount>('bankAccounts');
createCrudEndpoints<InsuranceProvider>('insuranceProviders');
createCrudEndpoints<CostCategory>('costCategories');
createCrudEndpoints<TreatmentPlan>('treatmentPlans');
createCrudEndpoints<ClinicalRecord>('clinicalRecords');


// Special routes for permissions (it's an object, not an array)
app.get('/api/permissions', (req, res) => {
    res.json(db.permissions);
});

app.post('/api/permissions', (req, res) => {
    const data = req.body;
    if (typeof data === 'object' && data !== null && !Array.isArray(data)) {
        db.permissions = data;
        res.status(200).send('Permissions saved successfully.');
    } else {
        res.status(400).send('Invalid data format for permissions. Expected an object.');
    }
});


// Login endpoint
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ ok: false, message: 'Username and password are required.' });
  }

  const user = (db.personnel as Personnel[]).find(p => p.username === username);

  if (user && user.password === password) {
    const { password, ...userWithoutPassword } = user;
    res.json({ ok: true, user: userWithoutPassword });
  } else {
    res.status(401).json({ ok: false, message: 'Invalid credentials' });
  }
});

// Backup/Restore
app.get('/api/all', (req, res) => {
    res.json(db);
});

app.post('/api/all', (req, res) => {
    const data = req.body;
    Object.keys(db).forEach(key => {
        if (data[key]) {
            // @ts-ignore
            db[key] = data[key];
        }
    });
    res.status(200).send('Data restored successfully.');
});

// Root endpoint
app.get('/', (req, res) => {
    res.send('Clinic Management Backend is running!');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
