
import type { Patient, Doctor, Appointment, Transaction, BankAccount, InsuranceProvider, Personnel, CostCategory, AppPermissions, TreatmentPlan, ClinicalRecord } from './types';
import {
  PATIENTS_DATA, DOCTORS_DATA, APPOINTMENTS_DATA, TRANSACTIONS_DATA,
  BANK_ACCOUNTS_DATA, INSURANCE_PROVIDERS_DATA, PERSONNEL_DATA,
  COST_CATEGORIES_DATA, DEFAULT_PERMISSIONS, TREATMENT_PLANS_DATA,
  CLINICAL_RECORDS_DATA
} from './constants';

// Helper to get data from localStorage or fallback to initial data
const getCollection = <T>(key: string, initialData: T[]): T[] => {
  try {
    const item = localStorage.getItem(key);
    if (item) {
      return JSON.parse(item);
    } else {
      // If not in localStorage, save the initial data and return it
      localStorage.setItem(key, JSON.stringify(initialData));
      return initialData;
    }
  } catch (error) {
    console.error(`Error reading ${key} from localStorage`, error);
    // On error, fallback to initial data
    return initialData;
  }
};

// Helper to save data to localStorage
const saveCollection = <T>(key: string, data: T[]): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving ${key} to localStorage`, error);
  }
};

// Generic CRUD helpers for localStorage
const addItem = <T>(key: string, initialData: T[], item: Omit<T, 'id'>): Promise<T> => {
  return new Promise((resolve) => {
    const collection = getCollection(key, initialData);
    const newItem = { ...item, id: String(Date.now() + Math.random()) } as T;
    const newCollection = [...collection, newItem];
    saveCollection(key, newCollection);
    resolve(newItem);
  });
};

const updateItem = <T extends { id: any }>(key: string, initialData: T[], item: T): Promise<T> => {
  return new Promise((resolve, reject) => {
    const collection = getCollection(key, initialData);
    const index = collection.findIndex(i => i.id === item.id);
    if (index > -1) {
      const newCollection = [...collection];
      newCollection[index] = item;
      saveCollection(key, newCollection);
      resolve(item);
    } else {
      reject(new Error(`${key} item with id ${item.id} not found.`));
    }
  });
};

const deleteItem = <T extends { id: any }>(key: string, initialData: T[], id: number | string): Promise<void> => {
  return new Promise((resolve) => {
    const collection = getCollection(key, initialData);
    const newCollection = collection.filter(item => item.id !== id);
    saveCollection(key, newCollection);
    resolve();
  });
};

export const db = {
  // Patients
  getPatients: (): Promise<Patient[]> => Promise.resolve(getCollection('patients', PATIENTS_DATA)),
  addPatient: (patient: Omit<Patient, 'id'>): Promise<Patient> => addItem('patients', PATIENTS_DATA, patient),
  updatePatient: (patient: Patient): Promise<Patient> => updateItem('patients', PATIENTS_DATA, patient),
  deletePatient: (id: number | string): Promise<void> => deleteItem('patients', PATIENTS_DATA, id),
  savePatients: (patients: Patient[]): Promise<void> => { saveCollection('patients', patients); return Promise.resolve(); },

  // Doctors
  getDoctors: (): Promise<Doctor[]> => Promise.resolve(getCollection('doctors', DOCTORS_DATA)),
  addDoctor: (doctor: Omit<Doctor, 'id'>): Promise<Doctor> => addItem('doctors', DOCTORS_DATA, doctor),
  updateDoctor: (doctor: Doctor): Promise<Doctor> => updateItem('doctors', DOCTORS_DATA, doctor),
  deleteDoctor: (id: number | string): Promise<void> => deleteItem('doctors', DOCTORS_DATA, id),

  // Personnel
  getPersonnel: (): Promise<Personnel[]> => Promise.resolve(getCollection('personnel', PERSONNEL_DATA)),
  addPersonnel: (person: Omit<Personnel, 'id'>): Promise<Personnel> => addItem('personnel', PERSONNEL_DATA, person),
  updatePersonnel: (person: Personnel): Promise<Personnel> => updateItem('personnel', PERSONNEL_DATA, person),
  deletePersonnel: (id: number | string): Promise<void> => deleteItem('personnel', PERSONNEL_DATA, id),

  // Appointments
  getAppointments: (): Promise<Appointment[]> => Promise.resolve(getCollection('appointments', APPOINTMENTS_DATA)),
  addAppointment: (appointment: Omit<Appointment, 'id'>): Promise<Appointment> => addItem('appointments', APPOINTMENTS_DATA, appointment),
  updateAppointment: (appointment: Appointment): Promise<Appointment> => updateItem('appointments', APPOINTMENTS_DATA, appointment),
  deleteAppointment: (id: number | string): Promise<void> => deleteItem('appointments', APPOINTMENTS_DATA, id),
  saveAppointments: (appointments: Appointment[]): Promise<void> => { saveCollection('appointments', appointments); return Promise.resolve(); },

  // Transactions
  getTransactions: (): Promise<Transaction[]> => Promise.resolve(getCollection('transactions', TRANSACTIONS_DATA)),
  addTransaction: (transaction: Omit<Transaction, 'id'>): Promise<Transaction> => addItem('transactions', TRANSACTIONS_DATA, transaction),
  updateTransaction: (transaction: Transaction): Promise<Transaction> => updateItem('transactions', TRANSACTIONS_DATA, transaction),
  deleteTransaction: (id: number | string): Promise<void> => deleteItem('transactions', TRANSACTIONS_DATA, id),

  // InsuranceProviders
  getInsuranceProviders: (): Promise<InsuranceProvider[]> => Promise.resolve(getCollection('insuranceProviders', INSURANCE_PROVIDERS_DATA)),
  addInsuranceProvider: (provider: Omit<InsuranceProvider, 'id'>): Promise<InsuranceProvider> => addItem('insuranceProviders', INSURANCE_PROVIDERS_DATA, provider),
  updateInsuranceProvider: (provider: InsuranceProvider): Promise<InsuranceProvider> => updateItem('insuranceProviders', INSURANCE_PROVIDERS_DATA, provider),
  deleteInsuranceProvider: (id: number | string): Promise<void> => deleteItem('insuranceProviders', INSURANCE_PROVIDERS_DATA, id),

  // BankAccounts
  getBankAccounts: (): Promise<BankAccount[]> => Promise.resolve(getCollection('bankAccounts', BANK_ACCOUNTS_DATA)),
  addBankAccount: (account: Omit<BankAccount, 'id'>): Promise<BankAccount> => addItem('bankAccounts', BANK_ACCOUNTS_DATA, account),
  updateBankAccount: (account: BankAccount): Promise<BankAccount> => updateItem('bankAccounts', BANK_ACCOUNTS_DATA, account),
  deleteBankAccount: (id: number | string): Promise<void> => deleteItem('bankAccounts', BANK_ACCOUNTS_DATA, id),

  // CostCategories
  getCostCategories: (): Promise<CostCategory[]> => Promise.resolve(getCollection('costCategories', COST_CATEGORIES_DATA)),
  addCostCategory: (category: Omit<CostCategory, 'id'>): Promise<CostCategory> => addItem('costCategories', COST_CATEGORIES_DATA, category),
  updateCostCategory: (category: CostCategory): Promise<CostCategory> => updateItem('costCategories', COST_CATEGORIES_DATA, category),
  deleteCostCategory: (id: number | string): Promise<void> => deleteItem('costCategories', COST_CATEGORIES_DATA, id),
  
  // TreatmentPlans
  getTreatmentPlans: (): Promise<TreatmentPlan[]> => Promise.resolve(getCollection('treatmentPlans', TREATMENT_PLANS_DATA)),
  addTreatmentPlan: (plan: Omit<TreatmentPlan, 'id'>): Promise<TreatmentPlan> => addItem('treatmentPlans', TREATMENT_PLANS_DATA, plan),
  updateTreatmentPlan: (plan: TreatmentPlan): Promise<TreatmentPlan> => updateItem('treatmentPlans', TREATMENT_PLANS_DATA, plan),
  deleteTreatmentPlan: (id: number | string): Promise<void> => deleteItem('treatmentPlans', TREATMENT_PLANS_DATA, id),
  saveTreatmentPlans: (plans: TreatmentPlan[]): Promise<void> => { saveCollection('treatmentPlans', plans); return Promise.resolve(); },

  // ClinicalRecords
  getClinicalRecords: (): Promise<ClinicalRecord[]> => Promise.resolve(getCollection('clinicalRecords', CLINICAL_RECORDS_DATA)),
  addClinicalRecord: (record: Omit<ClinicalRecord, 'id'>): Promise<ClinicalRecord> => addItem('clinicalRecords', CLINICAL_RECORDS_DATA, record),
  updateClinicalRecord: (record: ClinicalRecord): Promise<ClinicalRecord> => updateItem('clinicalRecords', CLINICAL_RECORDS_DATA, record),
  deleteClinicalRecord: (id: number | string): Promise<void> => deleteItem('clinicalRecords', CLINICAL_RECORDS_DATA, id),
  saveClinicalRecords: (records: ClinicalRecord[]): Promise<void> => { saveCollection('clinicalRecords', records); return Promise.resolve(); },

  // Permissions
  getPermissions: (): Promise<AppPermissions> => {
    // Permissions are stored as a single object in an array to use the generic helper
    return Promise.resolve(getCollection('permissions', [DEFAULT_PERMISSIONS])[0] || DEFAULT_PERMISSIONS);
  },
  savePermissions: (perms: AppPermissions): Promise<void> => {
    saveCollection('permissions', [perms]);
    return Promise.resolve();
  },

  // Backup/Restore helpers
  saveAllData: (data: any): Promise<void> => {
    Object.keys(data).forEach(key => {
      if (data[key]) {
        localStorage.setItem(key, JSON.stringify(data[key]));
      }
    });
    return Promise.resolve();
  },
  getAllData: (): Promise<any> => {
    const allData: { [key: string]: any } = {};
    const keys = [
      'patients', 'doctors', 'personnel', 'appointments', 'transactions',
      'insuranceProviders', 'bankAccounts', 'costCategories', 'permissions',
      'treatmentPlans', 'clinicalRecords'
    ];
    keys.forEach(key => {
      const item = localStorage.getItem(key);
      if (item) {
        allData[key] = JSON.parse(item);
      }
    });
    return Promise.resolve(allData);
  },
};
