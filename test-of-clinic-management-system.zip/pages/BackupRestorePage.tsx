
import React, { useState, useRef } from 'react';
import type { PermissionSet } from '../types';

interface BackupRestorePageProps {
  permissions: PermissionSet;
}

const LOCAL_STORAGE_KEYS = [
    'patients', 'doctors', 'personnel', 'appointments', 'transactions',
    'insuranceProviders', 'bankAccounts', 'costCategories', 
    'permissions', 'treatmentPlans', 'clinicalRecords'
];

const BackupRestorePage: React.FC<BackupRestorePageProps> = ({ permissions }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState({ message: '', type: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleBackup = () => {
    setIsLoading(true);
    setFeedback({ message: '', type: '' });
    try {
      const backupData: { [key: string]: any } = {};
      LOCAL_STORAGE_KEYS.forEach(key => {
        const item = localStorage.getItem(key);
        if (item) {
          backupData[key] = JSON.parse(item);
        }
      });

      const jsonString = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const date = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `clinic-backup-${date}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setFeedback({ message: 'پشتیبان‌گیری با موفقیت انجام شد.', type: 'success' });
    } catch (error) {
      console.error('Backup failed:', error);
      setFeedback({ message: 'خطا در فرآیند پشتیبان‌گیری. لطفا کنسول را بررسی کنید.', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestoreClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!window.confirm('آیا مطمئن هستید؟ با بازیابی اطلاعات، تمام داده‌های فعلی شما بازنویسی خواهد شد. این عمل غیرقابل بازگشت است.')) {
      if(event.target) event.target.value = '';
      return;
    }

    setIsLoading(true);
    setFeedback({ message: '', type: '' });
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text !== 'string') {
          throw new Error('File content is not readable text.');
        }
        const restoredData = JSON.parse(text);

        let validKeys = 0;
        LOCAL_STORAGE_KEYS.forEach(key => {
          if (restoredData[key]) {
            localStorage.setItem(key, JSON.stringify(restoredData[key]));
            validKeys++;
          }
        });
        
        if (validKeys === 0) {
            throw new Error('فایل پشتیبان معتبر نیست یا خالی است.');
        }

        setFeedback({ message: 'بازیابی اطلاعات با موفقیت انجام شد. لطفا صفحه را برای اعمال تغییرات رفرش کنید.', type: 'success' });
        alert('بازیابی اطلاعات با موفقیت انجام شد. برنامه مجددا راه‌اندازی می‌شود.');
        window.location.reload();

      } catch (error) {
        console.error('Restore failed:', error);
        const errorMessage = error instanceof Error ? error.message : 'خطای ناشناخته در پردازش فایل.';
        setFeedback({ message: `خطا در بازیابی اطلاعات: ${errorMessage}`, type: 'error' });
      } finally {
        setIsLoading(false);
        if(event.target) event.target.value = '';
      }
    };
    reader.onerror = () => {
        setFeedback({ message: 'خطا در خواندن فایل.', type: 'error' });
        setIsLoading(false);
        if(event.target) event.target.value = '';
    };
    reader.readAsText(file);
  };


  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">پشتیبان‌گیری و بازیابی اطلاعات</h2>
      
      {feedback.message && (
        <div className={`p-4 mb-6 rounded-lg ${feedback.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
          {feedback.message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl shadow-md border">
          <h3 className="text-xl font-bold mb-3">پشتیبان‌گیری</h3>
          <p className="text-gray-600 mb-6 text-sm leading-relaxed">
            از تمام اطلاعات کلینیک (بیماران، نوبت‌ها، تراکنش‌ها و...) یک فایل پشتیبان با فرمت JSON تهیه کنید. این فایل را در مکانی امن نگهداری کنید تا در صورت نیاز بتوانید اطلاعات را بازیابی کنید.
          </p>
          <button
            onClick={handleBackup}
            disabled={isLoading || !permissions.view}
            className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:shadow-outline transition disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {isLoading ? 'در حال پردازش...' : 'شروع پشتیبان‌گیری و دانلود فایل'}
          </button>
           {!permissions.view && <p className="text-xs text-red-600 mt-2 text-center">شما دسترسی لازم برای پشتیبان‌گیری را ندارید.</p>}
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md border">
          <h3 className="text-xl font-bold mb-3">بازیابی اطلاعات</h3>
          <p className="text-gray-600 mb-6 text-sm leading-relaxed">
            <strong className="text-red-600">هشدار:</strong> این عمل تمام اطلاعات فعلی سیستم را حذف و اطلاعات موجود در فایل پشتیبان را جایگزین می‌کند. این فرآیند غیرقابل بازگشت است.
          </p>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json"
            className="hidden"
            disabled={isLoading || !permissions.add}
          />
          <button
            onClick={handleRestoreClick}
            disabled={isLoading || !permissions.add}
            className="w-full bg-orange-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-orange-600 focus:outline-none focus:shadow-outline transition disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {isLoading ? 'در حال بازیابی...' : 'انتخاب فایل و شروع بازیابی'}
          </button>
           {!permissions.add && <p className="text-xs text-red-600 mt-2 text-center">شما دسترسی لازم برای بازیابی اطلاعات را ندارید.</p>}
        </div>
      </div>
    </div>
  );
};

export default BackupRestorePage;
