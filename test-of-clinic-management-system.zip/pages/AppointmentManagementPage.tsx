
import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { Appointment, Patient, Doctor, Transaction, BankAccount, PermissionSet, Personnel, ClinicalRecord, TreatmentPlan, InsuranceProvider, SuggestedService } from '../types';
import { 
    CalendarMonthIcon, CalendarWeekIcon, CalendarDayIcon, ClipboardListIcon, ListViewIcon, 
    TrashIcon, EditIcon, JalaliDatePicker, ClockIcon, ChevronLeftIcon, ChevronRightIcon, 
    ClipboardCopyIcon, PlusIcon, DocumentReportIcon, UploadIcon, TrendingDownIcon, TrendingUpIcon
} from '../components/icons/Icons';
import { AppointmentCalendarView } from '../components/AppointmentCalendarView';
import { formatToJalali, isPastDateTime } from '../utils/dateUtils';
import { formatNumberWithCommas, parseFormattedNumber } from '../utils/numberUtils';
import { areNamesEquivalent } from '../utils/textUtils';
import VoiceEnabledTextarea from '../components/VoiceEnabledTextarea';

// Helper for Jalali Library
declare var jalaali: any;

// Helper definitions
const DOCTOR_COLOR_PALETTE_DAY = [
  { bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-400', hoverBg: 'hover:bg-blue-100' },
  { bg: 'bg-green-50', text: 'text-green-800', border: 'border-green-400', hoverBg: 'hover:bg-green-100' },
  { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-400', hoverBg: 'hover:bg-purple-100' },
  { bg: 'bg-yellow-50', text: 'text-yellow-800', border: 'border-yellow-400', hoverBg: 'hover:bg-yellow-100' },
  { bg: 'bg-pink-50', text: 'text-pink-800', border: 'border-pink-400', hoverBg: 'hover:bg-pink-100' },
  { bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-400', hoverBg: 'hover:bg-indigo-100' },
  { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-400', hoverBg: 'hover:bg-red-100' },
  { bg: 'bg-teal-50', text: 'text-teal-800', border: 'border-teal-400', hoverBg: 'hover:bg-teal-100' },
];

// Generate unique color based on Doctor ID hash
const getDoctorColorClasses = (doctorId: string) => {
  if (!doctorId) return DOCTOR_COLOR_PALETTE_DAY[0];
  
  let hash = 0;
  for (let i = 0; i < doctorId.length; i++) {
    hash = doctorId.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  const index = Math.abs(hash) % DOCTOR_COLOR_PALETTE_DAY.length;
  return DOCTOR_COLOR_PALETTE_DAY[index];
};

const toLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const emptyAppointment: Omit<Appointment, 'id'> = {
  patientIds: [],
  doctorId: '',
  date: new Date().toISOString().split('T')[0],
  time: '09:00',
  sessionDuration: '45',
  sessionFee: 0,
  status: 'Scheduled',
  paymentStatus: 'Unpaid',
  cancellationReason: '',
  notes: '',
  suggestedDoctorIds: [],
  suggestedServices: [],
};

const getStatusLabel = (status: Appointment['status']) => {
    switch(status) {
        case 'Scheduled': return { text: 'زمان‌بندی شده', className: 'bg-blue-100 text-blue-800' };
        case 'Completed': return { text: 'تکمیل شده', className: 'bg-green-100 text-green-800' };
        case 'Cancelled': return { text: 'لغو شده', className: 'bg-red-100 text-red-800' };
        case 'Waiting': return { text: 'در انتظار', className: 'bg-yellow-100 text-yellow-800' };
        default: return { text: status, className: 'bg-gray-100 text-gray-800' };
    }
};

interface SessionPayment {
    id: string;
    amount: string;
    method: 'نقد' | 'کارت به کارت' | 'پوز';
    accountId: string;
    patientId: string; // Added to track which patient made the payment
}

interface CustomTimePickerProps {
  value: string; // HH:MM format
  onChange: (value: string) => void;
  required?: boolean;
  disabled?: boolean;
}

const CustomTimePicker: React.FC<CustomTimePickerProps> = ({ value, onChange, required, disabled }) => {
    const [hour, minute] = useMemo(() => {
        return value && value.includes(':') ? value.split(':') : ['09', '00'];
    }, [value]);

    const handleTimeChange = (part: 'hour' | 'minute', val: string) => {
        const newTime = part === 'hour' ? `${val}:${minute}` : `${hour}:${val}`;
        onChange(newTime);
    };
    
    const hours = useMemo(() => Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0')), []);
    const minutes = useMemo(() => ['00', '15', '30', '45'], []);

    return (
        <div className="flex items-center gap-2" dir="ltr">
            <select
                value={hour}
                onChange={(e) => handleTimeChange('hour', e.target.value)}
                className="w-full p-2.5 border rounded-lg bg-white text-center disabled:bg-gray-200 disabled:cursor-not-allowed"
                required={required}
                disabled={disabled}
            >
                {hours.map(h => <option key={h} value={h}>{Number(h).toLocaleString('fa-IR')}</option>)}
            </select>
            <span className="font-bold text-gray-500">:</span>
            <select
                value={minute}
                onChange={(e) => handleTimeChange('minute', e.target.value)}
                className="w-full p-2.5 border rounded-lg bg-white text-center disabled:bg-gray-200 disabled:cursor-not-allowed"
                required={required}
                disabled={disabled}
            >
                {minutes.map(m => <option key={m} value={m}>{Number(m).toLocaleString('fa-IR')}</option>)}
            </select>
        </div>
    );
};

interface AppointmentManagementPageProps {
  appointments: Appointment[];
  addAppointment: (appointment: Omit<Appointment, 'id'>) => Promise<Appointment>;
  updateAppointment: (appointment: Appointment) => Promise<Appointment>;
  deleteAppointment: (id: string) => Promise<void>;
  patients: Patient[];
  doctors: Doctor[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction>;
  updateTransaction: (transaction: Transaction) => Promise<Transaction>;
  deleteTransaction: (id: string) => Promise<void>;
  transactions: Transaction[];
  bankAccounts: BankAccount[];
  permissions: PermissionSet;
  currentUser: Personnel;
  clinicalRecords: ClinicalRecord[];
  addClinicalRecord: (record: Omit<ClinicalRecord, 'id'>) => Promise<ClinicalRecord>;
  updateClinicalRecord: (record: ClinicalRecord) => Promise<ClinicalRecord>;
  treatmentPlans: TreatmentPlan[];
  updateTreatmentPlan: (plan: TreatmentPlan) => Promise<TreatmentPlan>;
  addTreatmentPlan: (plan: Omit<TreatmentPlan, 'id'>) => Promise<TreatmentPlan>;
  deleteTreatmentPlan: (id: string) => Promise<void>;
  insuranceProviders: InsuranceProvider[];
  updatePatient: (patient: Patient) => Promise<Patient>;
}

const AppointmentManagementPage: React.FC<AppointmentManagementPageProps> = ({
  appointments,
  addAppointment,
  updateAppointment,
  deleteAppointment,
  patients,
  doctors,
  addTransaction,
  updateTransaction,
  deleteTransaction,
  transactions,
  bankAccounts,
  permissions,
  currentUser,
  clinicalRecords,
  addClinicalRecord,
  updateClinicalRecord,
  treatmentPlans,
  updateTreatmentPlan,
  insuranceProviders,
  updatePatient,
}) => {
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day' | 'list' | 'waiting'>('day');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<Appointment, 'id'>>(emptyAppointment);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [currentDay, setCurrentDay] = useState(new Date());
  const [autoCalculatedFee, setAutoCalculatedFee] = useState(0);
  const [patientHistoricalBalance, setPatientHistoricalBalance] = useState(0);
  const [sessionTotalCostOverride, setSessionTotalCostOverride] = useState<number | null>(null);
  const [showOnlyDoctorsWithAppointments, setShowOnlyDoctorsWithAppointments] = useState(true);
  const [applyInsurance, setApplyInsurance] = useState(true);

  // Sorting State
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' }>({ key: 'date', direction: 'desc' });

  const [patientSearch, setPatientSearch] = useState('');
  const [isPatientDropdownOpen, setIsPatientDropdownOpen] = useState(false);
  const patientSearchRef = useRef<HTMLDivElement>(null);
  
  const [isCustomReminderEnabled, setIsCustomReminderEnabled] = useState(false);
  const [reminderDate, setReminderDate] = useState('');
  const [reminderTime, setReminderTime] = useState('');
  
  const [cancellationFeeData, setCancellationFeeData] = useState({
      charge: false,
      amount: '',
      paymentMethod: 'نقد' as 'نقد' | 'کارت به کارت' | 'پوز',
      accountDebited: '',
  });

  const [draggingAppointmentId, setDraggingAppointmentId] = useState<string | null>(null);
  const [dragOverSlot, setDragOverSlot] = useState<{ doctorId: string; time: string } | null>(null);

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingAppointment, setDeletingAppointment] = useState<Appointment | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  
  const [isCopyDayModalOpen, setIsCopyDayModalOpen] = useState(false);
  const [copyTargetDate, setCopyTargetDate] = useState('');
  const [selectedDoctorIdsForCopy, setSelectedDoctorIdsForCopy] = useState<string[]>([]);
  
  const [sessionPayments, setSessionPayments] = useState<SessionPayment[]>([]);
  
  const [currentRecord, setCurrentRecord] = useState<Omit<ClinicalRecord, 'id'> | null>(null);

  const isAdmin = useMemo(() => ['مدیر', 'مدیریت'].includes(currentUser.role), [currentUser.role]);
  const canEditHistory = useMemo(() => ['مدیر', 'مدیریت', 'منشی'].includes(currentUser.role), [currentUser.role]);
  const isMedicalStaff = ['پزشک', 'درمانگر'].includes(currentUser.role);
  
  const isLockedForEditing = !!editingAppointment && (['Completed', 'Cancelled'].includes(editingAppointment.status)) && !canEditHistory;
  const canEditClinicalRecord = isMedicalStaff || isAdmin;
  const canDelete = useMemo(() => permissions.delete || currentUser.role === 'مدیریت', [permissions.delete, currentUser.role]);

  const currentDoctorId = useMemo(() => {
      if (!isMedicalStaff) return null;
      const doc = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
      return doc ? doc.id : null;
  }, [isMedicalStaff, doctors, currentUser.name]);

  const filteredAppointments = useMemo(() => {
      if (isMedicalStaff) {
          if (currentDoctorId) {
              return appointments.filter(app => app.doctorId === currentDoctorId);
          } else {
              return [];
          }
      }
      return appointments;
  }, [appointments, isMedicalStaff, currentDoctorId]);

  const getPatientName = (id: string) => patients.find(p => p.id === id)?.name || `بیمار #${id}`;
  const getDoctorName = (id: string) => doctors.find(d => d.id === id)?.name || `پزشک #${id}`;

  const getPatientNames = (ids: string[]): string => {
    if (!ids || ids.length === 0) return 'نامشخص';
    const patientNames = ids.map(id => patients.find(p => p.id === id)?.name || `بیمار #${id}`);
    return patientNames.join('، ');
  };

  const getDoctorFrequencyLabel = (appointment: Appointment, doctorId: string) => {
      const doctorName = doctors.find(d => d.id === doctorId)?.name || 'نامشخص';
      
      // 1. Check Appointment suggestedServices first (manual entry)
      if (appointment.suggestedServices) {
          const service = appointment.suggestedServices.find(s => s.doctorId === doctorId);
          if (service) {
              return `${doctorName} (x${service.count})`;
          }
      }

      // 2. Fallback to Treatment Plans if needed (or just show name if manual entry is empty)
      const patientId = appointment.patientIds[0];
      if (!patientId) return doctorName;

      const activePlan = treatmentPlans.find(p => p.patientId === patientId && p.status === 'confirmed');
      if (!activePlan) return doctorName;

      const service = activePlan.services.find(s => s.therapistIds.includes(doctorId));
      if (service && service.sessions > 0) {
          return `${doctorName} (x${service.sessions})`;
      }
      
      return doctorName;
  };

  const availablePatients = useMemo(() => {
    return patients.filter(p => 
      p.name.toLowerCase().includes(patientSearch.toLowerCase()) && 
      !formData.patientIds.includes(p.id)
    );
  }, [patients, patientSearch, formData.patientIds]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (patientSearchRef.current && !patientSearchRef.current.contains(event.target as Node)) {
            setIsPatientDropdownOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (!isModalOpen || formData.patientIds.length !== 1) {
        setPatientHistoricalBalance(0);
        return;
    }
    const patientId = formData.patientIds[0];
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    let balance = 0;
    const patientAppointments = filteredAppointments.filter(app => 
        app.patientIds.includes(patientId) && 
        app.status === 'Completed' && 
        (!editingAppointment || app.id !== editingAppointment.id)
    );

    patientAppointments.forEach(app => {
        const doctor = doctors.find(d => d.id === app.doctorId);
        const sessionCost = app.sessionFee || (doctor ? Math.round((doctor.ratePerHour / 60) * parseInt(app.sessionDuration || '0', 10)) : 0);
        let patientShare = sessionCost;
        if (app.applyInsurance !== false) {
            const insuranceProvider = insuranceProviders.find(i => i.id === patient.insuranceProviderId);
            if (insuranceProvider) {
                if (insuranceProvider.commissionType === 'percentage') {
                    const insuranceShare = Math.round(sessionCost * (insuranceProvider.commissionValue / 100));
                    patientShare -= insuranceShare;
                } else {
                    const insuranceShare = Math.min(sessionCost, insuranceProvider.commissionValue);
                    patientShare -= insuranceShare;
                }
            }
        }
        balance += patientShare;
    });
    
    const patientTransactions = transactions.filter(t => t.patientId === patientId);
    patientTransactions.forEach(t => {
        if (t.type === 'درآمد' && (!editingAppointment || t.appointmentId !== editingAppointment.id)) {
            balance -= t.amount;
        }
    });

    setPatientHistoricalBalance(balance);

  }, [isModalOpen, formData.patientIds, filteredAppointments, transactions, patients, doctors, insuranceProviders, editingAppointment]);

  useEffect(() => {
    if (editingAppointment || formData.patientIds.length !== 1) return;
    const patientId = formData.patientIds[0];
    const patientAppointments = filteredAppointments
        .filter(app => app.patientIds.includes(patientId))
        .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    if (patientAppointments.length === 0) return;
    let lastAppointment = patientAppointments.find(app => app.status === 'Completed') || patientAppointments[0];
    if (lastAppointment && lastAppointment.id !== editingAppointment?.id) {
       setFormData(prev => ({ ...prev, doctorId: lastAppointment.doctorId, sessionDuration: lastAppointment.sessionDuration || '45' }));
    }
  }, [formData.patientIds, filteredAppointments, editingAppointment]);

  useEffect(() => {
    if (isCustomReminderEnabled && !reminderDate) {
        setReminderDate(formData.date);
    }
  }, [isCustomReminderEnabled, formData.date, reminderDate]);
  
  const handleAddPatientToSelection = (patientId: string) => {
    setFormData(prev => ({...prev, patientIds: [...prev.patientIds, patientId]}));
    setPatientSearch('');
    setIsPatientDropdownOpen(false);
  };
  
  const handleRemovePatientFromSelection = (patientId: string) => {
    setFormData(prev => ({...prev, patientIds: prev.patientIds.filter(id => id !== patientId)}));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleDateChange = (name: string, date: string) => {
    setFormData(prev => ({ ...prev, [name]: date }));
  };
  
  const handleRecordChange = (field: keyof Omit<ClinicalRecord, 'id' | 'appointmentId' | 'patientId' | 'doctorId' | 'createdAt' | 'updatedAt'>, value: string) => {
    setCurrentRecord(prev => prev ? { ...prev, [field]: value, updatedAt: new Date().toISOString() } : null);
  };
  
  const handleSuggestedDoctorsChange = (doctorId: string) => {
      setFormData(prev => {
          const currentServices = prev.suggestedServices || [];
          const exists = currentServices.find(s => s.doctorId === doctorId);
          
          let newServices;
          if (exists) {
              // Remove
              newServices = currentServices.filter(s => s.doctorId !== doctorId);
          } else {
              // Add with default count 1
              newServices = [...currentServices, { doctorId, count: 1 }];
          }
          
          // Also sync the legacy simple ID array for backward compat/other views
          const newDoctorIds = newServices.map(s => s.doctorId);

          return { 
              ...prev, 
              suggestedServices: newServices,
              suggestedDoctorIds: newDoctorIds 
          };
      });
  };

  const handleSuggestedCountChange = (doctorId: string, newCount: number) => {
      setFormData(prev => {
          const currentServices = prev.suggestedServices || [];
          const newServices = currentServices.map(s => 
              s.doctorId === doctorId ? { ...s, count: newCount } : s
          );
          return { ...prev, suggestedServices: newServices };
      });
  };
  
  const handlePatientAttachmentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || formData.patientIds.length !== 1) return;
    
    const MAX_SIZE_KB = 5120; // 5MB
    if (file.size > MAX_SIZE_KB * 1024) {
      alert(`حجم فایل نباید بیشتر از ${MAX_SIZE_KB / 1024} مگابایت باشد.`);
      return;
    }

    const patientId = formData.patientIds[0];
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
        const newAttachment = {
            id: String(Date.now()),
            fileName: file.name,
            dataUrl: reader.result as string
        };
        const updatedPatient = {
            ...patient,
            attachments: [...(patient.attachments || []), newAttachment]
        };
        try {
            await updatePatient(updatedPatient);
            alert("فایل با موفقیت به پرونده بیمار ضمیمه شد.");
        } catch (error) {
            console.error("Failed to upload attachment from appointment modal:", error);
            alert("خطا در آپلود فایل.");
        }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  useEffect(() => {
    if(!isModalOpen) return;
    const doctor = doctors.find(d => d.id === formData.doctorId);
    if (doctor && formData.sessionDuration) {
      const fee = Math.round((doctor.ratePerHour / 60) * parseInt(formData.sessionDuration, 10));
      setAutoCalculatedFee(fee);
      if (sessionTotalCostOverride === null) {
          setFormData(prev => ({...prev, sessionFee: fee}));
      }
    } else {
        setAutoCalculatedFee(0);
         if (sessionTotalCostOverride === null) {
            setFormData(prev => ({...prev, sessionFee: 0}));
        }
    }
  }, [formData.doctorId, formData.sessionDuration, doctors, isModalOpen, sessionTotalCostOverride]);

    const handleAddPayment = () => {
        setSessionPayments(prev => [...prev, {
            id: String(Date.now()),
            amount: '',
            method: 'پوز',
            accountId: bankAccounts.find(b => b.name.includes('کارت') || b.name.includes('پوز'))?.id || bankAccounts[0]?.id || '',
            patientId: formData.patientIds.length > 0 ? formData.patientIds[0] : ''
        }]);
    };
    
    const handleRemovePayment = (id: string) => {
        setSessionPayments(prev => prev.filter(p => p.id !== id));
    };

    const handlePaymentChange = (id: string, field: keyof Omit<SessionPayment, 'id'>, value: string) => {
        setSessionPayments(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p));
    };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingAppointment(null);
    setFormData(emptyAppointment);
    setPatientSearch('');
    setIsCustomReminderEnabled(false);
    setReminderDate('');
    setReminderTime('');
    setCancellationFeeData({ charge: false, amount: '', paymentMethod: 'نقد', accountDebited: '' });
    setSessionTotalCostOverride(null);
    setSessionPayments([]);
    setApplyInsurance(true);
    setCurrentRecord(null);
  };
  
  const closeDeleteModal = () => {
      setIsDeleteModalOpen(false);
      setDeletingAppointment(null);
      setDeleteReason('');
  }

  const openAddModal = (date?: string, time?: string, doctorId?: string) => {
    setEditingAppointment(null);
    setFormData({
      ...emptyAppointment,
      date: date || toLocalDateString(new Date()),
      time: time || '10:00',
      doctorId: currentDoctorId || doctorId || (doctors.length > 0 ? doctors[0].id : '')
    });
    setIsCustomReminderEnabled(false);
    setReminderDate('');
    setReminderTime('');
    setCancellationFeeData({ charge: false, amount: '', paymentMethod: 'نقد', accountDebited: '' });
    setSessionTotalCostOverride(null);
    setSessionPayments([]);
    setApplyInsurance(true);
    setCurrentRecord(null);
    setIsModalOpen(true);
  };

  const openEditModal = (appointment: Appointment) => {
    setEditingAppointment(appointment);
    
    // Migration logic for editing legacy data that might only have suggestedDoctorIds
    let initialSuggestedServices = appointment.suggestedServices || [];
    if (initialSuggestedServices.length === 0 && appointment.suggestedDoctorIds && appointment.suggestedDoctorIds.length > 0) {
        initialSuggestedServices = appointment.suggestedDoctorIds.map(id => ({ doctorId: id, count: 1 }));
    }

    setFormData({ 
        ...appointment, 
        suggestedDoctorIds: appointment.suggestedDoctorIds || [],
        suggestedServices: initialSuggestedServices
    });
    setSessionTotalCostOverride(appointment.sessionFee || null);
    setApplyInsurance(appointment.applyInsurance !== false);

    const relatedTransactions = transactions.filter(t => t.appointmentId === appointment.id && t.type === 'درآمد');
    const paymentsFromTransactions = relatedTransactions.map(t => ({
        id: t.id,
        amount: String(t.amount),
        method: t.paymentMethod || 'پوز',
        accountId: bankAccounts.find(b => b.name === t.accountDebited)?.id || '',
        patientId: t.patientId || appointment.patientIds[0] || ''
    }));
    setSessionPayments(paymentsFromTransactions);
    
    if (canEditClinicalRecord && appointment.patientIds.length > 0) {
        const existingRecord = clinicalRecords.find(r => r.appointmentId === appointment.id);
        if (existingRecord) {
            setCurrentRecord({
                ...existingRecord,
                messages: existingRecord.messages || []
            });
        } else {
            setCurrentRecord({
                appointmentId: appointment.id,
                patientId: appointment.patientIds[0],
                doctorId: appointment.doctorId,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                note: '',
                messages: [],
                subjective: '', objective: '', assessment: '', plan: ''
            });
        }
    } else {
        setCurrentRecord(null);
    }
    
    if (appointment.reminderDateTime) {
        setIsCustomReminderEnabled(true);
        const [datePart, timePart] = appointment.reminderDateTime.split('T');
        setReminderDate(datePart);
        setReminderTime(timePart ? timePart.substring(0, 5) : '');
    } else {
        setIsCustomReminderEnabled(false);
        setReminderDate('');
        setReminderTime('');
    }
    setCancellationFeeData({
        charge: !!appointment.cancellationFee,
        amount: appointment.cancellationFee ? String(appointment.cancellationFee) : '',
        paymentMethod: 'نقد',
        accountDebited: ''
    });
    setIsModalOpen(true);
  };
  
  const requestNotificationPermission = async (): Promise<boolean> => {
    if (typeof Notification === 'undefined') {
        alert('مرورگر شما از یادآوری‌ها پشتیبانی نمی‌کند.');
        return false;
    }
    if (Notification.permission === 'granted') return true;
    if (Notification.permission === 'denied') {
        alert('ارسال یادآوری در مرورگر شما مسدود شده است. برای فعال‌سازی، لطفا به تنظیمات مرورگر خود مراجعه کرده و دسترسی لازم را به این سایت بدهید.');
        return false;
    }
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
        new Notification('یادآوری‌ها فعال شدند', { body: 'یادآوری‌های سفارشی برای شما نمایش داده خواهد شد.', icon: '/logo192.png' });
        return true;
    } else {
        alert('شما اجازه ارسال یادآوری را ندادید. برای استفاده از این قابلیت، لطفا از تنظیمات مرورگر خود اقدام کنید.');
        return false;
    }
  };

  const handleSaveAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (currentRecord) {
        const recordExists = clinicalRecords.some(r => r.appointmentId === currentRecord.appointmentId);
        const hasContent = Object.values(currentRecord).some(val => typeof val === 'string' && val.trim().length > 0);
        
        if (recordExists) {
            const existing = clinicalRecords.find(r => r.appointmentId === currentRecord.appointmentId);
            if (existing) {
                await updateClinicalRecord({ ...currentRecord, id: existing.id } as ClinicalRecord);
            }
        } else if (hasContent) {
            await addClinicalRecord(currentRecord);
        }
    }

    if (isLockedForEditing && !canEditClinicalRecord) {
        closeModal();
        return;
    }
    
    if (formData.patientIds.length === 0 || (!formData.doctorId && formData.status !== 'Waiting') || !formData.date) {
        alert('لطفا بیمار، پزشک و تاریخ نوبت را مشخص کنید.');
        return;
    }
    
    const totalPaidAmount = sessionPayments.reduce((sum, p) => sum + parseFormattedNumber(p.amount), 0);

    if (formData.status === 'Completed' && formData.paymentStatus === 'Paid' && sessionPayments.some(p => !p.amount || parseFormattedNumber(p.amount) <= 0)) {
        alert('لطفا برای تمام ردیف‌های پرداخت، مبلغ را به درستی وارد کنید.');
        return;
    }
     if (formData.status === 'Cancelled' && cancellationFeeData.charge && (!cancellationFeeData.amount || parseFormattedNumber(cancellationFeeData.amount) <= 0)) {
        alert('لطفا مبلغ جریمه کنسلی را وارد کنید.');
        return;
    }
    if (formData.status === 'Cancelled' && !formData.cancellationReason?.trim()) {
        alert('لطفا دلیل لغو نوبت را وارد کنید. این فیلد اجباری است.');
        return;
    }
    
    let customReminderData: Partial<Appointment> = {};
    if (isCustomReminderEnabled && reminderDate && reminderTime) {
        const permissionGranted = await requestNotificationPermission();
        if (!permissionGranted) {
            setIsCustomReminderEnabled(false);
        } else {
            const reminderDateTimeObj = new Date(`${reminderDate}T${reminderTime}`);
            if (reminderDateTimeObj < new Date()) {
                alert('زمان یادآوری نمی‌تواند در گذشته باشد.');
                return;
            }
            customReminderData = { reminderDateTime: `${reminderDate}T${reminderTime}:00`, reminderSent: false };
        }
    } else {
        customReminderData = { reminderDateTime: undefined, reminderSent: undefined };
    }
    
    const finalSessionFee = sessionTotalCostOverride ?? autoCalculatedFee;

    const finalAppointmentData: Omit<Appointment, 'id'> & { id?: string } = {
        ...(editingAppointment ? { ...formData, id: editingAppointment.id } : formData),
        sessionFee: finalSessionFee,
        ...customReminderData,
        cancellationFee: formData.status === 'Cancelled' && cancellationFeeData.charge ? parseFormattedNumber(cancellationFeeData.amount) : undefined,
        paymentMethod: undefined,
        applyInsurance: formData.status === 'Completed' ? applyInsurance : undefined,
    };

    try {
        let savedAppointment: Appointment;
        if (editingAppointment) {
            await updateAppointment(finalAppointmentData as Appointment);
            savedAppointment = finalAppointmentData as Appointment;
        } else {
            if (finalAppointmentData.status === 'Waiting') {
                finalAppointmentData.dateAddedToWaitingList = new Date().toISOString().split('T')[0];
            }
            savedAppointment = await addAppointment(finalAppointmentData);
        }
        
        if (!isLockedForEditing) {
            const existingTransactions = editingAppointment ? transactions.filter(t => t.appointmentId === editingAppointment.id && t.type === 'درآمد') : [];
            for (const t of existingTransactions) {
                await deleteTransaction(t.id);
            }

            if (finalAppointmentData.status === 'Completed' && finalAppointmentData.paymentStatus === 'Paid' && totalPaidAmount > 0) {
                for (const payment of sessionPayments) {
                    const amount = parseFormattedNumber(payment.amount);
                    if (amount > 0) {
                        const description = finalAppointmentData.patientIds.length > 1
                            ? `ویزیت بیمار: ${getPatientName(payment.patientId)} (جلسه گروهی)`
                            : `ویزیت بیمار: ${getPatientNames(finalAppointmentData.patientIds)}`;

                        const transactionData: Omit<Transaction, 'id'> = {
                            appointmentId: savedAppointment.id,
                            type: 'درآمد',
                            description: description,
                            amount: amount,
                            date: savedAppointment.date,
                            patientId: payment.patientId || savedAppointment.patientIds[0],
                            doctorId: savedAppointment.doctorId,
                            paymentMethod: payment.method,
                            accountDebited: bankAccounts.find(b => b.id === payment.accountId)?.name,
                        };
                        await addTransaction(transactionData);
                    }
                }
            }
            
            if (finalAppointmentData.status === 'Cancelled' && finalAppointmentData.cancellationFee && finalAppointmentData.cancellationFee > 0) {
                const cancellationTransaction: Omit<Transaction, 'id'> = {
                    appointmentId: savedAppointment.id,
                    type: 'درآمد',
                    description: `جریمه کنسلی: ${getPatientNames(savedAppointment.patientIds)}`,
                    amount: finalAppointmentData.cancellationFee,
                    date: new Date().toISOString().split('T')[0],
                    patientId: savedAppointment.patientIds[0],
                    doctorId: savedAppointment.doctorId,
                    accountDebited: bankAccounts.find(b => b.id === cancellationFeeData.accountDebited)?.name,
                    paymentMethod: cancellationFeeData.paymentMethod,
                };
                await addTransaction(cancellationTransaction);
            }
        }
        
        const patientIdsWithNewAppointment = finalAppointmentData.patientIds;
        if (patientIdsWithNewAppointment.length > 0 && finalAppointmentData.status !== 'Waiting') {
          const plansToUpdate = treatmentPlans.filter(plan => 
              plan.status === 'confirmed' && patientIdsWithNewAppointment.includes(plan.patientId)
          );
          for (const plan of plansToUpdate) {
              await updateTreatmentPlan({ ...plan, status: 'archived' });
          }
        }
        
        closeModal();

    } catch(error) {
        console.error("Failed to save appointment:", error);
        alert("خطا در ذخیره سازی نوبت. لطفا دوباره تلاش کنید.");
    }
  };

  const confirmDeleteAppointment = async (id: string) => {
    const appToDelete = appointments.find(a => a.id === id);
    if (!appToDelete) return;
    
    const relatedTransactions = transactions.filter(t => t.appointmentId === id);

    let confirmMessage = 'آیا از حذف این نوبت اطمینان دارید؟';
    if(relatedTransactions.length > 0) {
        confirmMessage += `\n\nهشدار: ${relatedTransactions.length} تراکنش مالی مرتبط با این نوبت وجود دارد. با حذف نوبت، این تراکنش‌ها نیز حذف خواهند شد.`;
    }

    if (appToDelete.status === 'Waiting') {
        setDeletingAppointment(appToDelete);
        setDeleteReason('');
        setIsDeleteModalOpen(true);
    } else {
        if (window.confirm(confirmMessage)) {
            try {
                for(const t of relatedTransactions) {
                    await deleteTransaction(t.id);
                }
                await deleteAppointment(id);
            } catch (error) {
                console.error('Failed to delete appointment and/or transaction:', error);
                alert('خطا در حذف نوبت.');
            }
        }
    }
  };
  
  const handleCopyAppointment = (appointment: Appointment) => {
      const { patientIds, doctorId, sessionDuration } = appointment;
      const copiedData = {
          ...emptyAppointment,
          patientIds,
          doctorId,
          sessionDuration,
          date: new Date().toISOString().split('T')[0],
          time: '10:00',
      };
      setEditingAppointment(null);
      setFormData(copiedData);
      setSessionTotalCostOverride(null);
      setSessionPayments([]);
      setIsModalOpen(true);
  };

  const handleConfirmRemoveFromWaitingList = async () => {
    if (!deletingAppointment || !deleteReason.trim()) {
        alert('لطفا دلیل حذف از لیست انتظار را وارد کنید.');
        return;
    }
    try {
        await updateAppointment({
            ...deletingAppointment,
            status: 'Cancelled',
            cancellationReason: deleteReason.trim()
        });
        closeDeleteModal();
    } catch(error) {
        console.error("Failed to cancel waiting list item:", error);
    }
  };
  
  const sortedAppointments = useMemo(() => 
    [...filteredAppointments].sort((a,b) => (new Date(b.date).getTime() - new Date(a.date).getTime()) || (b.time || '00:00').localeCompare(a.time || '00:00')), [filteredAppointments]);
    
  const listAppointments = useMemo(() => {
      let filtered = sortedAppointments;
      if (sortConfig.key) {
          filtered.sort((a, b) => {
              let aValue: any = '';
              let bValue: any = '';

              switch (sortConfig.key) {
                  case 'patient':
                      aValue = getPatientNames(a.patientIds);
                      bValue = getPatientNames(b.patientIds);
                      break;
                  case 'doctor':
                      aValue = getDoctorName(a.doctorId);
                      bValue = getDoctorName(b.doctorId);
                      break;
                  case 'date':
                      aValue = a.date + (a.time || '');
                      bValue = b.date + (b.time || '');
                      break;
                  case 'status':
                      aValue = a.status;
                      bValue = b.status;
                      break;
                  default:
                      return 0;
              }

              if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
              if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return filtered;
  }, [sortedAppointments, sortConfig, patients, doctors]);

  const waitingListAppointments = useMemo(() => sortedAppointments.filter(a => a.status === 'Waiting'), [sortedAppointments]);

  const renderSortIcon = (columnKey: string) => {
      if (sortConfig.key !== columnKey) return <div className="w-4 h-4 inline-block ml-1 opacity-20"><TrendingDownIcon className="w-4 h-4"/></div>;
      return sortConfig.direction === 'asc' 
        ? <div className="w-4 h-4 inline-block ml-1 text-blue-600"><TrendingUpIcon className="w-4 h-4"/></div> 
        : <div className="w-4 h-4 inline-block ml-1 text-blue-600"><TrendingDownIcon className="w-4 h-4"/></div>;
  };

  const requestSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const renderListView = () => (
    <div className="bg-white p-0 sm:p-4 rounded-lg shadow-none sm:shadow-md bg-transparent sm:bg-white">
        <div className="hidden md:block overflow-x-auto bg-white rounded-lg shadow-sm border">
            <table className="w-full text-right text-sm">
                <thead className="bg-gray-50 border-b">
                    <tr>
                        <th className="p-3 font-semibold cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('patient')}>بیمار {renderSortIcon('patient')}</th>
                        <th className="p-3 font-semibold cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('doctor')}>پزشک {renderSortIcon('doctor')}</th>
                        <th className="p-3 font-semibold cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('date')}>تاریخ و ساعت {renderSortIcon('date')}</th>
                        <th className="p-3 font-semibold cursor-pointer hover:bg-gray-100 select-none" onClick={() => requestSort('status')}>وضعیت {renderSortIcon('status')}</th>
                        <th className="p-3 font-semibold">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    {listAppointments.map(app => {
                        const isTimeLocked = isPastDateTime(app.date, app.time);
                        const canEdit = permissions.edit && (canEditHistory || (!isTimeLocked && !['Completed', 'Cancelled'].includes(app.status)));
                        const statusLabel = getStatusLabel(app.status);
                        const isFinished = ['Completed', 'Cancelled'].includes(app.status);

                        return (
                            <tr key={app.id} className={`border-b hover:bg-gray-50 ${isFinished ? 'bg-gray-100 text-gray-500' : ''}`}>
                                <td className={`p-3 ${isFinished ? 'text-gray-600' : 'text-gray-800'}`}>{getPatientNames(app.patientIds)}</td>
                                <td className={`p-3 ${isFinished ? 'text-gray-600' : 'text-gray-800'}`}>{getDoctorName(app.doctorId)}</td>
                                <td className={`p-3 ${isFinished ? 'text-gray-600' : 'text-gray-800'}`}>{formatToJalali(app.date)} - {app.time || 'نامشخص'}</td>
                                <td className="p-3">
                                    <span className={`px-2 py-1 rounded-full text-xs ${statusLabel.className}`}>
                                        {statusLabel.text}
                                    </span>
                                </td>
                                <td className="p-3 flex items-center space-x-2 space-x-reverse">
                                    {permissions.add && <button onClick={() => handleCopyAppointment(app)} className="text-gray-500 p-1 hover:text-blue-600" title="کپی کردن نوبت"><ClipboardCopyIcon className="w-6 h-6" /></button>}
                                    {permissions.edit && <button onClick={() => openEditModal(app)} disabled={!canEdit} className="text-gray-500 p-1 disabled:opacity-50 disabled:cursor-not-allowed hover:text-green-600" title="ویرایش"><EditIcon className="w-6 h-6"/></button>}
                                    {canDelete && <button onClick={() => confirmDeleteAppointment(app.id)} disabled={!canEdit && !isAdmin} className="text-gray-500 p-1 disabled:opacity-50 disabled:cursor-not-allowed hover:text-red-600" title="حذف"><TrashIcon className="w-6 h-6"/></button>}
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
        <div className="md:hidden space-y-4">
            {listAppointments.map(app => {
                 const isTimeLocked = isPastDateTime(app.date, app.time);
                 const canEdit = permissions.edit && (canEditHistory || (!isTimeLocked && !['Completed', 'Cancelled'].includes(app.status)));
                 const statusLabel = getStatusLabel(app.status);
                 const isFinished = ['Completed', 'Cancelled'].includes(app.status);
                return (
                    <div key={app.id} className={`p-4 rounded-xl shadow-sm border border-gray-100 active:scale-[0.99] transition-transform ${isFinished ? 'bg-gray-100' : 'bg-white'}`}>
                        <div className="flex justify-between items-start">
                            <div>
                                <p className={`font-bold ${isFinished ? 'text-gray-700' : 'text-gray-800'}`}>{getPatientNames(app.patientIds)}</p>
                                <p className={`text-sm font-medium mt-1 ${isFinished ? 'text-gray-600' : 'text-blue-600'}`}>{getDoctorName(app.doctorId)}</p>
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs ${statusLabel.className}`}>
                                {statusLabel.text}
                            </span>
                        </div>
                        <div className={`text-sm mt-2 pt-2 border-t border-gray-50 flex justify-between items-center ${isFinished ? 'text-gray-500' : 'text-gray-500'}`}>
                            <span>{formatToJalali(app.date)} - {app.time || 'نامشخص'}</span>
                            <div className="flex items-center gap-2">
                                {permissions.add && <button onClick={() => handleCopyAppointment(app)} className="text-gray-400 hover:text-blue-600 p-1.5 bg-gray-50 rounded-full"><ClipboardCopyIcon className="w-5 h-5" /></button>}
                                {permissions.edit && <button onClick={() => openEditModal(app)} disabled={!canEdit} className="text-gray-400 hover:text-green-600 p-1.5 bg-gray-50 rounded-full disabled:opacity-50"><EditIcon className="w-5 h-5"/></button>}
                                {canDelete && <button onClick={() => confirmDeleteAppointment(app.id)} disabled={!canEdit && !isAdmin} className="text-gray-400 hover:text-red-600 p-1.5 bg-gray-50 rounded-full disabled:opacity-50"><TrashIcon className="w-5 h-5"/></button>}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
        {listAppointments.length === 0 && <p className="text-center py-8 text-gray-500">نوبتی یافت نشد.</p>}
    </div>
  );

  const renderWaitingListView = () => (
    <div className="bg-white p-0 sm:p-4 rounded-lg shadow-none sm:shadow-md bg-transparent sm:bg-white">
        <div className="hidden md:block overflow-x-auto bg-white rounded-lg shadow-sm border">
            <table className="w-full text-right text-sm">
                <thead className="bg-gray-50 border-b">
                    <tr>
                        <th className="p-3 font-semibold">بیمار</th><th className="p-3 font-semibold">پزشک/درمانگر</th><th className="p-3 font-semibold">تاریخ ثبت</th>
                        <th className="p-3 font-semibold">یادداشت</th><th className="p-3 font-semibold">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    {waitingListAppointments.map(app => (
                        <tr key={app.id} className="border-b hover:bg-gray-50">
                            <td className="p-3">{getPatientNames(app.patientIds)}</td>
                            <td className="p-3">
                                {app.doctorId ? getDoctorName(app.doctorId) : (
                                    (app.suggestedServices && app.suggestedServices.length > 0) || (app.suggestedDoctorIds && app.suggestedDoctorIds.length > 0) ? (
                                        <div className="flex flex-wrap gap-1">
                                            {(app.suggestedServices || []).map(service => (
                                                <span key={service.doctorId} className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded-full whitespace-nowrap">
                                                    {getDoctorFrequencyLabel(app, service.doctorId)}
                                                </span>
                                            ))}
                                            {/* Legacy support: display IDs if services not present (though openEditModal migrates this) */}
                                            {(!app.suggestedServices || app.suggestedServices.length === 0) && app.suggestedDoctorIds?.map(id => (
                                                 <span key={id} className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded-full whitespace-nowrap">
                                                    {getDoctorFrequencyLabel(app, id)}
                                                </span>
                                            ))}
                                        </div>
                                    ) : <span className="text-gray-400">-</span>
                                )}
                            </td>
                            <td className="p-3">{app.dateAddedToWaitingList ? formatToJalali(app.dateAddedToWaitingList) : '-'}</td><td className="p-3">{app.notes}</td>
                            <td className="p-3 flex items-center space-x-2 space-x-reverse">
                                {permissions.edit && <button onClick={() => openEditModal(app)} className="text-gray-500 hover:text-green-600 p-1" title="زمان‌بندی نوبت"><EditIcon className="w-6 h-6"/></button>}
                                {canDelete && <button onClick={() => confirmDeleteAppointment(app.id)} className="text-gray-500 hover:text-red-600 p-1" title="حذف از لیست"><TrashIcon className="w-6 h-6"/></button>}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        <div className="md:hidden space-y-4">
            {waitingListAppointments.map(app => (
                <div key={app.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex justify-between">
                        <p className="font-bold text-gray-800">{getPatientNames(app.patientIds)}</p>
                        <span className="text-xs bg-yellow-50 text-yellow-700 px-2 py-1 rounded-md">لیست انتظار</span>
                    </div>
                    <div className="text-sm text-gray-500 mt-2 space-y-1">
                        <div className="flex flex-wrap gap-1">
                            <span>درمانگر پیشنهادی: </span>
                            {app.doctorId ? getDoctorName(app.doctorId) : (
                                (app.suggestedServices?.length || app.suggestedDoctorIds?.length) ? (
                                    <>
                                        {(app.suggestedServices || []).map(service => (
                                            <span key={service.doctorId} className="bg-blue-50 text-blue-700 text-xs px-1 rounded">
                                                {getDoctorFrequencyLabel(app, service.doctorId)}
                                            </span>
                                        ))}
                                        {(!app.suggestedServices || app.suggestedServices.length === 0) && app.suggestedDoctorIds?.map(id => (
                                            <span key={id} className="bg-blue-50 text-blue-700 text-xs px-1 rounded">
                                                {getDoctorFrequencyLabel(app, id)}
                                            </span>
                                        ))}
                                    </>
                                ) : 'نامشخص'
                            )}
                        </div>
                        <p>تاریخ ثبت: {app.dateAddedToWaitingList ? formatToJalali(app.dateAddedToWaitingList) : '-'}</p>
                        {app.notes && <p className="text-gray-700 mt-2 bg-gray-50 p-2 rounded text-xs italic">"{app.notes}"</p>}
                    </div>
                    <div className="mt-4 flex justify-end items-center gap-3">
                        {permissions.edit && <button onClick={() => openEditModal(app)} className="text-green-600 bg-green-50 px-3 py-1.5 rounded-lg text-sm font-medium" title="زمان‌بندی نوبت">زمان‌بندی</button>}
                        {canDelete && <button onClick={() => confirmDeleteAppointment(app.id)} className="text-red-600 bg-red-50 px-3 py-1.5 rounded-lg text-sm font-medium" title="حذف از لیست">حذف</button>}
                    </div>
                </div>
            ))}
        </div>
        {waitingListAppointments.length === 0 && <p className="text-center py-8 text-gray-500">موردی در لیست انتظار یافت نشد.</p>}
    </div>
  );
  
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, appointmentId: string) => {
    if (!permissions.edit) return;
    setDraggingAppointmentId(appointmentId);
    e.dataTransfer.setData('text/plain', String(appointmentId));
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragEnd = () => { setDraggingAppointmentId(null); setDragOverSlot(null); };
  const handleDragOver = (e: React.DragEvent<HTMLTableCellElement>) => e.preventDefault();
  const handleDragEnter = (e: React.DragEvent<HTMLTableCellElement>, doctorId: string, time: string) => { e.preventDefault(); if (permissions.edit && draggingAppointmentId) setDragOverSlot({ doctorId, time }); };
  const handleDragLeave = (e: React.DragEvent<HTMLTableCellElement>) => { e.preventDefault(); setDragOverSlot(null); };

  const handleDrop = async (e: React.DragEvent<HTMLTableCellElement>, targetDoctorId: string, targetTime: string) => {
    e.preventDefault();
    if (!permissions.edit || !draggingAppointmentId) return;
    const appointmentToMove = appointments.find(app => app.id === draggingAppointmentId);
    
    if (appointmentToMove) {
      // Allow move if it's scheduled OR if user has permission to edit history (Admin/Secretary)
      if (['Completed', 'Cancelled'].includes(appointmentToMove.status) && !canEditHistory) {
          alert('امکان جابجایی نوبت‌های تکمیل یا لغو شده وجود ندارد.');
      } else if (appointments.some(app => app.doctorId === targetDoctorId && app.time === targetTime && app.date === toLocalDateString(currentDay) && app.id !== draggingAppointmentId)) {
        alert('این جایگاه زمانی برای این پزشک قبلاً رزرو شده است.');
      } else {
        try {
            await updateAppointment({ ...appointmentToMove, doctorId: targetDoctorId, time: targetTime });
        } catch (error) {
            console.error("Failed to update appointment on drop:", error);
            alert("خطا در جابجایی نوبت.");
        }
      }
    }
    setDraggingAppointmentId(null);
    setDragOverSlot(null);
  };
  
  const doctorsOnCurrentDay = useMemo(() => {
    const sourceDate = toLocalDateString(currentDay);
    const doctorIdsOnDay = new Set(filteredAppointments.filter(app => app.date === sourceDate).map(app => app.doctorId));
    
    let availableDoctors = [...doctors];

    if (isMedicalStaff) {
        const myself = doctors.find(d => areNamesEquivalent(d.name, currentUser.name));
        if (myself) {
            availableDoctors = [myself];
        } else {
            availableDoctors = [];
        }
    }

    if (showOnlyDoctorsWithAppointments) {
      return availableDoctors.filter(doc => doctorIdsOnDay.has(doc.id)).sort((a,b) => a.name.localeCompare(b.name, 'fa'));
    }
    
    return availableDoctors.sort((a,b) => a.name.localeCompare(b.name, 'fa'));
  }, [currentDay, filteredAppointments, doctors, showOnlyDoctorsWithAppointments, isMedicalStaff, currentUser.name]);

  const handleDoctorSelectionForCopy = (doctorId: string, isSelected: boolean) => {
    setSelectedDoctorIdsForCopy(prev => {
        if (isSelected) {
            return [...prev, doctorId];
        } else {
            return prev.filter(id => id !== doctorId);
        }
    });
  };

  const handleSelectAllDoctorsForCopy = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
        setSelectedDoctorIdsForCopy(doctorsOnCurrentDay.map(d => d.id));
    } else {
        setSelectedDoctorIdsForCopy([]);
    }
  };

  const handleCopyDay = async () => {
    if (!copyTargetDate) {
        alert("لطفا تاریخ مقصد را برای کپی کردن انتخاب کنید.");
        return;
    }
     if (selectedDoctorIdsForCopy.length === 0) {
        alert("لطفا حداقل یک پزشک را برای کپی کردن انتخاب کنید.");
        return;
    }
    
    const sourceDate = toLocalDateString(currentDay);
    const targetDate = copyTargetDate;

    if (sourceDate === targetDate) {
        alert("تاریخ مبدا و مقصد نمی‌توانند یکسان باشند.");
        return;
    }

    const appointmentsToCopy = filteredAppointments.filter(app => 
        app.date === sourceDate && selectedDoctorIdsForCopy.includes(app.doctorId)
    );

    if (appointmentsToCopy.length === 0) {
        alert("هیچ نوبتی برای پزشکان انتخاب شده در این روز وجود ندارد.");
        setIsCopyDayModalOpen(false);
        return;
    }

    const targetDayAppointments = appointments.filter(app => app.date === targetDate);
    if (targetDayAppointments.length > 0) {
        if (!window.confirm(`در تاریخ مقصد ${targetDayAppointments.length.toLocaleString('fa-IR')} نوبت وجود دارد. آیا می‌خواهید نوبت‌های جدید را اضافه کنید؟ این کار ممکن است باعث تداخل شود.`)) {
            return;
        }
    }

    const newAppointments = appointmentsToCopy.map(app => ({
        ...app,
        date: targetDate,
        status: 'Scheduled' as 'Scheduled',
        paymentStatus: 'Unpaid' as 'Unpaid',
        cancellationReason: undefined,
        cancellationFee: undefined,
        reminderSent: undefined,
        reminderDateTime: undefined,
    }));
    
    try {
        for (const app of newAppointments) {
            await addAppointment(app);
        }
        alert(`${newAppointments.length.toLocaleString('fa-IR')} نوبت از پزشکان منتخب با موفقیت به تاریخ ${formatToJalali(targetDate)} کپی شد.`);
    } catch(error) {
        console.error("Failed to copy appointments:", error);
        alert("خطا در کپی کردن نوبت‌ها.");
    }

    setIsCopyDayModalOpen(false);
    setSelectedDoctorIdsForCopy([]);
  };


  const renderDayView = () => {
    const handlePrevDay = () => setCurrentDay(prev => { const d = new Date(prev); d.setDate(prev.getDate() - 1); return d; });
    const handleNextDay = () => setCurrentDay(prev => { const d = new Date(prev); d.setDate(prev.getDate() + 1); return d; });
    const handleToday = () => setCurrentDay(new Date());

    const jalaliDateStr = formatToJalali(toLocalDateString(currentDay));
    const dayOfWeekName = new Intl.DateTimeFormat('fa-IR', { weekday: 'long' }).format(currentDay);
    
    const headerText = `${dayOfWeekName}، ${jalaliDateStr}`;

    const timeSlots = Array.from({ length: 44 }, (_, i) => {
        const hour = 10 + Math.floor(i / 4);
        const minute = (i % 4) * 15;
        return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    });
    
    // Use filteredAppointments here
    const dayAppointments = filteredAppointments.filter(app => app.date === toLocalDateString(currentDay));

    return (
        <div className="bg-white rounded-lg shadow-md">
            <div className="flex justify-between items-center p-4 border-b flex-wrap gap-2 bg-gray-50 rounded-t-lg">
                 <div className="flex items-center gap-2 flex-wrap">
                    <button onClick={handlePrevDay} className="p-2 rounded-full bg-white shadow-sm hover:bg-gray-100"><ChevronRightIcon className="w-5 h-5"/></button>
                    <button onClick={handleNextDay} className="p-2 rounded-full bg-white shadow-sm hover:bg-gray-100"><ChevronLeftIcon className="w-5 h-5"/></button>
                    <button onClick={handleToday} className="px-4 py-1.5 border rounded-lg text-sm bg-white shadow-sm hover:bg-gray-100">امروز</button>
                    {permissions.add && (
                        <button 
                            onClick={() => {
                                setCopyTargetDate('');
                                setSelectedDoctorIdsForCopy([]);
                                setIsCopyDayModalOpen(true);
                            }} 
                            className="px-4 py-1.5 border rounded-lg text-sm bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100 flex items-center gap-2"
                        >
                            <ClipboardCopyIcon className="w-4 h-4" />
                            <span className="hidden sm:inline">کپی نوبت‌ها</span>
                        </button>
                    )}
                     <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer ml-2 sm:ml-4">
                        <input
                            type="checkbox"
                            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                            checked={showOnlyDoctorsWithAppointments}
                            onChange={(e) => setShowOnlyDoctorsWithAppointments(e.target.checked)}
                        />
                        <span className="hidden sm:inline">فقط پزشکان دارای نوبت</span>
                        <span className="sm:hidden">فقط فعال</span>
                    </label>
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-800 mt-2 sm:mt-0 w-full sm:w-auto text-center sm:text-right">{headerText}</h3>
            </div>
            <div className="overflow-auto max-h-[75vh]">
                {doctorsOnCurrentDay.length > 0 ? (
                    <table className="w-full border-collapse">
                        <thead>
                            <tr>
                                <th className="sticky top-0 right-0 bg-gray-50 p-2 border-b border-l text-sm font-semibold w-20 sm:w-24 z-20 text-center text-gray-500">ساعت</th>
                                {doctorsOnCurrentDay.map(doc => <th key={doc.id} className="sticky top-0 p-2 border-b border-l text-sm font-semibold min-w-[120px] sm:min-w-[150px] bg-gray-50 z-10 text-gray-800">{doc.name}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {timeSlots.map(time => (
                                <tr key={time}>
                                    <td className="sticky right-0 bg-white p-2 border-b border-l text-center text-xs sm:text-sm font-mono z-10 text-gray-500">{time}</td>
                                    {doctorsOnCurrentDay.map(doc => {
                                        const appsInSlot = dayAppointments.filter(a => a.doctorId === doc.id && a.time === time);
                                        const isDragOverTarget = dragOverSlot?.doctorId === doc.id && dragOverSlot?.time === time;
                                        return (
                                            <td key={doc.id} className={`p-1 border-b border-l align-top min-h-[60px] transition-colors ${isDragOverTarget ? 'bg-green-100' : 'hover:bg-gray-50'}`}
                                              onDragOver={handleDragOver} onDragEnter={(e) => handleDragEnter(e, doc.id, time)} onDragLeave={handleDragLeave} onDrop={(e) => handleDrop(e, doc.id, time)}
                                              onDoubleClick={() => permissions.add && openAddModal(toLocalDateString(currentDay), time, doc.id)}>
                                                <div className="space-y-1">
                                                    {appsInSlot.map(app => {
                                                        const color = getDoctorColorClasses(doc.id); 
                                                        const isFinished = ['Completed', 'Cancelled'].includes(app.status);
                                                        const canEdit = permissions.edit && (canEditHistory || (!isPastDateTime(app.date, app.time) && !isFinished));
                                                        const isBeingDragged = draggingAppointmentId === app.id;
                                                        
                                                        const cardClass = isFinished 
                                                            ? 'bg-gray-200 text-gray-500 border-gray-300 opacity-80' 
                                                            : `${color.bg} ${color.text} border-r-4 ${color.border}`;

                                                        return (
                                                            <div key={app.id} draggable={canEdit} onDragStart={(e) => canEdit && handleDragStart(e, app.id)} onDragEnd={handleDragEnd}
                                                                onClick={(e) => { e.stopPropagation(); openEditModal(app); }} className={`group relative p-2 rounded-lg ${cardClass} h-full ${canEdit ? `cursor-pointer ${isFinished ? '' : color.hoverBg}` : `cursor-default`} ${isBeingDragged ? 'opacity-40' : ''} shadow-sm`}>
                                                                <p className="font-bold text-xs truncate">{getPatientNames(app.patientIds)}</p>
                                                                <p className="text-[10px] sm:text-xs opacity-75 mt-0.5">{app.sessionDuration || '?'} دقیقه</p>
                                                                {currentUser.role === 'مدیریت' && (
                                                                  <button 
                                                                    onClick={(e) => { e.stopPropagation(); confirmDeleteAppointment(app.id); }} 
                                                                    className="absolute top-1 left-1 bg-red-100/80 p-1 rounded-full opacity-100 sm:opacity-0 group-hover:opacity-100 hover:bg-red-200 transition-opacity" 
                                                                    title="حذف نوبت"
                                                                  >
                                                                    <TrashIcon className="w-3 h-3 text-red-700"/>
                                                                  </button>
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                     <p className="text-center text-gray-500 py-8 bg-gray-50 m-4 rounded-lg">
                        {showOnlyDoctorsWithAppointments ? "هیچ نوبتی برای این روز ثبت نشده است." : "پزشکی یافت نشد."}
                    </p>
                )}
            </div>
        </div>
    );
};
  
  const viewTabs = [
    { id: 'day', label: 'روزانه', icon: CalendarDayIcon }, { id: 'week', label: 'هفتگی', icon: CalendarWeekIcon },
    { id: 'month', label: 'ماهانه', icon: CalendarMonthIcon }, { id: 'list', label: 'لیست', icon: ListViewIcon }, { id: 'waiting', label: 'انتظار', icon: ClipboardListIcon }
  ];

  const sessionTotalCost = useMemo(() => {
    return sessionTotalCostOverride ?? autoCalculatedFee;
  }, [sessionTotalCostOverride, autoCalculatedFee]);
  
  const { patientHasInsurance, insuranceName } = useMemo(() => {
    if (formData.patientIds.length !== 1) return { patientHasInsurance: false, insuranceName: 'آزاد' };
    const patient = patients.find(p => p.id === formData.patientIds[0]);
    if (!patient || !patient.insuranceProviderId) return { patientHasInsurance: false, insuranceName: 'آزاد' };
    const provider = insuranceProviders.find(i => i.id === patient.insuranceProviderId);
    return { patientHasInsurance: !!provider, insuranceName: provider?.name || 'آزاد' };
  }, [formData.patientIds, patients, insuranceProviders]);

  const patientShare = useMemo(() => {
    let insuranceShare = 0;
    if (applyInsurance && patientHasInsurance) {
        const patient = patients.find(p => p.id === formData.patientIds[0]);
        const insuranceProvider = insuranceProviders.find(i => i.id === patient?.insuranceProviderId);
        if (insuranceProvider) {
            if (insuranceProvider.commissionType === 'percentage') {
                insuranceShare = Math.round(sessionTotalCost * (insuranceProvider.commissionValue / 100));
            } else {
                insuranceShare = Math.min(sessionTotalCost, insuranceProvider.commissionValue);
            }
        }
    }
    return sessionTotalCost - insuranceShare;
  }, [sessionTotalCost, formData.patientIds, patients, insuranceProviders, applyInsurance, patientHasInsurance]);

  const finalBalance = useMemo(() => {
    const totalPaidThisSession = sessionPayments.reduce((sum, p) => sum + parseFormattedNumber(p.amount), 0);
    return patientHistoricalBalance + patientShare - totalPaidThisSession;
  }, [patientHistoricalBalance, patientShare, sessionPayments]);
  
  return (
    <div>
        <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
            <h2 className="text-2xl sm:text-3xl font-bold">مدیریت نوبت‌دهی</h2>
            {permissions.add && <button onClick={() => openAddModal()} className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition flex items-center gap-2">
                <PlusIcon className="w-5 h-5"/>
                <span>افزودن نوبت</span>
            </button>}
        </div>
        <div className="mb-6 border-b border-gray-200">
            <nav className="-mb-px flex space-x-4 space-x-reverse overflow-x-auto no-scrollbar" aria-label="Tabs">
                {viewTabs.map(tab => <button key={tab.id} onClick={() => setViewMode(tab.id as any)}
                    className={`whitespace-nowrap py-3 px-4 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors ${viewMode === tab.id ? 'border-purple-500 text-purple-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    <tab.icon className="w-5 h-5"/>{tab.label}</button>
                )}
            </nav>
        </div>
        <div className="safe-area-pb">
            {viewMode === 'list' && renderListView()} 
            {viewMode === 'waiting' && renderWaitingListView()} 
            {viewMode === 'day' && renderDayView()}
            {(viewMode === 'month' || viewMode === 'week') && (
                <AppointmentCalendarView 
                    viewMode={viewMode} 
                    appointments={filteredAppointments} 
                    patients={patients} 
                    doctors={doctors} 
                    onAppointmentClick={openEditModal} 
                    onAppointmentCopy={handleCopyAppointment} 
                    permissions={permissions} 
                    currentUser={currentUser} 
                    onAddClick={openAddModal} 
                />
            )}
        </div>
        {isModalOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-60 z-40 backdrop-blur-sm overflow-y-auto" onClick={closeModal}>
                <div className="flex items-end sm:items-center justify-center min-h-screen p-0 sm:p-4">
                    <div className="bg-white rounded-t-2xl sm:rounded-xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[95vh] sm:max-h-auto" onClick={(e) => e.stopPropagation()}>
                        <div className="p-6 border-b sticky top-0 bg-white z-10 rounded-t-2xl">
                            <h3 className="text-2xl font-bold">{editingAppointment ? 'ویرایش نوبت' : 'افزودن نوبت جدید'}</h3>
                        </div>
                        <div className="p-6 overflow-y-auto">
                            <form onSubmit={handleSaveAppointment} className="space-y-5">
                                <div ref={patientSearchRef}><label className="block text-gray-700 mb-2 font-medium">بیمار(ان)<span className="text-red-500 mr-1">*</span></label>
                                    <div className="border rounded-lg p-2 flex flex-wrap gap-2 min-h-[44px] bg-gray-50">{formData.patientIds.map(id => (<div key={id} className="bg-white border shadow-sm text-sm rounded-full px-3 py-1 flex items-center gap-2">{getPatientName(id)}<button type="button" onClick={() => !isLockedForEditing && handleRemovePatientFromSelection(id)} className="text-red-500 hover:font-bold disabled:opacity-50 disabled:cursor-not-allowed" disabled={isLockedForEditing}>&times;</button></div>))}</div>
                                    {!isLockedForEditing && <div className="relative mt-2">
                                        <input type="text" placeholder="جستجوی بیمار برای افزودن..." value={patientSearch} onChange={e => { setPatientSearch(e.target.value); setIsPatientDropdownOpen(true); }} onFocus={() => setIsPatientDropdownOpen(true)} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"/>
                                        {isPatientDropdownOpen && availablePatients.length > 0 && (<div className="absolute z-10 w-full bg-white border rounded-lg mt-1 max-h-48 overflow-y-auto shadow-lg">{availablePatients.map(p => (<div key={p.id} onClick={() => handleAddPatientToSelection(p.id)} className="p-3 hover:bg-gray-100 cursor-pointer border-b last:border-0">{p.name}</div>))}</div>)}
                                    </div>}
                                </div>
                                <div><label className="block text-gray-700 mb-2 font-medium">پزشک<span className="text-red-500 mr-1">*</span></label><select name="doctorId" value={formData.doctorId} onChange={handleInputChange} className="w-full p-3 border rounded-lg disabled:bg-gray-200 disabled:cursor-not-allowed bg-white" required={formData.status !== 'Waiting'} disabled={isLockedForEditing || !!currentDoctorId}><option value="">انتخاب پزشک</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
                                
                                {/* Suggested Therapists Field - Visible in Waiting/Scheduled modes or if populated */}
                                {(formData.status === 'Waiting' || formData.suggestedServices?.length || formData.suggestedDoctorIds?.length) && (
                                    <div className="p-4 border rounded-lg bg-yellow-50 space-y-2">
                                        <label className="block text-gray-700 font-semibold mb-2">درمانگران پیشنهادی (توسط پزشک داخلی)</label>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                                            {doctors.map(doc => {
                                                const service = formData.suggestedServices?.find(s => s.doctorId === doc.id);
                                                const isSelected = !!service;
                                                
                                                return (
                                                    <div key={doc.id} className={`flex items-center justify-between p-2 border rounded transition-colors ${isSelected ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200 hover:bg-gray-50'}`}>
                                                        <label className="flex items-center gap-2 cursor-pointer flex-1">
                                                            <input
                                                                type="checkbox"
                                                                checked={isSelected}
                                                                onChange={() => handleSuggestedDoctorsChange(doc.id)}
                                                                className="w-4 h-4 text-blue-600 rounded disabled:cursor-not-allowed"
                                                                disabled={isLockedForEditing}
                                                            />
                                                            <span className="text-sm">{doc.name}</span>
                                                        </label>
                                                        
                                                        {isSelected && (
                                                            <select
                                                                value={service.count}
                                                                onChange={(e) => handleSuggestedCountChange(doc.id, parseInt(e.target.value))}
                                                                className="text-xs p-1 border rounded bg-white mr-2 outline-none focus:ring-1 focus:ring-blue-500"
                                                                disabled={isLockedForEditing}
                                                                onClick={(e) => e.stopPropagation()}
                                                            >
                                                                <option value={1}>۱ جلسه</option>
                                                                <option value={2}>۲ جلسه</option>
                                                                <option value={3}>۳ جلسه</option>
                                                                <option value={4}>۴ جلسه</option>
                                                            </select>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                        <p className="text-xs text-gray-500 mt-1">این پیشنهادها به منشی کمک می‌کند تا درمانگر مناسب را انتخاب کند.</p>
                                    </div>
                                )}

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <JalaliDatePicker label="تاریخ" value={formData.date} onChange={(date) => handleDateChange('date', date)} required disabled={isLockedForEditing}/>
                                    <div><label className="block text-gray-700 mb-1 font-medium">ساعت <span className="text-gray-500 text-xs">(اختیاری)</span></label><CustomTimePicker value={formData.time || ''} onChange={(newTime) => handleDateChange('time', newTime)} disabled={isLockedForEditing}/></div>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div><label className="block text-gray-700 mb-2 font-medium">وضعیت نوبت<span className="text-red-500 mr-1">*</span></label><select name="status" value={formData.status} onChange={handleInputChange} className="w-full p-3 border rounded-lg disabled:bg-gray-200 disabled:cursor-not-allowed bg-white" disabled={isLockedForEditing}><option value="Scheduled">زمان‌بندی شده</option><option value="Completed">تکمیل شده</option><option value="Cancelled">لغو شده</option><option value="Waiting">در انتظار</option></select></div>
                                    {['Scheduled', 'Completed'].includes(formData.status) && (
                                        <div>
                                            <label className="block text-gray-700 mb-2 font-medium">مدت زمان جلسه</label>
                                            <select name="sessionDuration" value={formData.sessionDuration} onChange={handleInputChange} className="w-full p-3 border rounded-lg bg-white disabled:bg-gray-200 disabled:cursor-not-allowed" disabled={isLockedForEditing}>
                                                <option value="15">۱۵ دقیقه</option>
                                                <option value="30">۳۰ دقیقه</option>
                                                <option value="45">۴۵ دقیقه</option>
                                                <option value="60">۶۰ دقیقه (۱ ساعت)</option>
                                                <option value="90">90 دقیقه (۱.۵ ساعت)</option>
                                                <option value="120">۱۲۰ دقیقه (۲ ساعت)</option>
                                            </select>
                                        </div>
                                    )}
                                </div>
                                
                                {formData.status === 'Cancelled' && (<div><label className="block text-gray-700 mb-2 font-medium">دلیل لغو<span className="text-red-500 mr-1">*</span></label><VoiceEnabledTextarea name="cancellationReason" value={formData.cancellationReason || ''} onChange={handleInputChange} className="w-full p-3 border rounded-lg" required rows={2} disabled={isLockedForEditing} /></div>)}
                                {formData.status === 'Cancelled' && (<div className="p-4 border rounded-lg bg-red-50 space-y-4">
                                    <label htmlFor="charge-cancellation" className="flex items-center cursor-pointer"><input type="checkbox" id="charge-cancellation" className="w-5 h-5 ml-3 rounded text-red-600 focus:ring-red-500 border-gray-300 disabled:cursor-not-allowed" checked={cancellationFeeData.charge} onChange={(e) => !isLockedForEditing && setCancellationFeeData(p => ({...p, charge: e.target.checked}))} disabled={isLockedForEditing}/><span className="font-semibold text-gray-700">ثبت هزینه کنسلی</span></label>
                                    {cancellationFeeData.charge && (<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div><label className="block text-gray-700 mb-1">مبلغ جریمه*</label><input type="text" value={cancellationFeeData.amount} onChange={e => setCancellationFeeData(p => ({...p, amount: e.target.value}))} className="w-full p-3 border rounded-lg bg-white disabled:bg-gray-200" disabled={isLockedForEditing}/></div>
                                        <div><label className="block text-gray-700 mb-1">روش پرداخت</label><select value={cancellationFeeData.paymentMethod} onChange={e => setCancellationFeeData(p => ({...p, paymentMethod: e.target.value as any}))} className="w-full p-3 border rounded-lg disabled:bg-gray-200" disabled={isLockedForEditing}><option value="نقد">نقد</option><option value="کارت به کارت">کارت به کارت</option><option value="پوز">پوز</option></select></div>
                                        <div><label className="block text-gray-700 mb-1">به حساب</label><select value={cancellationFeeData.accountDebited} onChange={e => setCancellationFeeData(p => ({...p, accountDebited: e.target.value}))} className="w-full p-3 border rounded-lg disabled:bg-gray-200" disabled={isLockedForEditing}><option value="">انتخاب</option>{bankAccounts.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}</select></div>
                                    </div>)}
                                </div>)}

                                {formData.status === 'Completed' && (
                                    <div className="p-4 border rounded-lg bg-gray-50 space-y-4">
                                        <div><label className="block text-gray-700 mb-2 font-medium">هزینه جلسه (تومان)</label><input type="text" name="sessionFee" value={formatNumberWithCommas(sessionTotalCostOverride ?? formData.sessionFee ?? '')} onChange={(e) => setSessionTotalCostOverride(parseFormattedNumber(e.target.value))} className="w-full p-3 border rounded-lg bg-white disabled:bg-gray-200" disabled={isLockedForEditing} /></div>
                                        
                                        <div className="p-4 border rounded-lg bg-white shadow-sm space-y-3 text-sm">
                                            <h4 className="font-bold text-gray-800 border-b pb-2">خلاصه حساب بیمار</h4>
                                            <div className="flex justify-between items-center"><span className="text-gray-600">بدهکاری / بستانکاری قبلی:</span><span className={`font-semibold ${patientHistoricalBalance > 0 ? 'text-red-600' : 'text-green-600'}`}>{Math.abs(patientHistoricalBalance).toLocaleString('fa-IR')} تومان {patientHistoricalBalance > 0 ? '(بدهکار)' : (patientHistoricalBalance < 0 ? '(بستانکار)' : '')}</span></div>
                                            <div className="flex justify-between items-center"><span className="text-gray-600">بیمه بیمار:</span><span className="font-semibold">{insuranceName}</span></div>
                                            {patientHasInsurance && (
                                                <div className="flex justify-end items-center">
                                                    <label className="flex items-center gap-2 cursor-pointer text-gray-700">
                                                        <input 
                                                            type="checkbox" 
                                                            checked={applyInsurance} 
                                                            onChange={(e) => setApplyInsurance(e.target.checked)}
                                                            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 disabled:cursor-not-allowed"
                                                            disabled={isLockedForEditing}
                                                        />
                                                        اعمال سهم بیمه
                                                    </label>
                                                </div>
                                            )}
                                            <div className="flex justify-between items-center border-t pt-2 mt-2"><span className="text-gray-600 font-bold">مجموع پرداختی این جلسه:</span><span className="font-bold text-blue-600 text-lg">{sessionPayments.reduce((sum, p) => sum + parseFormattedNumber(p.amount), 0).toLocaleString('fa-IR')} تومان</span></div>
                                        </div>
                                        
                                        <div>
                                            <label className="block text-gray-700 mb-2 font-medium">وضعیت پرداخت<span className="text-red-500 mr-1">*</span></label><select name="paymentStatus" value={formData.paymentStatus} onChange={handleInputChange} className="w-full p-3 border rounded-lg disabled:bg-gray-200 bg-white" disabled={isLockedForEditing}><option value="Unpaid">پرداخت نشده</option><option value="Paid">پرداخت شده</option></select>
                                        </div>
                                        
                                        {formData.paymentStatus === 'Paid' && (
                                            <div className="p-3 border rounded-lg bg-white space-y-3">
                                                <h4 className="font-semibold text-gray-700">جزئیات پرداخت</h4>
                                                {sessionPayments.map((payment, index) => (
                                                    <div key={payment.id} className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center border-b pb-3 last:border-0 last:pb-0">
                                                        {formData.patientIds.length > 1 && (
                                                            <div className="sm:col-span-3">
                                                                <select 
                                                                    value={payment.patientId} 
                                                                    onChange={e => handlePaymentChange(payment.id, 'patientId', e.target.value)} 
                                                                    className="w-full p-2 border rounded-lg disabled:bg-gray-200 text-xs" 
                                                                    disabled={isLockedForEditing}
                                                                >
                                                                    {formData.patientIds.map(pid => (
                                                                        <option key={pid} value={pid}>{getPatientName(pid)}</option>
                                                                    ))}
                                                                </select>
                                                            </div>
                                                        )}
                                                        <input type="text" placeholder="مبلغ (تومان)" value={formatNumberWithCommas(payment.amount)} onChange={e => handlePaymentChange(payment.id, 'amount', e.target.value)} className={`${formData.patientIds.length > 1 ? 'sm:col-span-3' : 'sm:col-span-4'} w-full p-2 border rounded-lg disabled:bg-gray-200`} disabled={isLockedForEditing}/>
                                                        <select value={payment.method} onChange={e => handlePaymentChange(payment.id, 'method', e.target.value)} className="sm:col-span-3 w-full p-2 border rounded-lg disabled:bg-gray-200" disabled={isLockedForEditing}>
                                                            <option value="پوز">پوز</option><option value="کارت به کارت">کارت به کارت</option><option value="نقد">نقد</option>
                                                        </select>
                                                        {!['پزشک', 'درمانگر', 'درمانگران'].includes(currentUser.role) && (
                                                            <select value={payment.accountId} onChange={e => handlePaymentChange(payment.id, 'accountId', e.target.value)} className={`${formData.patientIds.length > 1 ? 'sm:col-span-2' : 'sm:col-span-4'} w-full p-2 border rounded-lg disabled:bg-gray-200`} disabled={isLockedForEditing}>
                                                                {bankAccounts.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                                                            </select>
                                                        )}
                                                        <button type="button" onClick={() => !isLockedForEditing && handleRemovePayment(payment.id)} className="sm:col-span-1 text-red-500 p-2 rounded-lg hover:bg-red-50 disabled:opacity-50 flex justify-center" disabled={isLockedForEditing}><TrashIcon className="w-5 h-5"/></button>
                                                    </div>
                                                ))}
                                                {!isLockedForEditing && <button type="button" onClick={handleAddPayment} className="w-full bg-gray-100 text-gray-700 px-3 py-2 text-sm rounded-lg hover:bg-gray-200 flex items-center justify-center gap-1 font-medium"><PlusIcon className="w-4 h-4"/> افزودن ردیف پرداخت</button>}
                                            </div>
                                        )}
                                    </div>
                                )}
                                
                                {canEditClinicalRecord && formData.status === 'Completed' && currentRecord ? (
                                    <div className="p-4 border rounded-lg bg-gray-50/50">
                                        <h4 className="font-semibold text-gray-700 mb-3 -mt-1 flex items-center gap-2"><DocumentReportIcon className="w-5 h-5"/> پرونده بالینی (طرح درمان)</h4>
                                        {/* New Attachment Section for Therapists */}
                                        <div className="mb-4 p-3 bg-white rounded border border-blue-100">
                                            <label className="block text-sm font-medium text-gray-700 mb-2">فایل‌های ضمیمه بیمار</label>
                                            <div className="flex items-center gap-3">
                                                <div className="relative overflow-hidden inline-block">
                                                    <button type="button" onClick={() => document.getElementById('modal-attachment-upload')?.click()} className="bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors">
                                                        <UploadIcon className="w-4 h-4"/> آپلود فایل جدید
                                                    </button>
                                                    <input type="file" id="modal-attachment-upload" accept="image/jpeg,application/pdf" onChange={handlePatientAttachmentUpload} className="absolute inset-0 opacity-0 cursor-pointer w-full"/>
                                                </div>
                                                <span className="text-xs text-gray-500">فایل مستقیماً در پرونده بیمار ذخیره می‌شود.</span>
                                            </div>
                                        </div>

                                        <div className="space-y-3">
                                            <div>
                                                <label className="block text-sm font-medium text-gray-600 mb-1">شرح حال و طرح درمان</label>
                                                <VoiceEnabledTextarea 
                                                    value={currentRecord.note || ''} 
                                                    onChange={(e) => handleRecordChange('note', e.target.value)} 
                                                    rows={6} 
                                                    placeholder="شرح حال، مشاهدات و طرح درمان را وارد کنید..."
                                                />
                                            </div>
                                        </div>
                                    </div>
                                ) : !canEditClinicalRecord && formData.status === 'Completed' && (<div className="p-4 border rounded-lg bg-gray-100 text-center text-sm text-gray-500">پرونده بالینی این جلسه توسط پزشک/درمانگر ثبت می‌شود و محرمانه است.</div>)}
                                
                                <div className="mt-4">
                                    <label className="block text-gray-700 mb-2 font-medium">یادداشت داخلی (اختیاری)</label>
                                    <VoiceEnabledTextarea 
                                        name="notes" 
                                        value={formData.notes || ''} 
                                        onChange={handleInputChange} 
                                        rows={2}
                                        disabled={isLockedForEditing}
                                    />
                                </div>

                                <div className="border-t pt-4 mt-4">
                                    <label htmlFor="custom-reminder-toggle" className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-lg transition"><input type="checkbox" id="custom-reminder-toggle" className="w-5 h-5 ml-3 rounded text-purple-600 focus:ring-purple-500 border-gray-300 disabled:cursor-not-allowed" checked={isCustomReminderEnabled} onChange={(e) => !isLockedForEditing && setIsCustomReminderEnabled(e.target.checked)} disabled={isLockedForEditing}/><span className="font-semibold text-gray-700">تنظیم یادآوری سفارشی</span></label>
                                    {isCustomReminderEnabled && (<div className="mt-4 p-4 bg-gray-50 rounded-lg grid grid-cols-1 md:grid-cols-2 gap-4 border"><JalaliDatePicker label="تاریخ یادآوری" value={reminderDate} onChange={setReminderDate} required disabled={isLockedForEditing}/><div><label className="block text-gray-700 mb-1">ساعت یادآوری<span className="text-red-500 mr-1">*</span></label><CustomTimePicker value={reminderTime} onChange={setReminderTime} required={isCustomReminderEnabled} disabled={isLockedForEditing}/></div></div>)}
                                </div>
                                
                                <div className="sticky bottom-0 bg-white pt-4 border-t mt-6 flex items-center gap-3 pb-2">
                                    <button type="button" onClick={closeModal} className="flex-1 bg-gray-100 text-gray-800 py-3 rounded-lg hover:bg-gray-200 font-medium transition">لغو</button>
                                    {!isLockedForEditing && <button type="submit" className="flex-1 bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 font-bold shadow-lg shadow-purple-200 transition">ذخیره</button>}
                                    {isLockedForEditing && canEditClinicalRecord && <button type="submit" className="flex-1 bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 font-bold shadow-lg shadow-purple-200 transition">ذخیره پرونده</button>}
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        )}
        
        {isDeleteModalOpen && deletingAppointment && (
            <div className="fixed inset-0 bg-black bg-opacity-60 z-50 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">حذف از لیست انتظار</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  برای حذف نوبت بیمار <span className="font-bold text-gray-800">{getPatientNames(deletingAppointment.patientIds)}</span> از لیست انتظار، لطفا دلیل آن را وارد کنید.
                </p>
                <div>
                  <label htmlFor="deleteReason" className="block text-gray-700 font-semibold mb-2">دلیل حذف (اجباری)</label>
                  <textarea
                    id="deleteReason"
                    value={deleteReason}
                    onChange={(e) => setDeleteReason(e.target.value)}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
                    rows={3}
                    placeholder="مثال: بیمار نوبت جدید دریافت کرد."
                    autoFocus
                  />
                </div>
                <div className="flex justify-end mt-8 gap-3">
                  <button type="button" onClick={closeDeleteModal} className="bg-gray-100 text-gray-800 px-5 py-2.5 rounded-lg hover:bg-gray-200 transition font-medium">انصراف</button>
                  <button
                    type="button"
                    onClick={handleConfirmRemoveFromWaitingList}
                    disabled={!deleteReason.trim()}
                    className="bg-red-600 text-white px-5 py-2.5 rounded-lg hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed font-bold shadow-lg shadow-red-200 transition"
                  >
                    حذف از لیست
                  </button>
                </div>
              </div>
            </div>
        )}
        {isCopyDayModalOpen && (
             <div className="fixed inset-0 bg-black bg-opacity-60 z-50 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                    <h3 className="text-xl font-bold mb-4">کپی نوبت‌های روز</h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">
                        نوبت‌های پزشکان منتخب از تاریخ <span className="font-bold text-blue-600 mx-1">{formatToJalali(currentDay.toISOString())}</span> به تاریخ مقصد کپی خواهند شد.
                    </p>
                    <div className="mb-6">
                        <JalaliDatePicker label="تاریخ مقصد" value={copyTargetDate} onChange={setCopyTargetDate} required />
                    </div>

                    <div className="mt-6">
                        <h4 className="font-bold text-gray-700 mb-3">پزشکان مورد نظر را انتخاب کنید</h4>
                        {doctorsOnCurrentDay.length > 0 ? (
                            <div className="space-y-2 max-h-48 overflow-y-auto border p-3 rounded-lg bg-gray-50">
                                <label className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 cursor-pointer font-bold border-b pb-2 mb-2">
                                    <input 
                                        type="checkbox" 
                                        className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                                        onChange={handleSelectAllDoctorsForCopy}
                                        checked={doctorsOnCurrentDay.length > 0 && selectedDoctorIdsForCopy.length === doctorsOnCurrentDay.length}
                                    />
                                    انتخاب همه
                                </label>
                                {doctorsOnCurrentDay.map(doc => (
                                    <label key={doc.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 cursor-pointer transition">
                                        <input 
                                            type="checkbox"
                                            value={doc.id}
                                            className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                                            checked={selectedDoctorIdsForCopy.includes(doc.id)}
                                            onChange={(e) => handleDoctorSelectionForCopy(doc.id, e.target.checked)}
                                        />
                                        {doc.name}
                                    </label>
                                ))}
                            </div>
                        ) : (
                            <p className="text-center text-gray-500 py-4 bg-gray-50 rounded-lg">پزشکی در این روز نوبت ندارد.</p>
                        )}
                    </div>
                    
                    <div className="flex justify-end mt-8 gap-3">
                        <button type="button" onClick={() => setIsCopyDayModalOpen(false)} className="bg-gray-100 text-gray-800 px-5 py-2.5 rounded-lg hover:bg-gray-200 font-medium transition">انصراف</button>
                        <button 
                            type="button" 
                            onClick={handleCopyDay} 
                            disabled={!copyTargetDate || selectedDoctorIdsForCopy.length === 0}
                            className="bg-blue-600 text-white px-5 py-2.5 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed font-bold shadow-lg shadow-blue-200 transition"
                        >
                          کپی نوبت‌ها
                        </button>
                    </div>
                </div>
             </div>
        )}
    </div>
  );
};

export default AppointmentManagementPage;
