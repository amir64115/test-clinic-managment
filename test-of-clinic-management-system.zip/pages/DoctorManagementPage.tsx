
import React from 'react';
import DoctorManagement from '../components/DoctorManagement';
import type { Doctor, PermissionSet, Personnel, Appointment } from '../types';

interface DoctorManagementPageProps {
  doctors: Doctor[];
  permissions: PermissionSet;
  currentUser: Personnel;
  addDoctor: (doctor: Omit<Doctor, 'id'>) => Promise<Doctor>;
  updateDoctor: (doctor: Doctor) => Promise<Doctor>;
  deleteDoctor: (id: number | string) => Promise<void>;
  appointments: Appointment[];
}

const DoctorManagementPage: React.FC<DoctorManagementPageProps> = (props) => {
  return <DoctorManagement {...props} />;
};

export default DoctorManagementPage;
