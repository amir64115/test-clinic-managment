
import React from 'react';
import Settings from '../components/Settings';
import type { AppPermissions, Personnel } from '../types';

interface SettingsPageProps {
  permissions: AppPermissions;
  setPermissions: React.Dispatch<React.SetStateAction<AppPermissions>>;
  personnel: Personnel[];
  setPersonnel: React.Dispatch<React.SetStateAction<Personnel[]>>;
}

const SettingsPage: React.FC<SettingsPageProps> = (props) => {
  return <Settings {...props} />;
};

export default SettingsPage;
