import React from 'react';
import PatientManagement from '../components/PatientManagement';
import type { Patient, Doctor, Appointment, InsuranceProvider, PermissionSet, Personnel, TreatmentPlan, ClinicalRecord, Transaction } from '../types';

interface PatientManagementPageProps {
  patients: Patient[];
  setPatients: React.Dispatch<React.SetStateAction<Patient[]>>;
  addPatient: (patient: Omit<Patient, 'id'>) => Promise<Patient>;
  updatePatient: (patient: Patient) => Promise<Patient>;
  deletePatient: (id: string) => Promise<void>;
  doctors: Doctor[];
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  insuranceProviders: InsuranceProvider[];
  permissions: PermissionSet;
  currentUser: Personnel;
  personnel: Personnel[];
  treatmentPlans: TreatmentPlan[];
  setTreatmentPlans: React.Dispatch<React.SetStateAction<TreatmentPlan[]>>;
  addTreatmentPlan: (plan: Omit<TreatmentPlan, 'id'>) => Promise<TreatmentPlan>;
  updateTreatmentPlan: (plan: TreatmentPlan) => Promise<TreatmentPlan>;
  clinicalRecords: ClinicalRecord[];
  addClinicalRecord: (record: Omit<ClinicalRecord, 'id'>) => Promise<ClinicalRecord>;
  updateClinicalRecord: (record: ClinicalRecord) => Promise<ClinicalRecord>;
  transactions: Transaction[]; // Added transactions prop
}

const PatientManagementPage: React.FC<PatientManagementPageProps> = (props) => {
  return <PatientManagement {...props} />;
};

export default PatientManagementPage;