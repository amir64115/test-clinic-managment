
import React from 'react';
import FinancialManagement from '../components/FinancialManagement';
import type { Transaction, Patient, Doctor, Personnel, BankAccount, InsuranceProvider, CostCategory, PermissionSet } from '../types';

interface FinancialManagementPageProps {
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction>;
  updateTransaction: (transaction: Transaction) => Promise<Transaction>;
  deleteTransaction: (id: string) => Promise<void>;
  
  patients: Patient[];
  doctors: Doctor[];
  personnel: Personnel[];
  
  bankAccounts: BankAccount[];
  addBankAccount: (account: Omit<BankAccount, 'id'>) => Promise<BankAccount>;
  updateBankAccount: (account: BankAccount) => Promise<BankAccount>;
  deleteBankAccount: (id: string) => Promise<void>;
  
  insuranceProviders: InsuranceProvider[];
  addInsuranceProvider: (provider: Omit<InsuranceProvider, 'id'>) => Promise<InsuranceProvider>;
  updateInsuranceProvider: (provider: InsuranceProvider) => Promise<InsuranceProvider>;
  deleteInsuranceProvider: (id: string) => Promise<void>;
  
  costCategories: CostCategory[];
  addCostCategory: (category: Omit<CostCategory, 'id'>) => Promise<CostCategory>;
  updateCostCategory: (category: CostCategory) => Promise<CostCategory>;
  deleteCostCategory: (id: string) => Promise<void>;
  
  permissions: PermissionSet;
}

const FinancialManagementPage: React.FC<FinancialManagementPageProps> = (props) => {
  return <FinancialManagement {...props} />;
};

export default FinancialManagementPage;
