
import React from 'react';
import type { AppView, AppPermissions, Personnel, TreatmentPlan, Patient, Doctor } from '../types';
import Dashboard from '../components/Dashboard';

interface DashboardPageProps {
  setCurrentView: (view: AppView) => void;
  currentUser: Personnel;
  permissions: AppPermissions;
  personnel: Personnel[];
  treatmentPlans: TreatmentPlan[];
  updateTreatmentPlan: (plan: TreatmentPlan) => Promise<TreatmentPlan>;
  patients: Patient[];
  doctors: Doctor[];
}

const DashboardPage: React.FC<DashboardPageProps> = (props) => {
  return <Dashboard {...props} />;
};

export default DashboardPage;
