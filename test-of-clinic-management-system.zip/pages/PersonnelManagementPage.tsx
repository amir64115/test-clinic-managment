
import React from 'react';
import PersonnelManagement from '../components/PersonnelManagement';
import type { Personnel, PermissionSet, AppPermissions } from '../types';

interface PersonnelManagementPageProps {
  personnel: Personnel[];
  permissions: PermissionSet;
  allPermissions: AppPermissions;
  addPersonnel: (personnel: Omit<Personnel, 'id'>) => Promise<Personnel>;
  updatePersonnel: (personnel: Personnel) => Promise<Personnel>;
  deletePersonnel: (id: number | string) => Promise<void>;
}

const PersonnelManagementPage: React.FC<PersonnelManagementPageProps> = (props) => {
  return <PersonnelManagement {...props} />;
};

export default PersonnelManagementPage;
