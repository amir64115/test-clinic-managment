
import React from 'react';
import Reports from '../components/Reports';
import type { Transaction, Patient, Doctor, Appointment, InsuranceProvider, BankAccount, Personnel, CostCategory } from '../types';

interface ReportsPageProps {
  transactions: Transaction[];
  patients: Patient[];
  doctors: Doctor[];
  appointments: Appointment[];
  insuranceProviders: InsuranceProvider[];
  bankAccounts: BankAccount[];
  personnel: Personnel[];
  currentUser: Personnel;
  costCategories: CostCategory[];
}

const ReportsPage: React.FC<ReportsPageProps> = (props) => {
  return <Reports {...props} />;
};

export default ReportsPage;
