
import React, { useState } from 'react';
import type { Personnel } from '../types';
import { db } from '../db'; // Import the local db

interface LoginPageProps {
    onLoginSuccess: (user: Personnel) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!username.trim() || !password.trim()) {
            setError('نام کاربری و رمز عبور نمی‌توانند خالی باشند.');
            return;
        }

        setIsLoading(true);

        try {
            // Fetch personnel data from local storage via db
            const personnelList = await db.getPersonnel();
            const user = personnelList.find(p => p.username === username.trim());

            if (user && user.password === password) {
                // On success, save to localStorage and trigger success callback
                localStorage.setItem('currentUser', JSON.stringify(user));
                onLoginSuccess(user);
            } else {
                setError('نام کاربری یا رمز عبور نادرست است.');
            }
        } catch (err) {
            console.error("Login failed:", err);
            setError('خطا در بارگذاری اطلاعات کاربران. لطفا صفحه را رفرش کنید.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
          <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-sm">
            <h2 className="text-2xl font-bold mb-2 text-center text-gray-800">ورود به سیستم</h2>
            <p className="text-center text-gray-500 mb-6 text-sm">کلینیک</p>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="username" className="block text-sm font-medium text-gray-700">نام کاربری</label>
                    <input
                        id="username"
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="mt-1 w-full p-2 border rounded-lg"
                        required autoFocus
                    />
                </div>
                <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700">رمز عبور</label>
                    <input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="mt-1 w-full p-2 border rounded-lg"
                        required
                    />
                </div>
                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                <div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        {isLoading ? 'در حال ورود...' : 'ورود'}
                    </button>
                </div>
            </form>
          </div>
        </div>
    );
};

export default LoginPage;
