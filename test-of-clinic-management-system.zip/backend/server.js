// ✅ Clinic Backend (Express + Mongoose) — Liara-ready

require('ts-node').register(); // Allows server to require .ts files directly
require('express-async-errors'); // Must be required early
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');

// ----- ENV -----
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
  console.error("❌ MONGODB_URI is required in environment variables.");
  process.exit(1);
}
const PORT = parseInt(process.env.PORT || "80", 10);
const FRONTEND_URL = process.env.FRONTEND_URL || "https://radclinic.liara.run";

const app = express();

// ----- Security/Headers (without ORB) -----
app.set('trust proxy', 1); // Required for express-rate-limit and X-Forwarded-For on platforms like Liara
app.use(helmet({
  crossOriginEmbedderPolicy: false,                   // Prevents require-corp
  crossOriginResourcePolicy: { policy: 'cross-origin' }, // Allows cross-origin consumption
}));

// ----- CORS -----
app.use(cors({
  origin: [FRONTEND_URL, 'http://localhost:3000', 'http://localhost:5173'], // Added localhost for development
  credentials: false,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.options('*', cors());
console.log(`CORS allowed for: ${FRONTEND_URL} and development servers.`);

// ----- Logger & Parsers -----
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ----- Rate Limit -----
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 500,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// ----- MongoDB -----
mongoose
  .connect(MONGODB_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => {
    console.error('❌ Database connection error:', err);
    process.exit(1);
  });

// ----- Dynamic Models (collections == resource name) -----
const modelCache = {};
function getModel(name) {
  if (modelCache[name]) return modelCache[name];
  // Using a flexible schema to accommodate any document structure
  const schema = new mongoose.Schema({}, { strict: false, timestamps: true });
  const model = mongoose.model(name, schema, name);
  modelCache[name] = model;
  return model;
}

// ----- Data Transformation Utility -----
// Recursively transforms MongoDB '_id' to a frontend-friendly 'id'
function transformId(data) {
  if (Array.isArray(data)) {
    return data.map(transformId);
  }
  if (data && typeof data === 'object' && data._id) {
    // Create a new object to avoid modifying the original lean object
    const result = { ...data, id: data._id.toString() };
    delete result._id;
    delete result.__v; // also remove the version key
    return result;
  }
  return data;
}


// ----- Root -----
app.get('/', (_req, res) => {
  res.send('✅ Clinic backend is running');
});

// ===== Permissions endpoints (explicit) =====
app.get("/api/permissions", async (req, res) => {
  try {
    const Model = getModel("permissions");
    const doc = await Model.findOne({}).lean();

    if (!doc) {
      // If nothing is in the DB, return an empty object so the frontend uses its DEFAULT_PERMISSIONS
      return res.json({});
    }

    // Destructure to explicitly remove mongoose metadata fields before sending
    const { _id, __v, createdAt, updatedAt, ...permissionsData } = doc;

    return res.json(permissionsData);
  } catch (err) {
    console.error("GET /api/permissions error:", err);
    return res.status(500).json({ error: "Failed to read permissions" });
  }
});

app.post("/api/permissions", async (req, res) => {
  try {
    const Model = getModel("permissions");
    const payload = req.body;

    // We only keep one document to ensure a consistent structure
    await Model.deleteMany({});

    // Accept both a direct object and a {data: ...} structure
    const docToSave =
      (payload && typeof payload === "object" && payload.data)
        ? { data: payload.data }
        : payload;

    const created = await Model.create(docToSave);
    return res.status(201).json(transformId(created.toObject()));
  } catch (err) {
    console.error("POST /api/permissions error:", err);
    return res.status(500).json({ error: "Failed to save permissions" });
  }
});

// ----- User Authentication -----
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ ok: false, message: 'Username and password are required.' });
  }

  const PersonnelModel = getModel('personnel');
  let user = await PersonnelModel.findOne({ username }).lean();

  if (user && user.password === password) {
    // IMPORTANT: Never send the password back to the client
    const { password: _, ...userWithoutPassword } = user;
    return res.json({ ok: true, user: transformId(userWithoutPassword) });
  }

  // If user not found, check if it's the very first login attempt to an empty DB
  if (!user) {
    const userCount = await PersonnelModel.countDocuments({});
    if (userCount === 0) {
      console.log('No users found in DB. Attempting to seed on first login.');
      // This is the first login. Let's seed the personnel data.
      try {
        const constants = require('./constants.ts');
        if (constants && constants.PERSONNEL_DATA && constants.PERSONNEL_DATA.length > 0) {
          await PersonnelModel.insertMany(constants.PERSONNEL_DATA);
          console.log(`🌱 Seeded ${constants.PERSONNEL_DATA.length} personnel records on first login.`);
          // Now, try to find the user again
          user = await PersonnelModel.findOne({ username }).lean();
          if (user && user.password === password) {
            const { password: _, ...userWithoutPassword } = user;
            return res.json({ ok: true, user: transformId(userWithoutPassword) });
          }
        }
      } catch (e) {
        console.error('Error during on-demand seeding:', e);
        return res.status(500).json({ ok: false, message: 'Server error during initial setup.' });
      }
    }
  }
  
  return res.status(401).json({ ok: false, message: 'Invalid credentials' });
});


// ----- Generic CRUD Endpoints -----

// GET all documents for a resource
app.get('/api/:resource', async (req, res) => {
  const { resource } = req.params;
  const Model = getModel(resource);
  const docs = await Model.find({}).lean();
  res.json(transformId(docs));
});

// GET a single document by ID
app.get('/api/:resource/:id', async (req, res) => {
  const { resource, id } = req.params;
  const Model = getModel(resource);
  const doc = await Model.findById(id).lean();
  if (!doc) return res.status(404).json({ error: 'Not found' });
  res.json(transformId(doc));
});

// CREATE a document or REPLACE an entire collection
app.post('/api/:resource', async (req, res) => {
  const { resource } = req.params;
  const payload = req.body;
  const Model = getModel(resource);

  if (Array.isArray(payload)) {
    // If payload is an array, treat it as a full replacement of the collection.
    // This is the primary save mechanism for the frontend's backup/restore.
    await Model.deleteMany({});
    const inserted = await Model.insertMany(payload);
    return res.status(200).json({ message: `Collection ${resource} replaced.`, insertedCount: inserted.length });
  } else {
    // If payload is a single object, create a new document.
    const created = await Model.create(payload);
    // Use .toObject() to get a plain object that can be transformed
    return res.status(201).json(transformId(created.toObject()));
  }
});


// UPDATE a single document by ID (PUT)
app.put('/api/:resource/:id', async (req, res) => {
  const { resource, id } = req.params;
  const Model = getModel(resource);
  // `upsert: false` ensures it doesn't create a new document if ID not found
  const updated = await Model.findByIdAndUpdate(id, req.body, { new: true, upsert: false }).lean();
  if (!updated) return res.status(404).json({ error: 'Not found' });
  res.json(transformId(updated));
});

// DELETE a single document by ID
app.delete('/api/:resource/:id', async (req, res) => {
  const { resource, id } = req.params;
  const Model = getModel(resource);
  const removed = await Model.findByIdAndDelete(id).lean();
  if (!removed) return res.status(404).json({ error: 'Not found' });
  res.json({ deleted: true, id: removed._id.toString() });
});


// ----- Optional seeding from ./constants on startup -----
async function trySeedFromConstants() {
  try {
    const constants = require('./constants.ts');
    if (!constants || typeof constants !== 'object') {
        console.log("No constants file found for seeding.");
        return;
    }

    // Helper to check and seed a collection. Returns the documents (new or existing).
    const seedCollection = async (modelName, data, message) => {
        if (data && Array.isArray(data) && data.length > 0) {
            const Model = getModel(modelName);
            const count = await Model.countDocuments({});
            if (count === 0) {
                console.log(`🌱 Seeding ${message || modelName} with ${data.length} documents...`);
                // insertMany returns the documents with their new _ids
                return await Model.insertMany(data);
            } else {
                console.log(`Collection ${modelName} already has ${count} documents; skipping seed.`);
                // Return existing documents so their IDs can be used for relationship mapping
                return await Model.find({}).lean();
            }
        }
        return [];
    };

    // 1. Seed collections without dependencies first
    const seededDoctors = await seedCollection('doctors', constants.DOCTORS_DATA);
    const seededPatients = await seedCollection('patients', constants.PATIENTS_DATA);
    await seedCollection('personnel', constants.PERSONNEL_DATA);
    await seedCollection('bankAccounts', constants.BANK_ACCOUNTS_DATA);
    await seedCollection('insuranceProviders', constants.INSURANCE_PROVIDERS_DATA);
    await seedCollection('costCategories', constants.COST_CATEGORIES_DATA);
    await seedCollection('treatmentPlans', constants.TREATMENT_PLANS_DATA);
    await seedCollection('clinicalRecords', constants.CLINICAL_RECORDS_DATA);
    await seedCollection('transactions', constants.TRANSACTIONS_DATA);


    // 2. Seed appointments, mapping old hardcoded IDs to new MongoDB IDs
    const AppointmentModel = getModel('appointments');
    const appointmentCount = await AppointmentModel.countDocuments({});
    if (appointmentCount === 0 && constants.APPOINTMENTS_DATA && seededDoctors.length > 0 && seededPatients.length > 0) {
        console.log('🌱 Seeding appointments with correct relations...');

        // `seededDoctors` contains the documents from the DB, including the original `id` and the new `_id`.
        const doctorIdMap = new Map(seededDoctors.map(doc => [doc.id, doc._id.toString()]));
        const patientIdMap = new Map(seededPatients.map(pat => [pat.id, pat._id.toString()]));

        const appointmentsToSeed = constants.APPOINTMENTS_DATA.map(app => {
            // Find the new MongoDB ID using the old hardcoded ID from the constants file
            const newDoctorId = doctorIdMap.get(app.doctorId);
            const newPatientIds = app.patientIds.map(pid => patientIdMap.get(pid)).filter(Boolean);

            if (!newDoctorId || newPatientIds.length !== app.patientIds.length) {
                console.warn(`Could not map appointment, skipping. Original doctorId: ${app.doctorId}, patientIds: ${app.patientIds}`);
                return null;
            }
            
            // Return a new appointment object with the correct, relational MongoDB IDs
            return {
                ...app,
                doctorId: newDoctorId,
                patientIds: newPatientIds,
            };
        }).filter(Boolean); // Filter out any nulls from failed mappings
        
        if (appointmentsToSeed.length > 0) {
            await AppointmentModel.insertMany(appointmentsToSeed);
            console.log(`Seeded ${appointmentsToSeed.length} appointments.`);
        }
    } else if (appointmentCount === 0) {
        console.log("Appointments collection is empty, but prerequisite data (doctors/patients) for seeding is missing.");
    }

    // 3. Seed permissions object
    const permissionsData = constants.DEFAULT_PERMISSIONS;
    if (permissionsData) {
        const Model = getModel('permissions');
        if (await Model.countDocuments({}) === 0) {
            console.log('🌱 Seeding permissions...');
            await Model.create(permissionsData);
        } else {
             console.log('Permissions collection already exists; skipping seed.');
        }
    }

  } catch(e) {
    console.warn("Could not fully seed from constants. This is optional.", e.message);
  }
}

// ----- 404 handler for API routes -----
app.use('/api', (_req, res) => {
  res.status(404).json({ ok: false, message: 'API route not found' });
});

// ----- Global error handler -----
app.use((err, _req, res, next) => {
  console.error('Unhandled error:', err);
  if (!res.headersSent) {
    res.status(err?.status || 500).json({ error: err?.message || 'Internal Server Error' });
  } else {
    next(err);
  }
});

// ----- Start server -----
(async () => {
  await trySeedFromConstants();
  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log('Example Endpoints:');
    console.log(`  - GET  /api/patients`);
    console.log(`  - POST /api/auth/login`);
  });
})();
