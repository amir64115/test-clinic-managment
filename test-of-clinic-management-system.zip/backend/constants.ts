
// FIX: Add declaration for the 'module' object to resolve TypeScript error.
declare var module: any;

// This file is now plain JavaScript (CommonJS) but retains its .ts extension
// to work within the existing file structure. Types have been removed.

const TREATMENT_SERVICE_NAMES_DATA = [
  'کار درمانی',
  'گفتار درمانی',
  'بازی درمانی',
  'روانشناسی',
  'آموزش',
  'مشاوره',
  'ارزیابی',
];

const REFERRAL_SOURCES_DATA = [
  'وبسایت کلینیک',
  'اینستاگرام',
  'معرفی توسط بیمار دیگر',
  'معرفی توسط پزشک',
  'تابلوی کلینیک',
  'جستجوی اینترنتی',
  'سایر',
];

const BANK_ACCOUNTS_DATA = [
  { id: '1', name: 'حساب بانک ملت', accountNumber: '123-456-789' },
  { id: '2', name: 'حساب بانک ملی', accountNumber: '987-654-321' },
  { id: '3', name: 'صندوق نقدی کلینیک' },
];

const INSURANCE_PROVIDERS_DATA = [
  { id: '1', name: 'تامین اجتماعی', commissionType: 'percentage', commissionValue: 70 },
  { id: '2', name: 'خدمات درمانی', commissionType: 'percentage', commissionValue: 85 },
  { id: '3', name: 'بیمه تکمیلی ایران', commissionType: 'percentage', commissionValue: 90 },
  { id: '4', name: 'بیمه البرز (طرح ویژه)', commissionType: 'fixed', commissionValue: 150000 },
];

const COST_CATEGORIES_DATA = [
    { id: '1', name: 'حقوق و دستمزد' },
    { id: '2', name: 'اجاره' },
    { id: '3', name: 'قبوض و شارژ' },
    { id: '4', name: 'ملزومات مصرفی' },
    { id: '5', name: 'تعمیر و نگهداری' },
    { id: '6', name: 'تبلیغات و بازاریابی' },
    { id: '7', name: 'مالیات و عوارض' },
    { id: '8', name: 'پذیرایی و تشریفات' },
    { id: '9', name: 'ایاب و ذهاب' },
    { id: '10', name: 'سایر' },
];

const TREATMENT_PLANS_DATA = [];

const CLINICAL_RECORDS_DATA = [
  {
    id: '1',
    appointmentId: '101',
    patientId: '1',
    doctorId: '1',
    createdAt: "2024-05-10T10:00:00Z",
    updatedAt: "2024-05-10T10:15:00Z",
    note: "بیمار از درد قفسه سینه هنگام ورزش شکایت دارد. درد را به صورت فشاری توصیف می‌کند. فشار خون 130/80. نوار قلب در حالت استراحت ریتم سینوسی نرمال را نشان می‌دهد. معاینه قلبی بدون سوفل. آنژین پایدار. شروع درمان با متوپرولول 25 میلی‌گرم روزانه. برنامه‌ریزی برای تست ورزش در هفته آینده.",
    messages: [],
    subjective: "بیمار از درد قفسه سینه هنگام ورزش شکایت دارد. درد را به صورت فشاری توصیف می‌کند.",
    objective: "فشار خون 130/80. نوار قلب در حالت استراحت ریتم سینوسی نرمال را نشان می‌دهد. معاینه قلبی بدون سوفل.",
    assessment: "آنژین پایدار.",
    plan: "شروع درمان با متوپرولول 25 میلی‌گرم روزانه. برنامه‌ریزی برای تست ورزش در هفته آینده."
  },
  {
    id: '2',
    appointmentId: '102',
    patientId: '2',
    doctorId: '2',
    createdAt: "2024-05-11T11:30:00Z",
    updatedAt: "2024-05-11T11:40:00Z",
    note: "مادر گزارش می‌دهد کودک 3 ساله از 3 روز پیش تب 38.5 درجه و سرفه دارد. کودک هوشیار. گلوی قرمز و ملتهب. ریه‌ها در سمع پاک هستند. گوش‌ها نرمال. فارنژیت ویروسی. توصیه به مراقبت‌های حمایتی شامل استراحت، مصرف مایعات فراوان و استامینوفن برای تب. نیازی به آنتی‌بیوتیک نیست.",
    messages: [],
    subjective: "مادر گزارش می‌دهد کودک 3 ساله از 3 روز پیش تب 38.5 درجه و سرفه دارد.",
    objective: "کودک هوشیار. گلوی قرمز و ملتهب. ریه‌ها در سمع پاک هستند. گوش‌ها نرمال.",
    assessment: "فارنژیت ویروسی.",
    plan: "توصیه به مراقبت‌های حمایتی شامل استراحت، مصرف مایعات فراوان و استامینوفن برای تب. نیازی به آنتی‌بیوتیک نیست."
  }
];


const DEFAULT_PERMISSIONS = {
    'مدیر': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true },
        doctors: { view: true, add: true, edit: true, delete: true },
        personnel: { view: true, add: true, edit: true, delete: true },
        appointments: { view: true, add: true, edit: true, delete: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: true, add: true },
        settings: { view: true },
    },
    'مدیر داخلی': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true },
        doctors: { view: true, add: true, edit: true, delete: true },
        personnel: { view: false },
        appointments: { view: true, add: true, edit: true, delete: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: true, add: true },
        settings: { view: false },
    },
    'حسابدار': {
        dashboard: { view: true },
        patients: { view: true },
        doctors: { view: true },
        personnel: { view: false },
        appointments: { view: true },
        financial: { view: true, add: true, edit: true, delete: true },
        reports: { view: true },
        backup: { view: false },
        settings: { view: false },
    },
    'پزشک': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: true },
        doctors: { view: true },
        personnel: { view: false },
        appointments: { view: true, edit: true },
        financial: { view: false },
        reports: { view: true },
        backup: { view: false },
        settings: { view: false },
    },
    'منشی': {
        dashboard: { view: true },
        patients: { view: true, add: true, edit: true, delete: false },
        doctors: { view: true },
        personnel: { view: false },
        appointments: { view: true, add: true, edit: true, delete: false },
        financial: { view: false },
        reports: { view: false },
        backup: { view: false },
        settings: { view: false },
    }
};

const PATIENTS_DATA = [
  { id: '1', name: 'علی محمدی', nationalId: '1234567890', phone1: '09123456789', phone2: '02188888888', age: 39, gender: 'مرد', insuranceProviderId: '1', nextSessionPlan: 'بررسی نتایج آزمایش خون و تنظیم دوز دارو. جلسه بعدی روی تکنیک‌های مدیریت استرس تمرکز می‌کنیم.', referredById: '2', referralSource: 'وبسایت کلینیک', attachments: [] },
  { id: '2', name: 'زهرا رضایی', nationalId: '0987654321', phone1: '09129876543', age: 32, gender: 'زن', insuranceProviderId: '2', referralSource: 'معرفی توسط بیمار دیگر', attachments: [] },
  { id: '3', name: 'حسین احمدی', nationalId: '1122334455', phone1: '09351234567', age: 46, gender: 'مرد', referredById: '1', attachments: [] }
];

const DOCTORS_DATA = [
  { id: '1', name: 'دکتر مریم کریمی', specialty: 'متخصص قلب', education: 'فوق تخصص قلب و عروق از دانشگاه علوم پزشکی تهران', phone: '09101112233', photoUrl: 'https://picsum.photos/seed/doc1/200', officeHours: 'شنبه تا چهارشنبه، ۹ صبح تا ۵ عصر', ratePerHour: 450000, participationRate: 25, referralParticipationRate: 35 },
  { id: '2', name: 'دکتر رضا قاسمی', specialty: 'متخصص اطفال', education: 'دانشگاه علوم پزشکی شهید بهشتی', phone: '09104445566', photoUrl: 'https://picsum.photos/seed/doc2/200', officeHours: 'یکشنبه و سه‌شنبه، ۱۰ صبح تا ۶ عصر', ratePerHour: 300000, participationRate: 20, referralParticipationRate: 30 },
];

const PERSONNEL_DATA = [
    { id: '1', name: 'شیما محمدی', nationalId: '1112223334', phone: '09121112233', role: 'منشی', employmentDate: '2022-01-15', age: 29, photoUrl: 'https://picsum.photos/seed/staff1/200', username: 'secretary', password: '12345' },
    { id: '2', name: 'کامران تهرانی', nationalId: '4445556667', phone: '09367778899', role: 'مدیر', employmentDate: '2021-06-01', age: 36, photoUrl: 'https://picsum.photos/seed/staff2/200', username: 'manager', password: '12345' },
    { id: '3', name: 'دکتر الهام جعفری', nationalId: '7778889990', phone: '09104567890', role: 'پزشک', employmentDate: '2023-02-01', age: 39, username: 'doctor', password: '12345' },
    { id: '4', name: 'آقای حسابی', nationalId: '1231231231', phone: '09123214567', role: 'حسابدار', employmentDate: '2022-09-20', age: 34, username: 'accountant', password: '12345' }
];

const formatDate = (date) => date.toISOString().split('T')[0];

const generateAppointments = () => {
  const appointments = [];
  const patientIds = PATIENTS_DATA.map(p => p.id);
  const doctorIds = DOCTORS_DATA.map(d => d.id);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Generate some appointments for today for demo
  for(let i=0; i<5; i++) {
      const hour = 9 + i;
      appointments.push({
        id: String(100 + i),
        patientIds: [patientIds[i % patientIds.length]],
        doctorId: doctorIds[i % doctorIds.length],
        date: formatDate(today),
        time: `${String(hour).padStart(2, '0')}:00`,
        status: 'Scheduled',
        paymentStatus: 'Unpaid',
      });
  }
  return appointments;
};

const APPOINTMENTS_DATA = generateAppointments();

const TRANSACTIONS_DATA = [];

module.exports = {
    TREATMENT_SERVICE_NAMES_DATA,
    REFERRAL_SOURCES_DATA,
    BANK_ACCOUNTS_DATA,
    INSURANCE_PROVIDERS_DATA,
    COST_CATEGORIES_DATA,
    TREATMENT_PLANS_DATA,
    CLINICAL_RECORDS_DATA,
    DEFAULT_PERMISSIONS,
    PATIENTS_DATA,
    DOCTORS_DATA,
    PERSONNEL_DATA,
    APPOINTMENTS_DATA,
    TRANSACTIONS_DATA
};
