
export interface PatientFileAttachment {
  id: string;
  fileName: string;
  dataUrl: string; // base64 data url
}

export interface Patient {
  id: string;
  name: string;
  nationalId: string;
  phone1: string;
  phone2?: string;
  age: number;
  gender: 'مرد' | 'زن';
  insuranceProviderId?: string;
  nextSessionPlan?: string;
  referredById?: string;
  photoUrl?: string;
  referralSource?: string;
  attachments?: PatientFileAttachment[];
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  education?: string;
  phone: string;
  photoUrl?: string;
  officeHours?: string;
  ratePerHour: number;
  participationRate: number;
  referralParticipationRate: number;
}

export interface Personnel {
    id: string;
    name: string;
    nationalId: string;
    phone: string;
    role: string;
    employmentDate: string;
    age: number;
    photoUrl?: string;
    username: string;
    password: string;
}

export interface SuggestedService {
  doctorId: string;
  count: number;
}

export interface Appointment {
  id: string;
  patientIds: string[];
  doctorId: string;
  date: string; // ISO 'YYYY-MM-DD'
  time?: string; // 'HH:MM'
  sessionDuration?: string; // '30', '45', '60' etc.
  sessionFee?: number;
  status: 'Scheduled' | 'Completed' | 'Cancelled' | 'Waiting';
  paymentStatus: 'Paid' | 'Unpaid';
  paymentMethod?: 'نقد' | 'کارت به کارت' | 'پوز';
  cancellationReason?: string;
  cancellationFee?: number;
  notes?: string;
  dateAddedToWaitingList?: string;
  reminderDateTime?: string; // ISO 'YYYY-MM-DDTHH:mm:ss'
  reminderSent?: boolean;
  applyInsurance?: boolean;
  suggestedDoctorIds?: string[];
  suggestedServices?: SuggestedService[];
}

export interface ClinicalRecordMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  text: string;
  createdAt: string; // ISO String
}

export interface ClinicalRecord {
  id: string;
  appointmentId: string;
  patientId: string;
  doctorId: string;
  createdAt: string; // ISO String
  updatedAt: string; // ISO String
  note: string; // Single note field replacing SOAP
  messages: ClinicalRecordMessage[];
  managerComment?: string; // Deprecated
  subjective?: string; // Deprecated
  objective?: string; // Deprecated
  assessment?: string; // Deprecated
  plan?: string; // Deprecated
}

export interface Transaction {
  id: string;
  type: 'درآمد' | 'هزینه';
  description: string;
  amount: number;
  date: string; // ISO 'YYYY-MM-DD'
  patientId?: string;
  doctorId?: string;
  personnelId?: string;
  costCategory?: string;
  accountDebited?: string;
  payer?: string;
  paymentMethod?: 'نقد' | 'کارت به کارت' | 'پوز';
}

export interface BankAccount {
  id: string;
  name: string;
  accountNumber?: string;
}

export interface InsuranceProvider {
  id: string;
  name: string;
  commissionType: 'percentage' | 'fixed';
  commissionValue: number;
}

export interface CostCategory {
    id: string;
    name: string;
}

export interface TreatmentService {
  id: string;
  serviceName: string;
  sessions: number;
  frequency: 'هفتگی' | 'ماهانه';
  therapistIds: string[];
}

export interface TreatmentPlan {
  id: string;
  patientId: string;
  referringDoctorId: string;
  createdAt: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'archived';
  services: TreatmentService[];
  notes?: string;
  cancellationReason?: string;
  confirmedById?: string;
  confirmedAt?: string;
  cancelledById?: string;
  cancelledAt?: string;
}

// Permissions types
export type AppView = 'dashboard' | 'patients' | 'doctors' | 'personnel' | 'appointments' | 'financial' | 'reports' | 'backup' | 'settings';

export interface PermissionSet {
  view?: boolean;
  add?: boolean;
  edit?: boolean;
  delete?: boolean;
}

export type RolePermissions = {
  [key in AppView]?: PermissionSet;
};

export type AppPermissions = {
  [role: string]: RolePermissions;
};
