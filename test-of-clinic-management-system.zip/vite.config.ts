
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'url';

export default defineConfig({
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
  plugins: [react()],
  resolve: {
    alias: {
      // FIX: __dirname is not available in ES modules. Using import.meta.url is the modern and correct way to get the current directory path.
      '@': fileURLToPath(new URL('.', import.meta.url)),
    }
  }
});
